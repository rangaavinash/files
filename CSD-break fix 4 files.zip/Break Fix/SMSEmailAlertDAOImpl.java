package com.fss.csr.smsemailalert.dao;

import java.sql.CallableStatement;
import java.sql.Connection;

/**
*=======================================================================================================================================
*   Version      Date          Author                Reason
*=======================================================================================================================================
*     1.0      15-06-12       Dnyaneshwar J      Initial Version
*     1.1	   18-06-12		  Dnyaneshwar J		 add method for updating alerts and user details
*     1.2	   22-06-12		  Dnyaneshwar J		 Change Store Procedure calling now WRPAAER
*     1.3	   27-06-12		  Dnyaneshwar J		 Change in query to get amount format as 0.00
*     												take member nmber using DB query,
*     												take constant values from common class
*     1.4	   04-07-12		  Dnyaneshwar J		 Change in Mobile carrier names
*     1.5	   07-08-12		  Dnyaneshwar J		 add trim function while setting to bean
*     1.6	   22-08-12		  Dnyaneshwar J		 Changes done for taking carrier from table
*     1.7	   28-08-12		  Kinjal P			 Change made for Checking Debug Flag condition
*     1.8	   01-09-12		  Dnyaneshwar J		 taking transaction code from constants.
*     1.9      24-09-12       Abhay R		  	  Changes done for amount Format.
*     1.10     01-10-12       Abhay R		  	  Changes done for amount De Format.
*     1.2      26-12-12       Dnyaneshwar J  	  Changes done for logging IpAddress.
*     1.3      08-03-13       Dnyaneshwar J  	  Changes done for JIRA Issue (FSS-410) disable Time for Daily Balance Alert
*     1.4      11-06-12       Abhay R     	      Changes for message type 200
*     1.5      20-08-13       Dnyaneshwar J  	  add c2c flag in select query to store C2C alert flag as 1.7.4 release item with issue id MOB-31
*     1.6      30-09-13       Dnyaneshwar J  	  add two new alerts on alert config screen JH-6 changes.
*     1.7      16-10-13       Dnyaneshwar J      Modify return type of alertSettings from String to SMSEmailAlert & add getMaskCard method.
*     1.8      03-01-14       Dnyaneshwar J      Comment out c2c alert flag 
*=======================================================================================================================================
*This Class is used for Update SMS & Email Alerts for Card Number.
*/

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.fss.csr.common.bean.KeyValueBean;
import com.fss.csr.common.util.CMSUtils;
import com.fss.csr.common.util.CSRUtils;
import com.fss.csr.common.util.CmsConstants;
import com.fss.csr.common.util.NullUtilities;
import com.fss.csr.common.util.cmsParameters;
import com.fss.csr.common.util.logger.LoggerUtil;
import com.fss.csr.smsemailalert.bean.Alerts;
import com.fss.csr.smsemailalert.bean.SMSEmailAlert;
import com.fss.csr.startup.StartOfProcess;

public class SMSEmailAlertDAOImpl extends SimpleJdbcDaoSupport implements SMSEmailAlertDAO {
	
	private static LoggerUtil loggerUtil = new LoggerUtil(SMSEmailAlertDAOImpl.class);
	
	@Override
	public SMSEmailAlert getAvlblAlertForCard(String instCode,String cardNumber,String languageID) throws Exception {
		loggerUtil.logMethodEntry("getAvlblAlertForCard");
		
		StringBuffer sql=new StringBuffer();
		List<SMSEmailAlert> smsEmailAlertbean;
		SMSEmailAlert smsEmailAlert=new SMSEmailAlert();
		Alerts alert=new Alerts();
//		sql.append("SELECT  ");
//		sql.append("cmm_carrier_name Mobile_Carrier, cmm_carrier_code carrierCode,"); 
//		sql.append("CaM_MOBL_ONE Mobile_no, ");
//		sql.append("CAM_EMAIL Email_id_one, ");
//		sql.append("ccm_email_two Email_id_two, ");
////		sql.append("CPS_LOADCREDIT_FLAG  P_loadcredit_flag,       ");
//		sql.append("nvl(CSA_LOADORCREDIT_FLAG,'0') A_loadcredit_flag, ");//Modified by Dnyaneshwar J on 22 Aug 2013
////		sql.append("CPS_LOWBAL_FLAG P_lowbal_flag, ");
//		sql.append("nvl(CSA_LOWBAL_FLAG,'0') A_lowbal_flag, ");//Modified by Dnyaneshwar J on 22 Aug 2013
//		sql.append("nvl(TO_CHAR(CSA_LOWBAL_AMT,'"+CMSUtils.AMTDEFORMAT+"'),'0.00') A_lowbal_amt, ");//changed by Dnyaneshwar J to display amount in 0.00 format on 27 Jun 2012////Modified by Dnyaneshwar J on 22 Aug 2013
////		sql.append("CPS_NEGATIVEBAL_FLAG P_negbal_flag,    ");
//		sql.append("nvl(CSA_NEGBAL_FLAG,'0')      A_negbal_flag, ");//Modified by Dnyaneshwar J on 22 Aug 2013
////		sql.append("CPS_HIGHAUTHAMT_FLAG P_highauth_flag, ");
//		sql.append("nvl(CSA_HIGHAUTHAMT_FLAG,'0') A_highauth_flag,      ");//Modified by Dnyaneshwar J on 22 Aug 2013
//		sql.append("nvl(TO_CHAR(CSA_HIGHAUTHAMT,'"+CMSUtils.AMTDEFORMAT+"'),'0.00') A_highauth_amt, ");//changed by Dnyaneshwar J to display amount in 0.00 format on 27 Jun 2012////Modified by Dnyaneshwar J on 22 Aug 2013
////		sql.append("CPS_DAILYBAL_FLAG    P_dailybal_flag, ");
//		sql.append("nvl(CSA_DAILYBAL_FLAG,'0')    A_dailybal_flag, ");//Modified by Dnyaneshwar J on 22 Aug 2013
//		sql.append("CSA_BEGIN_TIME       A_Dailybal_Begin_time, ");
//		sql.append("CSA_END_TIME         A_Dailybal_End_time, ");
////		sql.append("CPS_INSUFFUND_FLAG  P_insuffund_flag, ");
//		sql.append("nvl(CSA_INSUFF_FLAG,'0')     A_insuffund_flag, ");
////		sql.append("CPS_INCORRECTPIN_FLAG P_INCORRECTPIN_FLAG, ");
//		sql.append("nvl(CSA_INCORRPIN_FLAG,'0')    A_INCORRECTPIN_FLAG ");
//		sql.append(",nvl(CSA_C2C_FLAG,'0') A_CSA_C2C_FLAG ");//Added by Dnyaneshwar J on 20 Aug 2013
//		sql.append(",nvl(CSA_FAST50_FLAG,'0') A_fast50_flag, ");//sn-Added by Dnyaneshwar J on 30 Sept 2013
////		sql.append("CPS_FAST50_FLAG  p_fast50_flag,       ");
////		sql.append("CPS_FEDTAX_REFUND_FLAG  p_fedtax_refund_flag      ");
//		sql.append("decode(ccm_optinoptout_status,0,'Not Available',1,'Opted In',2,'Opted Out')CCM_OPTINOPTOUT_STATUS,");//Added By Narsing I on 9th Oct 2013
//		sql.append("nvl(CSA_FEDTAX_REFUND_FLAG,'0') a_fedtax_refund_flag ");//en-Added by Dnyaneshwar J on 0 Sept 2013
////		sql.append(" ,CSA_ALERT_LANG_ID alert_lang_id,substr(cps_alert_msg,1,1) flag,cps_alert_id alert_id ");
//		sql.append(" ,CSA_ALERT_LANG_ID alert_lang_id  ");
//		sql.append("from CMS_APPL_PAN"//,CMS_PRODCATG_SMSEMAIL_ALERTS
//		+",CMS_SMSANDEMAIL_ALERT,cms_addr_mast,cms_cust_mast, cms_mobilecarrier_mast ");
//		sql.append("WHERE CSA_PAN_CODE  =  gethash(?) ");
//		sql.append("AND   CAP_INST_CODE = CSA_INST_CODE ");
//		sql.append("AND   CAP_PAN_CODE  = CSA_PAN_CODE ");
//	/*	sql.append("AND   CAP_INST_CODE = CPS_INST_CODE ");
//		sql.append("AND   CAP_PROD_CODE = CPS_PROD_CODE ");
//		sql.append("AND   CAP_CARD_TYPE = CPS_CARD_TYPE ");*/
//		sql.append("AND   CAP_INST_CODE = CaM_INST_CODE ");
//		sql.append("AND   CAP_bill_addr = CaM_addr_CODE ");
//		sql.append("and   CAP_INST_CODE = CcM_INST_CODE ");
//		sql.append("and CSA_CELLPHONECARRIER=cmm_carrier_code ");
//		sql.append("and   CAP_cust_CODE = CcM_cust_CODE ");
//		sql.append("and   NVL(CSA_ALERT_LANG_ID,'1') = ? ");
////		sql.append("and ((CSA_ALERT_LANG_ID is not null and CSA_ALERT_LANG_ID=cps_alert_lang_id) or (CSA_ALERT_LANG_ID is null and  CPS_DEFALERT_LANG_FLAG='Y'))");
		
		sql.append("SELECT  ");
		sql.append("cmm_carrier_name Mobile_Carrier, cmm_carrier_code carrierCode,"); 
		sql.append("Fn_Dmaps_Main( CaM_MOBL_ONE)  Mobile_no, ");
		sql.append("Fn_Dmaps_Main( CAM_EMAIL)   Email_id_one, ");
		sql.append("ccm_email_two Email_id_two, ");
//		sql.append("CPS_LOADCREDIT_FLAG  P_loadcredit_flag,       ");
		sql.append("nvl(CSA_LOADORCREDIT_FLAG,'0') A_loadcredit_flag, ");//Modified by Dnyaneshwar J on 22 Aug 2013
//		sql.append("CPS_LOWBAL_FLAG P_lowbal_flag, ");
		sql.append("nvl(CSA_LOWBAL_FLAG,'0') A_lowbal_flag, ");//Modified by Dnyaneshwar J on 22 Aug 2013
		sql.append("nvl(TO_CHAR(CSA_LOWBAL_AMT,'"+CMSUtils.AMTDEFORMAT+"'),'0.00') A_lowbal_amt, ");//changed by Dnyaneshwar J to display amount in 0.00 format on 27 Jun 2012////Modified by Dnyaneshwar J on 22 Aug 2013
//		sql.append("CPS_NEGATIVEBAL_FLAG P_negbal_flag,    ");
		sql.append("nvl(CSA_NEGBAL_FLAG,'0')      A_negbal_flag, ");//Modified by Dnyaneshwar J on 22 Aug 2013
//		sql.append("CPS_HIGHAUTHAMT_FLAG P_highauth_flag, ");
		sql.append("nvl(CSA_HIGHAUTHAMT_FLAG,'0') A_highauth_flag,      ");//Modified by Dnyaneshwar J on 22 Aug 2013
		sql.append("nvl(TO_CHAR(CSA_HIGHAUTHAMT,'"+CMSUtils.AMTDEFORMAT+"'),'0.00') A_highauth_amt, ");//changed by Dnyaneshwar J to display amount in 0.00 format on 27 Jun 2012////Modified by Dnyaneshwar J on 22 Aug 2013
//		sql.append("CPS_DAILYBAL_FLAG    P_dailybal_flag, ");
		sql.append("nvl(CSA_DAILYBAL_FLAG,'0')    A_dailybal_flag, ");//Modified by Dnyaneshwar J on 22 Aug 2013
		sql.append("CSA_BEGIN_TIME       A_Dailybal_Begin_time, ");
		sql.append("CSA_END_TIME         A_Dailybal_End_time, ");
//		sql.append("CPS_INSUFFUND_FLAG  P_insuffund_flag, ");
		sql.append("nvl(CSA_INSUFF_FLAG,'0')     A_insuffund_flag, ");
//		sql.append("CPS_INCORRECTPIN_FLAG P_INCORRECTPIN_FLAG, ");
		sql.append("nvl(CSA_INCORRPIN_FLAG,'0')    A_INCORRECTPIN_FLAG ");
		sql.append(",nvl(CSA_C2C_FLAG,'0') A_CSA_C2C_FLAG ");//Added by Dnyaneshwar J on 20 Aug 2013
		sql.append(",nvl(CSA_FAST50_FLAG,'0') A_fast50_flag, ");//sn-Added by Dnyaneshwar J on 30 Sept 2013
//		sql.append("CPS_FAST50_FLAG  p_fast50_flag,       ");
//		sql.append("CPS_FEDTAX_REFUND_FLAG  p_fedtax_refund_flag      ");
		sql.append("decode(ccm_optinoptout_status,0,'Not Available',1,'Opted In',2,'Opted Out')CCM_OPTINOPTOUT_STATUS,");//Added By Narsing I on 9th Oct 2013
		sql.append("nvl(CSA_FEDTAX_REFUND_FLAG,'0') a_fedtax_refund_flag ");//en-Added by Dnyaneshwar J on 0 Sept 2013
//		sql.append(" ,CSA_ALERT_LANG_ID alert_lang_id,substr(cps_alert_msg,1,1) flag,cps_alert_id alert_id ");
		sql.append(" ,CSA_ALERT_LANG_ID alert_lang_id  ");
		sql.append( " from CMS_APPL_PAN "//,CMS_PRODCATG_SMSEMAIL_ALERTS
		+", CMS_SMSANDEMAIL_ALERT,cms_addr_mast,cms_cust_mast, cms_mobilecarrier_mast  ");
		sql.append(" WHERE CSA_PAN_CODE  =  gethash(?) ");
		sql.append(" AND   CAP_INST_CODE = CSA_INST_CODE ");
		sql.append(" AND   CAP_PAN_CODE  = CSA_PAN_CODE ");
	/*	sql.append("AND   CAP_INST_CODE = CPS_INST_CODE ");
		sql.append("AND   CAP_PROD_CODE = CPS_PROD_CODE ");
		sql.append("AND   CAP_CARD_TYPE = CPS_CARD_TYPE ");*/
		sql.append(" AND   CAP_INST_CODE = CaM_INST_CODE ");
		sql.append(" AND   CAP_bill_addr = CaM_addr_CODE ");
		sql.append(" and   CAP_INST_CODE = CcM_INST_CODE ");
		sql.append(" and CSA_CELLPHONECARRIER=cmm_carrier_code ");
		sql.append(" and   CAP_cust_CODE = CcM_cust_CODE  ");
		sql.append(" and   NVL(CSA_ALERT_LANG_ID,'1') = ? ");
//		sql.append("and ((CSA_ALERT_LANG_ID is not null and CSA_ALERT_LANG_ID=cps_alert_lang_id) or (CSA_ALERT_LANG_ID is null and  CPS_DEFALERT_LANG_FLAG='Y'))");
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("Query for getting Configured Alerts : "+sql.toString());
			loggerUtil.debug("instCode "+instCode);
		}
		loggerUtil.logCardNumber(cardNumber);
		 
		 ParameterizedRowMapper<SMSEmailAlert> mapper = new ParameterizedRowMapper<SMSEmailAlert>() {
				public SMSEmailAlert mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					SMSEmailAlert smsAlert = new SMSEmailAlert();
					Alerts alert = new Alerts();
					
					//Setting flags
			/*		alert.setLoadCreditFlag(rs.getString("P_loadcredit_flag"));
					alert.setLowerBalFlag(rs.getString("P_lowbal_flag"));
					alert.setNegtiveBalFlag(rs.getString("P_negbal_flag"));
					alert.setHighAuthFlag(rs.getString("P_highauth_flag"));
					alert.setDailyBalFlag(rs.getString("P_dailybal_flag"));
					alert.setInsufficientFundFlag(rs.getString("P_insuffund_flag"));
					alert.setIncorrectPINFlag(rs.getString("P_INCORRECTPIN_FLAG"));
					alert.setFast50Flag(rs.getString("p_fast50_flag"));//Added by Dnyaneshwar J on 30 Sept 2013
					alert.setFedTaxRefundFlag(rs.getString("p_fedtax_refund_flag"));//Added by Dnyaneshwar J on 30 Sept 2013
					*/

					//setting Value of alerts for e.g. disable, sms, email, both
					alert.setLoadCreditAlert(rs.getString("A_loadcredit_flag"));
					alert.setLowBalAlert(rs.getString("A_lowbal_flag"));
					alert.setNegativeBalAlert(rs.getString("A_negbal_flag"));
					alert.setHighAuthAmtAlert(rs.getString("A_highauth_flag"));
					alert.setDailyBalAlert(rs.getString("A_dailybal_flag"));
					alert.setInsufficientFundAlert(rs.getString("A_insuffund_flag"));
					alert.setCheckIncorrectPINAlert(rs.getString("A_INCORRECTPIN_FLAG"));
					//alert.setC2cAlert(rs.getString("A_CSA_C2C_FLAG"));//Added by Dnyaneshwar J on 20 Aug 2013 //Commented By Narsing on 24th Dec 2013 to remove c2c Alert
					alert.setFast50Alert(rs.getString("A_fast50_flag"));//Added by Dnyaneshwar J on 30 Sept 2013
					alert.setFedTaxRefundAlert(rs.getString("a_fedtax_refund_flag"));//Added by Dnyaneshwar J on 30 Sept 2013
					alert.setAlertLangId(rs.getString("alert_lang_id"));
					//setting values
					if(rs.getString("A_lowbal_amt")!=null && !(rs.getString("A_lowbal_amt").trim().equals(""))){//Add trim by Dnyaneshwar J 07 Aug 2012
						alert.setLowBalAmt(rs.getString("A_lowbal_amt").trim());
					}
					else{
						alert.setLowBalAmt("0.00");
					}
					
					if(rs.getString("A_highauth_amt")!=null && !(rs.getString("A_highauth_amt").trim().equals(""))){//Add trim by Dnyaneshwar J 07 Aug 2012
						alert.setHighAuthAmt(rs.getString("A_highauth_amt").trim());
					}
					else{
						alert.setHighAuthAmt("0.00");
					}
					
					alert.setDailyBalBeginTime(rs.getString("A_Dailybal_Begin_time"));
					alert.setDailyBalEndTime(rs.getString("A_Dailybal_End_time"));
					
					if(rs.getString("Mobile_Carrier")!=null && !(rs.getString("Mobile_Carrier").trim().equals(""))){
						smsAlert.setCellPhoneCarrier(rs.getString("Mobile_Carrier"));
						smsAlert.setCarrierCode(rs.getString("carrierCode"));
					}
					else{
						smsAlert.setCellPhoneCarrier(rs.getString("Mobile_Carrier"));
						smsAlert.setCarrierCode(rs.getString("carrierCode"));
						/*smsAlert.setCellPhoneCarrier("Select Phone Carrier");
						smsAlert.setCarrierCode("select");*/
					}
					if(rs.getString("CCM_OPTINOPTOUT_STATUS")!=null && !(rs.getString("CCM_OPTINOPTOUT_STATUS").trim().equals(""))){//Added By Narsing I on 9th Oct 2013
						smsAlert.setOptinoptoutstatus(rs.getString("CCM_OPTINOPTOUT_STATUS"));
					}//Added By Narsing I on 9th Oct 2013
					smsAlert.setCellPhoneNumber(rs.getString("Mobile_no"));
					if(rs.getString("Email_id_one")!=null && !(rs.getString("Email_id_one").equals(""))){
						smsAlert.setEmailOne(rs.getString("Email_id_one").trim());
					}
					if(rs.getString("Email_id_two")!=null && !(rs.getString("Email_id_two").equals(""))){
						smsAlert.setEmailTwo(rs.getString("Email_id_two").trim());
					}
					
					smsAlert.setAlerts(alert);
					
					return smsAlert;
				}
			};
			smsEmailAlertbean = getSimpleJdbcTemplate().query(sql.toString(), mapper,cardNumber,languageID);
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("Searched Record List Size : "+smsEmailAlertbean.size());
			}
			if(smsEmailAlertbean.size()==1){
				//return (SMSEmailAlert) smsEmailAlertbean.get(0);
				List<Alerts> alertList=new ArrayList<Alerts>();
				smsEmailAlert= (SMSEmailAlert) smsEmailAlertbean.get(0);
				alert=smsEmailAlert.getAlerts();
				String qry="select dbms_lob.substr(cps_alert_msg,1,1) flag,cps_alert_id alert_id from cms_appl_pan,CMS_PRODCATG_SMSEMAIL_ALERTS" +
						" where CAP_INST_CODE= CPS_INST_CODE AND CAP_PROD_CODE = CPS_PROD_CODE AND CAP_CARD_TYPE= CPS_CARD_TYPE" +
						" and  cap_pan_code=gethash(?) and cps_alert_lang_id=?";

				final HashMap<String,String> map=new HashMap<String,String>();	
				 ParameterizedRowMapper<Alerts> alertMapper = new ParameterizedRowMapper<Alerts>() {
						public Alerts mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							
							Alerts alert = new Alerts();
							
							map.put(rs.getString("alert_id"), rs.getString("flag"));

							return alert;
						}
					};
				
				
				
				
				
			alertList = getSimpleJdbcTemplate().query(qry,alertMapper,cardNumber,languageID);
				
				if(map.get("9")!=null )	
					alert.setLoadCreditFlag(map.get("9"));
				 if( map.get("10")!=null )
					alert.setLowerBalFlag(map.get("10"));
				 if( map.get("11")!=null )
					alert.setNegtiveBalFlag(map.get("11"));
				 if( map.get("16")!=null )
					alert.setHighAuthFlag(map.get("16"));
				 if( map.get("12")!=null )
					alert.setDailyBalFlag(map.get("12"));
				 if( map.get("17")!=null )
					alert.setInsufficientFundFlag( map.get("17"));
				 if( map.get("13")!=null )
					alert.setIncorrectPINFlag(map.get("13"));
				 if( map.get("21")!=null )
					alert.setFast50Flag(map.get("21"));
				 if( map.get("22")!=null )
					alert.setFedTaxRefundFlag(map.get("22"));
				
				loggerUtil.debug("alert.setLoadCreditFlag"+alert.getLoadCreditFlag());
				loggerUtil.debug("alert.setLowerBalFlag"+alert.getLowerBalFlag());
				loggerUtil.debug("alert.setNegtiveBalFlag"+alert.getNegtiveBalFlag());
				loggerUtil.debug("alert.setHighAuthFlag"+alert.getHighAuthFlag());
				loggerUtil.debug("alert.setDailyBalFlag"+alert.getDailyBalFlag());
				loggerUtil.debug("alert.setInsufficientFundFlag"+alert.getInsufficientFundFlag());
				loggerUtil.debug("alert.setIncorrectPINFlag"+alert.getIncorrectPINFlag());
				loggerUtil.debug("alert.setFast50Flag"+alert.getFast50Flag());
				loggerUtil.debug("alert.setFedTaxRefundFlag"+alert.getFedTaxRefundFlag());
				
				smsEmailAlert.setAlerts(alert);
				smsEmailAlertbean.clear();
				smsEmailAlertbean.add(smsEmailAlert);
				return smsEmailAlertbean.get(0);
			}
			else if(smsEmailAlertbean.size()==0)
			{
				StringBuffer sqlQry=new StringBuffer();
				
//				sqlQry.append("SELECT  ");
//				sqlQry.append("cmm_carrier_name Mobile_Carrier, cmm_carrier_code carrierCode,"); 
//				sqlQry.append("CaM_MOBL_ONE Mobile_no, ");
//				sqlQry.append("CAM_EMAIL Email_id_one, ");
//				sqlQry.append("ccm_email_two Email_id_two, ");
//				sqlQry.append("decode(ccm_optinoptout_status,0,'Not Available',1,'Opted In',2,'Opted Out')CCM_OPTINOPTOUT_STATUS,");//Added By Narsing I on 9th Oct 2013
//				sqlQry.append("CSA_ALERT_LANG_ID alert_lang_id  ");
//				sqlQry.append("from CMS_APPL_PAN,CMS_SMSANDEMAIL_ALERT,cms_addr_mast,cms_cust_mast, cms_mobilecarrier_mast ");
//				sqlQry.append("WHERE CSA_PAN_CODE  =  gethash(?) ");
//				sqlQry.append("AND   CAP_INST_CODE = CSA_INST_CODE ");
//				sqlQry.append("AND   CAP_PAN_CODE  = CSA_PAN_CODE ");
//				sqlQry.append("AND   CAP_INST_CODE = CaM_INST_CODE ");
//				sqlQry.append("AND   CAP_bill_addr = CaM_addr_CODE ");
//				sqlQry.append("and   CAP_INST_CODE = CcM_INST_CODE ");
//				sqlQry.append("and CSA_CELLPHONECARRIER=cmm_carrier_code ");
//				sqlQry.append("and   CAP_cust_CODE = CcM_cust_CODE ");
				
				
				sqlQry.append("SELECT  ");
				sqlQry.append(" cmm_carrier_name Mobile_Carrier, cmm_carrier_code carrierCode,"); 
				sqlQry.append(" Decode(Cpc_Encrypt_Enable,'Y',Fn_Dmaps_Main( CaM_MOBL_ONE),CaM_MOBL_ONE ) Mobile_no, ");
				sqlQry.append(" Decode(Cpc_Encrypt_Enable,'Y',Fn_Dmaps_Main( CAM_EMAIL),CAM_EMAIL ) Email_id_one, ");
				sqlQry.append("ccm_email_two Email_id_two, ");
				sqlQry.append("decode(ccm_optinoptout_status,0,'Not Available',1,'Opted In',2,'Opted Out')CCM_OPTINOPTOUT_STATUS,");//Added By Narsing I on 9th Oct 2013
				sqlQry.append("CSA_ALERT_LANG_ID alert_lang_id  ");
				sqlQry.append(" from CMS_APPL_PAN,CMS_SMSANDEMAIL_ALERT,cms_addr_mast,cms_cust_mast, cms_mobilecarrier_mast ,CMS_PROD_CATTYPE ");
				sqlQry.append("WHERE CSA_PAN_CODE  =  gethash(?) ");
				sqlQry.append("AND   CAP_INST_CODE = CSA_INST_CODE ");
				sqlQry.append("AND   CAP_PAN_CODE  = CSA_PAN_CODE ");
				sqlQry.append("AND   CAP_INST_CODE = CaM_INST_CODE ");
				sqlQry.append("AND   CAP_bill_addr = CaM_addr_CODE ");
				sqlQry.append("and   CAP_INST_CODE = CcM_INST_CODE  AND CAP_INST_CODE=CPC_INST_CODE AND CAP_PROD_CODE=CPC_PROD_CODE AND CAP_CARD_TYPE=CPC_CARD_TYPE ");
				sqlQry.append("and CSA_CELLPHONECARRIER=cmm_carrier_code ");
				sqlQry.append("and   CAP_cust_CODE = CcM_cust_CODE ");

				if(loggerUtil.isDebugEnabled())
				{
					loggerUtil.debug("Query for getting customer details in alerts : "+sqlQry.toString());
					loggerUtil.debug("instCode "+instCode);
				}
				loggerUtil.logCardNumber(cardNumber);
				

				 ParameterizedRowMapper<SMSEmailAlert> alertmapper = new ParameterizedRowMapper<SMSEmailAlert>() {
						public SMSEmailAlert mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							SMSEmailAlert smsAlert = new SMSEmailAlert();
							Alerts alert = new Alerts();
							
							//Setting flags
						/*	alert.setLoadCreditFlag("0");
							alert.setLowerBalFlag("0");
							alert.setNegtiveBalFlag("0");
							alert.setHighAuthFlag("0");
							alert.setDailyBalFlag("0");
							alert.setInsufficientFundFlag("0");
							alert.setIncorrectPINFlag("0");
							alert.setFast50Flag("0");
							alert.setFedTaxRefundFlag("0");
							*/
							
							//setting Value of alerts for e.g. disable, sms, email, both
							alert.setLoadCreditAlert("0");
							alert.setLowBalAlert("0");
							alert.setNegativeBalAlert("0");
							alert.setHighAuthAmtAlert("0");
							alert.setDailyBalAlert("0");
							alert.setInsufficientFundAlert("0");
							alert.setCheckIncorrectPINAlert("0");
							alert.setFast50Alert("0");
							alert.setFedTaxRefundAlert("0");
							alert.setLowBalAmt("0.00");
							alert.setHighAuthAmt("0.00");
							alert.setAlertLangId(rs.getString("alert_lang_id"));

						/*	
							alert.setDailyBalBeginTime(rs.getString("A_Dailybal_Begin_time"));
							alert.setDailyBalEndTime(rs.getString("A_Dailybal_End_time"));
						*/	
							if(rs.getString("Mobile_Carrier")!=null && !(rs.getString("Mobile_Carrier").trim().equals(""))){
								smsAlert.setCellPhoneCarrier(rs.getString("Mobile_Carrier"));
								smsAlert.setCarrierCode(rs.getString("carrierCode"));
							}
							else{
								smsAlert.setCellPhoneCarrier(rs.getString("Mobile_Carrier"));
								smsAlert.setCarrierCode(rs.getString("carrierCode"));
								/*smsAlert.setCellPhoneCarrier("Select Phone Carrier");
								smsAlert.setCarrierCode("select");*/
							}
							if(rs.getString("CCM_OPTINOPTOUT_STATUS")!=null && !(rs.getString("CCM_OPTINOPTOUT_STATUS").trim().equals(""))){
								smsAlert.setOptinoptoutstatus(rs.getString("CCM_OPTINOPTOUT_STATUS"));
							}
							smsAlert.setCellPhoneNumber(rs.getString("Mobile_no"));
							if(rs.getString("Email_id_one")!=null && !(rs.getString("Email_id_one").equals(""))){
								smsAlert.setEmailOne(rs.getString("Email_id_one").trim());
							}
							if(rs.getString("Email_id_two")!=null && !(rs.getString("Email_id_two").equals(""))){
								smsAlert.setEmailTwo(rs.getString("Email_id_two").trim());
							}
							
							smsAlert.setAlerts(alert);
							
							return smsAlert;
						}
					};
					smsEmailAlertbean = getSimpleJdbcTemplate().query(sqlQry.toString(), alertmapper,cardNumber);
					List<Alerts> alertList=new ArrayList<Alerts>();
					smsEmailAlert= (SMSEmailAlert) smsEmailAlertbean.get(0);
					alert=smsEmailAlert.getAlerts();
					String qry="select dbms_lob.substr(cps_alert_msg,1,1) flag,cps_alert_id alert_id from cms_appl_pan,CMS_PRODCATG_SMSEMAIL_ALERTS" +
							" where CAP_INST_CODE= CPS_INST_CODE AND CAP_PROD_CODE = CPS_PROD_CODE AND CAP_CARD_TYPE= CPS_CARD_TYPE" +
							" and  cap_pan_code=gethash(?) and cps_alert_lang_id=?";

					final HashMap<String,String> map=new HashMap<String,String>();	
					 ParameterizedRowMapper<Alerts> alertMapper = new ParameterizedRowMapper<Alerts>() {
							public Alerts mapRow(ResultSet rs, int rowNum)
									throws SQLException {
								
								Alerts alert = new Alerts();
								
								map.put(rs.getString("alert_id"), rs.getString("flag"));
							
								return alert;
							}
						};
					
						alertList = getSimpleJdbcTemplate().query(qry,alertMapper,cardNumber,languageID);
					
					if(map.get("9")!=null )	
						alert.setLoadCreditFlag(map.get("9"));
					 if( map.get("10")!=null )
						alert.setLowerBalFlag(map.get("10"));
					 if( map.get("11")!=null )
						alert.setNegtiveBalFlag(map.get("11"));
					 if( map.get("16")!=null )
						alert.setHighAuthFlag(map.get("16"));
					 if( map.get("12")!=null )
						alert.setDailyBalFlag(map.get("12"));
					 if( map.get("17")!=null )
						alert.setInsufficientFundFlag( map.get("17"));
					 if( map.get("13")!=null )
						alert.setIncorrectPINFlag(map.get("13"));
					 if( map.get("21")!=null )
						alert.setFast50Flag(map.get("21"));
					 if( map.get("22")!=null )
						alert.setFedTaxRefundFlag(map.get("22"));
					
					loggerUtil.debug("alert.setLoadCreditFlag"+alert.getLoadCreditFlag());
					loggerUtil.debug("alert.setLowerBalFlag"+alert.getLowerBalFlag());
					loggerUtil.debug("alert.setNegtiveBalFlag"+alert.getNegtiveBalFlag());
					loggerUtil.debug("alert.setHighAuthFlag"+alert.getHighAuthFlag());
					loggerUtil.debug("alert.setDailyBalFlag"+alert.getDailyBalFlag());
					loggerUtil.debug("alert.setInsufficientFundFlag"+alert.getInsufficientFundFlag());
					loggerUtil.debug("alert.setIncorrectPINFlag"+alert.getIncorrectPINFlag());
					loggerUtil.debug("alert.setFast50Flag"+alert.getFast50Flag());
					loggerUtil.debug("alert.setFedTaxRefundFlag"+alert.getFedTaxRefundFlag());
					
					smsEmailAlert.setAlerts(alert);
					smsEmailAlertbean.clear();
					smsEmailAlertbean.add(smsEmailAlert);
					return smsEmailAlertbean.get(0);
					

			}
			else{
				return null;
			}
	}

	@Override
	public SMSEmailAlert alertSettings(SMSEmailAlert bean) throws Exception {//Modified by Dnyaneshwar J on 16 Oct 2013, changed return type
		
		loggerUtil.logMethodEntry("alertSettings");
		
		DateFormat dateFormat=null;
		Date l_date =null;
		CSRUtils csrUtil=null;
		String deliveryChannel="";
		String [] result = new String[3];
		KeyValueBean keyValue=new KeyValueBean();
		String formateddate="";
		String trandate="";
		String trantime="";
		String mbrNumb="";//Added by Dnyaneshwar J on 27 Jun 2012
//		SimpleJdbcCall simpleJdbcCall=null;
		Map <String , Object> out=null;
		
		deliveryChannel=CmsConstants.DELIVERY_CHANNEL;
		
	    csrUtil= new CSRUtils();
//	    csrUtil.setSimpleJdbcTemplate(getSimpleJdbcTemplate());
	    keyValue = csrUtil.getSeqNoForRRNAndStan();
	    
	    keyValue.setRRN(keyValue.getRRN());
	    keyValue.setSTAN(keyValue.getSTAN());
	    
	    mbrNumb=csrUtil.getMemberNumber(bean.getCardNumber());
	    
		dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
	    l_date = new Date();
	    formateddate=dateFormat.format(l_date);
		trandate=formateddate.substring(0, 8);
		trantime=formateddate.substring(8);
		String[] currencyCode=new String[2];
//		csrUtil.setSimpleJdbcTemplate(getSimpleJdbcTemplate());
		String productCardtype=csrUtil.getProdCodeandCardType(bean.getCardNumber());
		Connection con = null;
		CallableStatement cstmt = null;
		try {
			currencyCode = StartOfProcess.curncyDetl.get(productCardtype.substring(0, productCardtype.length())).split(",");
			//currencyCode = StartOfProcess.curncyDetl.get(bean.getCardNumber().substring(0, 6)).split(",");
			con = getDataSource().getConnection();
			cstmt = con.prepareCall("{call vmscms.SP_CSR_SMSANDEMAIL_ALERT(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");//37 arguments
			cstmt.setInt(1,bean.getInstCode() );
			cstmt.setString(2,keyValue.getRRN());
			cstmt.setString(3,null );
			cstmt.setString(4,keyValue.getSTAN() );
			cstmt.setString(5,trandate );
			cstmt.setString(6,trantime );
			cstmt.setString(7,bean.getCardNumber() );
			cstmt.setString(8,NullUtilities.returnBlank(currencyCode[0]) );
			cstmt.setString(9,CmsConstants.TXN_0200_NORMAL_MSG_TYPE );
			cstmt.setString(10,CmsConstants.TXN_CODE_UPDATE_SMS_EMAIL_ALERTS );//Changed by Dnyaneshwar J on 01 Sept 2012 taking txn code from constants
			cstmt.setString(11,CmsConstants.TXN_MODE_OFFLINE );
			cstmt.setString(12,deliveryChannel );
			cstmt.setString(13,mbrNumb );//changed by Dnyaneshwar J on 27 Jun 2012
			cstmt.setString(14,CmsConstants.TXN_NONREVERSAL_CODE );
			cstmt.setString(15,bean.getCellPhoneNumber() );
			cstmt.setInt(16,Integer.parseInt(bean.getCellPhoneCarrier().trim()) );
			cstmt.setString(17,bean.getEmailOne() );
			cstmt.setString(18,bean.getEmailTwo() );
			cstmt.setString(19,bean.getAlerts().getLoadCreditAlert() );
			cstmt.setString(20,bean.getAlerts().getLowBalAlert() );
			cstmt.setString(21,bean.getAlerts().getLowBalAmt() );
			cstmt.setString(22,bean.getAlerts().getNegativeBalAlert() );
			cstmt.setString(23,bean.getAlerts().getHighAuthAmtAlert() );
			cstmt.setString(24,bean.getAlerts().getHighAuthAmt() );
			cstmt.setString(25,bean.getAlerts().getDailyBalAlert() );
			cstmt.setString(26,null);//bean.getAlerts().getDailyBalBeginTime() );//hard coded null value as JIRA fix for FSS-410 (Time  should not set in Daily Balance Alert)
			cstmt.setString(27,null);//bean.getAlerts().getDailyBalEndTime() );//hard coded null value as JIRA fix for FSS-410 (Time  should not set in Daily Balance Alert)
			cstmt.setString(28,bean.getAlerts().getInsufficientFundAlert() );
			cstmt.setString(29,bean.getAlerts().getCheckIncorrectPINAlert() );
			//map.put("prm_c2calert",bean.getAlerts().getC2cAlert());//Added by Dnyaneshwar J on 20 Aug 2013 //Commented By Narsing on 24th Dec 2013 to remove c2c Alert
			cstmt.setString(30,bean.getAlerts().getFast50Alert());//Added by Dnyaneshwar J on 30 Sept 2013
			cstmt.setString(31,bean.getAlerts().getFedTaxRefundAlert());//Added by Dnyaneshwar J on 30 Sept 2013
			cstmt.setString(32,bean.getIpAddress() );//Added by dnyaneshwar J on 26 Dec 2012
			cstmt.setString(33,bean.getInsUser() );
			cstmt.setString(34,bean.getCallId() );
			cstmt.setString(35,"" );
			cstmt.setString(36,bean.getLanguageId());
//			SqlParameterSource in = new MapSqlParameterSource().addValues(map);				
//			out  =  simpleJdbcCall.execute(in);
			cstmt.registerOutParameter(37, Types.VARCHAR);
			cstmt.executeUpdate();
			
			resultSet = cstmt.getString(37);
			
			if(loggerUtil.isDebugEnabled())
			{
			    loggerUtil.debug("RRN  "+keyValue.getRRN());
			    loggerUtil.debug("STAN "+keyValue.getSTAN());
				loggerUtil.debug("trandate "+trandate);
			    loggerUtil.debug("trantime "+trantime);
			    loggerUtil.debug("prm_inst_code         "+bean.getInstCode() );
				loggerUtil.debug("prm_rrn               "+keyValue.getRRN() );
				loggerUtil.debug("prm_terminalid        "+"" );
				loggerUtil.debug("prm_stan              "+keyValue.getSTAN() );
				loggerUtil.debug("prm_tran_date         "+trandate );
				loggerUtil.debug("prm_tran_time         "+trantime );
				loggerUtil.debug("prm_currcode          "+NullUtilities.returnBlank(currencyCode[0])  );
				loggerUtil.debug("prm_msg_type          "+CmsConstants.TXN_0200_NORMAL_MSG_TYPE  );
				loggerUtil.debug("prm_txn_code          "+CmsConstants.TXN_CODE_UPDATE_SMS_EMAIL_ALERTS);
				loggerUtil.debug("prm_txn_mode          "+CmsConstants.TXN_MODE_OFFLINE );
				loggerUtil.debug("prm_delivery_channel  "+deliveryChannel );
				loggerUtil.debug("prm_mbr_numb          "+mbrNumb );//changed by Dnyaneshwar J on 27 Jun 2012
				loggerUtil.debug("prm_rvsl_code         "+CmsConstants.TXN_NONREVERSAL_CODE );
				loggerUtil.debug("prm_cellphoneno       "+bean.getCellPhoneNumber() );
				loggerUtil.debug("prm_cellphonecarrier  "+bean.getCellPhoneCarrier() );
				loggerUtil.debug("prm_emailid1          "+bean.getEmailOne() );
				loggerUtil.debug("prm_emailid2          "+bean.getEmailTwo() );//P_LOADORCREDITALERT
				loggerUtil.debug("prm_loadorcreditalert "+bean.getAlerts().getLoadCreditAlert() );
				loggerUtil.debug("prm_lowbalalert       "+bean.getAlerts().getLowBalAlert() );
				loggerUtil.debug("prm_lowbalamount      "+bean.getAlerts().getLowBalAmt() );
				loggerUtil.debug("prm_negativebalalert  "+bean.getAlerts().getNegativeBalAlert() );
				loggerUtil.debug("prm_highauthamtalert  "+bean.getAlerts().getHighAuthAmtAlert() );
				loggerUtil.debug("prm_highauthamt       "+bean.getAlerts().getHighAuthAmt() );
				loggerUtil.debug("prm_dailybalalert     "+bean.getAlerts().getDailyBalAlert() );
				loggerUtil.debug("prm_begintime         "+"NULL");//bean.getAlerts().getDailyBalBeginTime() );//hard coded null value as JIRA fix for FSS-410 (Time  should not set in Daily Balance Alert)
				loggerUtil.debug("prm_endtime           "+"NULL");//bean.getAlerts().getDailyBalEndTime() );//hard coded null value as JIRA fix for FSS-410 (Time  should not set in Daily Balance Alert)
				loggerUtil.debug("prm_insufficientalert "+bean.getAlerts().getInsufficientFundAlert() );
				loggerUtil.debug("prm_incorrectpinalert "+bean.getAlerts().getCheckIncorrectPINAlert() );
				//loggerUtil.debug("prm_c2calert          "+bean.getAlerts().getC2cAlert());//Added by Dnyaneshwar J on 20 Aug 2013 //Commented By Narsing on 24th Dec 2013 to remove c2c Alert
				loggerUtil.debug("prm_fast50alert       "+bean.getAlerts().getFast50Alert());//Added by Dnyaneshwar J on 30 Sept 2013
				loggerUtil.debug("prm_federalstatealert "+bean.getAlerts().getFedTaxRefundAlert());//Added by Dnyaneshwar J on 30 Sept 2013
				loggerUtil.debug("prm_ipaddress         "+bean.getIpAddress() );//Added by dnyaneshwar J on 26 Dec 2012
				loggerUtil.debug("prm_ins_user          "+bean.getInsUser() );
				loggerUtil.debug("prm_call_id           "+bean.getCallId() );
				loggerUtil.debug("prm_remark            "+"" );
				loggerUtil.debug("PRM_LANG_ID           "+ bean.getLanguageId());
				
			}
			
			
			result[0] = (String) cstmt.getString("PRM_RESP_CODE");
			result[1] = (String) cstmt.getString("PRM_RESP_MSG");
			result[2] = (String) cstmt.getString("PRM_DOUBLEOPTINFLAG");
			
			bean.setRespCode(result[0]);//Added by Dnyaneshwar J on 16 Oct 2013
			bean.setRespMsg(result[1]);//Added by Dnyaneshwar J on 16 Oct 2013
			bean.setDoubleoptinFlag(result[2]);
			if(loggerUtil.isDebugEnabled())
			{
			loggerUtil.debug("result[0] "+result[0]);
			loggerUtil.debug("result[1] "+result[1]);
			loggerUtil.debug("result[2] "+result[2]);
			}
			
			if(result[0]!=null && result[0].equals("00")){
				loggerUtil.logMethodExit("alertSettings "+result[1]);
				bean.setRRN(keyValue.getRRN());
				bean.setBusinessDate(trandate);
				bean.setBusinessTime(trantime);
				bean.setMaskCardNumber(getMaskCard(bean.getCardNumber(), String.valueOf(bean.getInstCode())));
			}
			else{
				loggerUtil.logMethodExit("alertSettings "+result[1]);
			}
			return result;
			
		} catch (Exception e) {
			loggerUtil.error("Error occured while Getting the Profile Currency Code : "+ e);
		}finally {
			if (cstmt != null) {
				cstmt.close();
			}
			if (con != null) {
				con.close();
			}
		}
	    
		//change SP Name and its parameter on 22 Jun 2012
/*		simpleJdbcCall = new SimpleJdbcCall(getDataSource());
		simpleJdbcCall = simpleJdbcCall.withProcedureName("SP_CSR_SMSANDEMAIL_ALERT");
		simpleJdbcCall = simpleJdbcCall.withSchemaName(cmsParameters.getProperty("SCHEMANAME"));*/
		loggerUtil.logCardNumber(bean.getCardNumber());
		
		
		
//	    Map<String,Object> map = new HashMap<String, Object>();
	    
	    
	   		

		
//		return bean;
		
	}

	@Override
	public List<KeyValueBean> getMobileCarrierList() throws Exception {
		loggerUtil.logMethodEntry("getMobileCarrierList");
		List<KeyValueBean> carrierList= null;
		
		String getStatesQuery="select cmm_carrier_code,cmm_carrier_name from cms_mobilecarrier_mast";
		
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("query For getting mobile carrier : "+getStatesQuery);
		}
		
		carrierList = (List<KeyValueBean>) getSimpleJdbcTemplate().query(
				getStatesQuery, new ParameterizedRowMapper<KeyValueBean>() {
					public KeyValueBean  mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						KeyValueBean result= new KeyValueBean();
						if(rs.getString(1).trim().equals("0")){
							result.setKey(rs.getString(1));
							result.setValue("Select");
						}
						result.setKey(rs.getString(1));
						result.setValue(rs.getString(2));
						return result;
					}
		});
		
		return carrierList;
	}

	@Override
	public String validateMobileCarrier(int instCode, String carrierCode) throws Exception {
		loggerUtil.logMethodEntry("validateMobileCarrier");
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("instCode       "+instCode);
			loggerUtil.debug("cntryStateCode "+carrierCode);
		}
		
		CSRUtils csr = new CSRUtils();
		csr.setSimpleJdbcTemplate(getSimpleJdbcTemplate());
		
		if(csr.validateMobileCarrier(instCode,carrierCode).equals(CmsConstants.VALIDATE_INVALID_CHAR)){
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("Code not matching");
			}
			return "invalid";
		}
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("Code matching");
		}
		loggerUtil.logMethodExit("validateMobileCarrier");
		return "valid";
	}

	@Override
	public String getPhoneCarrierName(String instCode, String carrierCode)
			throws Exception {
		loggerUtil.logMethodEntry("getPhoneCarrierName");
		
		String carrierName="";
		StringBuffer sql = new StringBuffer();
		sql.append(" select cmm_carrier_name from cms_mobilecarrier_mast where cmm_carrier_code=? and cmm_inst_code=? ");
		carrierName=getSimpleJdbcTemplate().queryForObject(sql.toString(),String.class,carrierCode,instCode);
		
		if(carrierName!=null && !(carrierName.trim().equals(""))){
			carrierName=carrierName.trim();
			loggerUtil.logMethodExit("getPhoneCarrierName");
			return carrierName;
		}
		else{
			loggerUtil.logMethodExit("getPhoneCarrierName");
			return null;
		}
	}
	
	//Added by Dnyaneshwar J on 16 Oct 2013 to get Mask PAN
	public String getMaskCard(String cardNumber, String instCode)throws Exception {
		loggerUtil.logMethodEntry("getMaskCard");
		
		String maskPan="";
    	String sql="select cap_mask_pan from cms_appl_pan where cap_pan_code=gethash(?) and CAP_INST_CODE=?";
    	if((cardNumber!=null && !("".equals(cardNumber))) && (instCode!=null && !("".equals(instCode)))){
    		maskPan=getSimpleJdbcTemplate().queryForObject(sql,String.class,cardNumber,instCode);
    	}
    	else{
    		loggerUtil.debug("PAN is Null or Inst Code Null");
    	}
    	
		loggerUtil.logMethodExit("getMaskCard");
		return maskPan;
	}

	@Override
	public List<KeyValueBean> getLanguageList(String instCode,String cardNumber) throws Exception {
		loggerUtil.logMethodEntry("getLanguageList");
		List<KeyValueBean> languageList= null;
		
		String getStatesQuery="select distinct vas_alert_lang_id,VAS_ALERT_LANG,cps_defalert_lang_flag from VMS_ALERTS_SUPPORTLANG,cms_appl_pan,cms_prodcatg_smsemail_alerts  " +
				" where cap_pan_code=gethash(?) and CAP_INST_CODE= CPS_INST_CODE AND CAP_PROD_CODE = CPS_PROD_CODE AND CAP_CARD_TYPE= CPS_CARD_TYPE " +
				" and cps_config_flag='Y' and VAS_ALERT_LANG_ID=cps_alert_lang_id";
		
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("query For getting mobile carrier : "+getStatesQuery);
		}
		
		ParameterizedRowMapper<KeyValueBean> mapper = new ParameterizedRowMapper<KeyValueBean>()
		 {
					public KeyValueBean  mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						KeyValueBean result= new KeyValueBean();						
						result.setKey(rs.getString(1)+":"+rs.getString(3));
						result.setValue(rs.getString(2));
						return result;
					}
		};
		languageList = (List<KeyValueBean>) getSimpleJdbcTemplate().query(
				getStatesQuery, mapper,cardNumber);
		
		return languageList;
	}
	
	@Override
	public String customerOptedLanguage(String instCode,String cardNumber) 
			throws Exception {
		loggerUtil.logMethodEntry("customerOptedLanguage");
		
		String optedLang="";
		StringBuffer sql = new StringBuffer();
		sql.append(" SELECT CSA_ALERT_LANG_ID from CMS_SMSANDEMAIL_ALERT where CSA_PAN_CODE = gethash(?) and CSA_INST_CODE=? ");
		optedLang=getSimpleJdbcTemplate().queryForObject(sql.toString(),String.class,cardNumber,instCode);
		
		if(optedLang!=null && !(optedLang.trim().equals(""))){
			optedLang=optedLang.trim();
			loggerUtil.logMethodExit("customerOptedLanguage");
			return optedLang;
		}
		else{
			loggerUtil.logMethodExit("customerOptedLanguage");
			return null;
		}
	}
	
}