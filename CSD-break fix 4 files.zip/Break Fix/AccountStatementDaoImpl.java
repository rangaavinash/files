package com.fss.csr.services.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.fss.csr.cardreplacement.bean.CardReplacement;
import com.fss.csr.common.bean.KeyValueBean;
import com.fss.csr.common.exception.CmsGenException;
import com.fss.csr.common.util.CMSUtils;
import com.fss.csr.common.util.CSRUtils;
import com.fss.csr.common.util.CmsConstants;
import com.fss.csr.common.util.NullUtilities;
import com.fss.csr.common.util.cmsParameters;
import com.fss.csr.common.util.logger.LoggerUtil;
import com.fss.csr.customer.bean.CustomerDetails;
import com.fss.csr.services.bean.AccountStatement;
import com.fss.csr.startup.StartOfProcess;


/**
* 
*==================================================================================================================================
*  Version      Date          Author          Reason
*==================================================================================================================================
*     1.0      02-03-12       Lince J       Initial Version  
*     1.1      09-03-12       Lince J       Add DDA Statement   
*     1.2      19-04-12       Lince J       Change query for Account Statement,add 
*     									    account Type check also.	
*     1.3      09-05-12       Lince J       Add methods forReset Password
*     1.4      18-05-12       Lince J       Add methods for displaying Savings Interest
*     1.5      23-05-12       Abhay R       For Date Format
*     1.6 	   29-05-12       Abhay R       For Calling procedure To Log
*     1.7	   30-05-12		  Dnyaneshwar J user pin set to sp_upgrade_to_personalisedcard as 1
*     1.8	   30-05-12		  Abhay R       For Product & Category description
*     1.9	   22-06-12		  Dnyaneshwar J add merchant parameter to :- SP_UPGRADE_TO_PERSONALISEDCARD
*     										add currcode & revrsCode to :-SP_CUSTOMER_SERVICES_CSR
*     										(with code clean up remove unused imports)
*     2.0 	   27-06-12       Kinjal P      Taking txn code,Reversal code etc from CmsConstant while calling SP
*     2.1      09-07-12       Abhay R       DDA Form Changes As Per CR-008
*     2.2      28-08-12  	  Kinjal P 	    Change made for Checking Debug Flag condition
*     2.3      31-08-12       Lince J		Changes for Fee 
*     2.4      04-09-12       Lince J       Changed query for retrieving account number and email
*     2.5      06-09-12       Lince J       Removed hard coded inst code from Query in Upgrade to Personalized card
*     2.6      12-09-12       Abhay R       For Initial transcation  Caption Query Change
*     2.7      24-09-12       Abhay R		Changes done for amount Format.
*     2.8      25-09-12       Lince J       Add method to get opening and closing balance.
*     2.9      07-10-12       Dnyaneshwar J Add IpAddress Parameter to stored procedure of SP_UPGRADE_TO_PERSONALISEDCARD.
*     3.0      03-11-12       Dnyaneshwar J change the address flag from O to P
*     3.1      18-03-13       Dnyaneshwar J Add method to log userid in transactionlog after calling upgrade_per stored procedure
*     3.2      16-04-13  	  Abhay R       Changes Done For Paper Statement
*     3.3 	   06-05-13       Dnyaneshwar J   Add method to get email id for paperstatement.
*     3.4 	   10-06-13       Dnyaneshwar J modify Spending & Saving statement queries & change msg type code to 0200.
*     3.5 	   08-08-13       Dnyaneshwar J   Add method to get online user name.
*     3.6 	   04-10-13       Dnyaneshwar J   Modify getInterestRate to pass product code LYFEHOST-63
*     3.7 	   16-12-13       Dnyaneshwar J   Modify viewCustomerDetails method to read one new column to get bank name from product level, (JIRA) JH-655.
*     3.8 	   07-02-14       Narsing I       Modified for changing query for getInterestPaid()
*     3.9 	   11-02-14       Narsing I       Modified for changing query for viewCustomerDetails() for DFCCSD-117
*     4.0 	   16-05-14       Dnyaneshwar J  Added method to get APYE value.
*     4.1	   12-09-14		  Ramesh A		 Modified method(getAPYEamount) for getting interest rate and APYE amount for FSS-1830
*     4.2	   29-05-15 	  Siva Kumar 	 Modified   for FSS-3493(Table full scan chages)
*===================================================================================================================================
*This Class is used for Account Statement.
*/
public class AccountStatementDaoImpl extends SimpleJdbcDaoSupport implements AccountStatementDao {
	
	private final LoggerUtil loggerUtil = new LoggerUtil(AccountStatementDaoImpl.class);
		
public List<AccountStatement> viewCustomerDetails(String cardNumber) throws CmsGenException {

	  loggerUtil.logMethodEntry("viewCustomerDetails");
      List<AccountStatement> accntStmnt=new ArrayList<AccountStatement>();
      try {
	      StringBuffer viewCustomerDetails = new StringBuffer();
	     /* viewCustomerDetails.append(" SELECT fn_getmaskpan(fn_dmaps_main(cap_pan_code_encr)) cardnumber,ccm_first_name firstname, ");
	      viewCustomerDetails.append(" ccm_last_name lastname,TO_CHAR (NVL (cam_acct_bal, 0), '"+CMSUtils.AMTFORMAT+"') availablebalance, ");
	      viewCustomerDetails.append(" cpm_prod_desc CARDTYPE,cpc_cardtype_desc   PRODCATAGORY,cam_acct_no, ");//abhay change for product & category
	      viewCustomerDetails.append(" cam_add_one Mailaddress1,cam_add_two Mailaddress2, ");
	      viewCustomerDetails.append(" (SELECT UPPER (gsm_state_name) FROM gen_state_mast WHERE gsm_inst_code = addr.cam_inst_code ");
	      viewCustomerDetails.append(" AND gsm_state_code = cam_state_code AND gsm_cntry_code = cam_cntry_code) Mailstate, ");
	      viewCustomerDetails.append(" cam_pin_code Mailzip,(SELECT UPPER (gcm_cntry_name) FROM gen_cntry_mast");
	      viewCustomerDetails.append(" WHERE gcm_inst_code = addr.cam_inst_code AND gcm_cntry_code = cam_cntry_code) Mailcountry, ");
	      viewCustomerDetails.append(" cam_email emailaddress, addr.cam_city_name Mailcity,(select GCM_CURR_NAME from gen_curr_mast ");
	      viewCustomerDetails.append(" where gcm_inst_code = CBP_INST_CODE and GCM_CURR_CODE = cbp_param_value) Currency,CPC_ROUT_NUM routingNumber ");
	      viewCustomerDetails.append(" ,cap_prod_code ");//Added by Dnyaneshwar J on 04 Oct 2013
	      viewCustomerDetails.append(" ,nvl(CPC_ISSU_BANK,'Bancorp') CPC_ISSU_BANK ");//Added by Dnyaneshwar J on 16 Dec 2013
	      viewCustomerDetails.append(" ,CPC_STATEMENT_FOOTER,CPC_INSTITUTION_ID INSTID,CPC_TRANSIT_NUMBER TRANSITNO,");
	      viewCustomerDetails.append(" CAP_PROXY_NUMBER PROXYNUMBER,CIM_INTERCHANGE_NAME,CIM_INTERCHANGE_CODE,CPC_ISSU_BANK_ADDR , ");//Added by Narsing  I on 10th Feb 2014
	      viewCustomerDetails.append(" CPM_STATEMENT_FOOTER1,CPM_STATEMENT_FOOTER2,CPM_STATEMENT_FOOTER3,CPM_STATEMENT_FOOTER4,CPM_STATEMENT_FOOTER5");	
	      viewCustomerDetails.append(" FROM cms_appl_pan,cms_cust_mast cust,cms_acct_mast acct,cms_addr_mast addr, ");
	      viewCustomerDetails.append(" cms_cardissuance_status,cms_prod_cattype cattype,cms_prod_catg catg,cms_prod_mast,cms_bin_param,cms_interchange_mast ");
	      viewCustomerDetails.append(" where cbp_param_name = 'Currency' AND cap_pan_code = gethash (?) ");
	      viewCustomerDetails.append(" AND CAM_ADDR_FLAG = 'P' ");//Changed by Dnyaneshwar J on 03 Nov 2012
	      viewCustomerDetails.append(" AND cap_inst_code = cust.ccm_inst_code  AND cap_cust_code = cust.ccm_cust_code ");
	      viewCustomerDetails.append(" AND cap_inst_code = acct.cam_inst_code  AND cap_acct_id  = acct.cam_acct_id ");
	      viewCustomerDetails.append(" AND addr.cam_cust_code = ccm_cust_code  AND addr.cam_inst_code = ccm_inst_code ");
	      viewCustomerDetails.append(" AND cap_inst_code = ccs_inst_code   AND cap_pan_code = ccs_pan_code ");
	      viewCustomerDetails.append(" AND cap_inst_code = cattype.cpc_inst_code AND cap_prod_code = cattype.cpc_prod_code");
	      viewCustomerDetails.append(" AND cap_card_type = cattype.cpc_card_type AND cap_inst_code = catg.cpc_inst_code ");
	      viewCustomerDetails.append(" AND cap_prod_catg = catg.cpc_catg_code and  cap_inst_code = cbp_inst_code ");  modified for table full scan chages..
	      viewCustomerDetails.append(" AND cpm_inst_code = cbp_inst_code AND cap_prod_code = cpm_prod_code ");
	      viewCustomerDetails.append(" AND cpm_profile_code = cbp_profile_code ");
	      viewCustomerDetails.append(" AND cap_prod_catg = catg.cpc_catg_code and   cpm_inst_code = cap_inst_code ");
	      viewCustomerDetails.append(" AND cpm_prod_code = cap_prod_code AND cbp_inst_code = cpm_inst_code ");
	      viewCustomerDetails.append(" AND cbp_profile_code = cpC_profile_code ");
	      viewCustomerDetails.append(" AND CIM_INST_CODE = cpm_inst_code AND CIM_INTERCHANGE_CODE=CPM_INTERCHANGE_CODE ");*/
	      
	      viewCustomerDetails.append(" SELECT fn_getmaskpan(fn_dmaps_main(cap_pan_code_encr)) cardnumber,Decode(cattype.cpc_encrypt_enable,'Y',Fn_Dmaps_Main( ccm_first_name),ccm_first_name ) firstname, ");
	      viewCustomerDetails.append(" Decode(cattype.cpc_encrypt_enable,'Y',Fn_Dmaps_Main( ccm_last_name),ccm_last_name ) lastname,TO_CHAR (NVL (cam_acct_bal, 0), '"+CMSUtils.AMTFORMAT+"') availablebalance, ");
	      viewCustomerDetails.append(" cpm_prod_desc CARDTYPE,cpc_cardtype_desc   PRODCATAGORY,cam_acct_no, ");//abhay change for product & category
	      viewCustomerDetails.append(" Decode(cattype.cpc_encrypt_enable,'Y',Fn_Dmaps_Main( cam_add_one),cam_add_one ) Mailaddress1,Decode(cattype.cpc_encrypt_enable,'Y',Fn_Dmaps_Main( cam_add_two),cam_add_two ) Mailaddress2, ");
	      viewCustomerDetails.append(" (SELECT UPPER (gsm_state_name) FROM gen_state_mast WHERE gsm_inst_code = addr.cam_inst_code ");
	      viewCustomerDetails.append(" AND gsm_state_code = cam_state_code AND gsm_cntry_code = cam_cntry_code) Mailstate, ");
	      viewCustomerDetails.append(" Decode(cattype.cpc_encrypt_enable,'Y',Fn_Dmaps_Main( cam_pin_code),cam_pin_code ) Mailzip,(SELECT UPPER (gcm_cntry_name) FROM gen_cntry_mast");
	      viewCustomerDetails.append(" WHERE gcm_inst_code = addr.cam_inst_code AND gcm_cntry_code = cam_cntry_code) Mailcountry, ");
	      viewCustomerDetails.append(" Decode(cattype.cpc_encrypt_enable,'Y',Fn_Dmaps_Main( cam_email),cam_email ) emailaddress,Decode(cattype.cpc_encrypt_enable,'Y',Fn_Dmaps_Main(  addr.cam_city_name), addr.cam_city_name ) Mailcity,(select GCM_CURR_NAME from gen_curr_mast ");
	      viewCustomerDetails.append(" where gcm_inst_code = CBP_INST_CODE and GCM_CURR_CODE = cbp_param_value) Currency,CPC_ROUT_NUM routingNumber ");
	      viewCustomerDetails.append(" ,cap_prod_code ");//Added by Dnyaneshwar J on 04 Oct 2013
	      viewCustomerDetails.append(" ,nvl(CPC_ISSU_BANK,'Bancorp') CPC_ISSU_BANK ");//Added by Dnyaneshwar J on 16 Dec 2013
	      viewCustomerDetails.append(" ,CPC_STATEMENT_FOOTER,CPC_INSTITUTION_ID INSTID,CPC_TRANSIT_NUMBER TRANSITNO,");
	      viewCustomerDetails.append(" CAP_PROXY_NUMBER PROXYNUMBER,CIM_INTERCHANGE_NAME,CIM_INTERCHANGE_CODE,CPC_ISSU_BANK_ADDR , ");//Added by Narsing  I on 10th Feb 2014
	      viewCustomerDetails.append(" CPM_STATEMENT_FOOTER1,CPM_STATEMENT_FOOTER2,CPM_STATEMENT_FOOTER3,CPM_STATEMENT_FOOTER4,CPM_STATEMENT_FOOTER5");	
	      viewCustomerDetails.append(" FROM cms_appl_pan,cms_cust_mast cust,cms_acct_mast acct,cms_addr_mast addr, ");
	      viewCustomerDetails.append(" cms_cardissuance_status,cms_prod_cattype cattype,cms_prod_catg catg,cms_prod_mast,cms_bin_param,cms_interchange_mast ");
	      viewCustomerDetails.append(" where cbp_param_name = 'Currency' AND cap_pan_code = gethash (?) ");
	      viewCustomerDetails.append(" AND CAM_ADDR_FLAG = 'P' ");//Changed by Dnyaneshwar J on 03 Nov 2012
	      viewCustomerDetails.append(" AND cap_inst_code = cust.ccm_inst_code  AND cap_cust_code = cust.ccm_cust_code ");
	      viewCustomerDetails.append(" AND cap_inst_code = acct.cam_inst_code  AND cap_acct_id  = acct.cam_acct_id ");
	      viewCustomerDetails.append(" AND addr.cam_cust_code = ccm_cust_code  AND addr.cam_inst_code = ccm_inst_code ");
	      viewCustomerDetails.append(" AND cap_inst_code = ccs_inst_code   AND cap_pan_code = ccs_pan_code ");
	      viewCustomerDetails.append(" AND cap_inst_code = cattype.cpc_inst_code AND cap_prod_code = cattype.cpc_prod_code");
	      viewCustomerDetails.append(" AND cap_card_type = cattype.cpc_card_type AND cap_inst_code = catg.cpc_inst_code ");
        /* viewCustomerDetails.append("  and  cap_inst_code = cbp_inst_code ");  //modified for table full scan chages..
	      viewCustomerDetails.append("  and  cap_prod_code = cpm_prod_code ");
	      viewCustomerDetails.append(" AND cpm_profile_code = cbp_profile_code ");*/
	      viewCustomerDetails.append(" AND cap_prod_catg = catg.cpc_catg_code and   cpm_inst_code = cap_inst_code ");
	      viewCustomerDetails.append(" AND cpm_prod_code = cap_prod_code AND cbp_inst_code = cpm_inst_code ");
	      viewCustomerDetails.append(" AND cbp_profile_code = cpC_profile_code ");
	      viewCustomerDetails.append(" AND CIM_INST_CODE = cpm_inst_code AND CIM_INTERCHANGE_CODE=CPM_INTERCHANGE_CODE ");
	     
	      if(loggerUtil.isDebugEnabled())
			{     
	    	  	loggerUtil.debug("Query in Account Statement for viewCustomerDetails====  "+ viewCustomerDetails);
			}
			ParameterizedRowMapper<AccountStatement> mapper = new ParameterizedRowMapper<AccountStatement>() {
				public AccountStatement mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					AccountStatement accountStatement=new AccountStatement();
					String availableBalance=rs.getString("availablebalance");
					String cardnumber=rs.getString("cardnumber");
					String firstname=rs.getString("firstname");
					String lastname=rs.getString("lastname");
					String emailaddress=rs.getString("emailaddress");
					String accountno=rs.getString("cam_acct_no");
					String Mailstate=rs.getString("Mailstate");
					String Mailcity=rs.getString("Mailcity");
					String Mailcountry=rs.getString("Mailcountry");
					String cardType=rs.getString("CARDTYPE");
					String prodCategory=rs.getString("PRODCATAGORY");
					String mailZip=rs.getString("Mailzip");
					String mailAddr1=rs.getString("Mailaddress1");
					String mailAddr2=rs.getString("Mailaddress2");
					String currency=rs.getString("Currency");
					String bankRoutingNo=rs.getString("routingNumber");
					String prodCode=rs.getString("cap_prod_code");//Added by Dnyaneshwar J on 04 Oct 2013
					String issueBank=rs.getString("CPC_ISSU_BANK");//Added by Dnyaneshwar J on 16 Dec 2013					
					String bankAccountDetail=rs.getString("CPC_STATEMENT_FOOTER");//Added by Narsing  I on 10th Feb 2014
										
					//Added for MVCSD-5596
					String institutionId=rs.getString("INSTID");
					String transitNumber=rs.getString("TRANSITNO");
					String proxyNumber=rs.getString("PROXYNUMBER");					
					String interChangeName=rs.getString("CIM_INTERCHANGE_NAME");
					String interChangeCode=rs.getString("CIM_INTERCHANGE_CODE");
					String issueBankAddress=rs.getString("CPC_ISSU_BANK_ADDR");
					
					String footerStmtOne = rs.getString("CPM_STATEMENT_FOOTER1");
					String footerStmtTwo = rs.getString("CPM_STATEMENT_FOOTER2");
					String footerStmtThree = rs.getString("CPM_STATEMENT_FOOTER3");
					String footerStmtFour = rs.getString("CPM_STATEMENT_FOOTER4");
					String footerStmtFive = rs.getString("CPM_STATEMENT_FOOTER5");
					
					if(availableBalance!=null)
						accountStatement.setAvailableBalance(availableBalance);
					if(cardnumber!=null)
						accountStatement.setPanNumber(cardnumber);
					if(firstname!=null)
						accountStatement.setFirstName(firstname.toUpperCase().trim());
					if(lastname!=null)
						accountStatement.setLastName(lastname.toUpperCase().trim());
					if(emailaddress!=null)
						accountStatement.setEmail(emailaddress);
					if(accountno!=null)
						accountStatement.setAccountNumber(accountno);
					if(Mailstate!=null)
						accountStatement.setState(Mailstate.toUpperCase());
					if(Mailcity!=null)
						accountStatement.setCity(Mailcity.toUpperCase());
					if(Mailcountry!=null)
						accountStatement.setCountry(Mailcountry.toUpperCase());
					if(cardType!=null)
						accountStatement.setCardType(cardType.toUpperCase());
					if(prodCategory!=null)
						accountStatement.setProductCategory(prodCategory.toUpperCase());
					if(mailZip!=null)
						accountStatement.setZip(mailZip);
					if(mailAddr1!=null)
						accountStatement.setAddress1(mailAddr1.toUpperCase());
					if(mailAddr2!=null)
						accountStatement.setAddress2(mailAddr2.toUpperCase());
						accountStatement.setCurrency(currency.toUpperCase());
					if(bankRoutingNo!=null)
						accountStatement.setBankRoutingNo(bankRoutingNo.trim());
					if(prodCode!=null)//Added by Dnyaneshwar J on 04 Oct 2013
						accountStatement.setProdCode(prodCode);//Added by Dnyaneshwar J on 04 Oct 2013
					if(issueBank!=null){//Added by Dnyaneshwar J on 16 Dec 2013
						accountStatement.setIssueBankName(issueBank);//Added by Dnyaneshwar J on 04 Dec 2013
					}else{
						accountStatement.setIssueBankName("");
					}
					if(bankAccountDetail!=null)//Added by Dnyaneshwar J on 16 Dec 2013
						accountStatement.setBankAcctDetail(bankAccountDetail);//Added by Narsing  I on 10th Feb 2014
					if(institutionId!=null)
						accountStatement.setInstitutionId(institutionId);
					if(transitNumber!=null)
						accountStatement.setTransitNumber(transitNumber);
					if(proxyNumber!=null){
						accountStatement.setProxyNumber(proxyNumber);
					}else{
						accountStatement.setProxyNumber("");
					}
					if(interChangeName!=null)					
						accountStatement.setInterChangeName(interChangeName);					
					if(interChangeCode!=null)					
						accountStatement.setInterChangeCode(interChangeCode);
					if(issueBankAddress!=null){
						accountStatement.setIssueBankAddress(issueBankAddress);
					}else{
						accountStatement.setIssueBankAddress("");
					}
					
					if(footerStmtOne != null){
						accountStatement.setFooterStmtOne(footerStmtOne);
					} else{
						accountStatement.setFooterStmtOne("");
					}
					
					
					if(footerStmtTwo != null){
						accountStatement.setFooterStmtTwo(footerStmtTwo);
					} else{
						accountStatement.setFooterStmtTwo("");
					}
					
					if(footerStmtThree != null){
						accountStatement.setFooterStmtThree(footerStmtThree);
					} else{
						accountStatement.setFooterStmtThree("");
					}
					
					if(footerStmtFour != null){
						accountStatement.setFooterStmtFour(footerStmtFour);
					} else{
						accountStatement.setFooterStmtFour("");
					}
					
					if(footerStmtFive != null){
						accountStatement.setFooterStmtFive(footerStmtFive);
					} else{
						accountStatement.setFooterStmtFive("");
					}
					
					return accountStatement;
				}
				};
				accntStmnt=getSimpleJdbcTemplate().query(viewCustomerDetails.toString(), mapper,cardNumber);
      }
      catch (Exception e) {
    	  e.printStackTrace();
	  }
      loggerUtil.logMethodExit("viewCustomerDetails");
      return accntStmnt;
      
	}
	
public List<AccountStatement> getTxnStatement(AccountStatement accountStatement)
	throws CmsGenException {
		
      loggerUtil.logMethodEntry("getTxnStatement");
      
      List<AccountStatement> list = new ArrayList<AccountStatement>();
     
      try {
	      //StringBuffer genAccntStatement = new StringBuffer();
    	  StringBuilder genAccntStatement = new StringBuilder();
	      /* genAccntStatement.append(" SELECT  TO_CHAR (NVL (CSL_OPENING_BAL, 0), '"+CMSUtils.AMTFORMAT+"') CSL_OPENING_BAL,");
	      genAccntStatement.append(" TO_CHAR (NVL (CSL_TRANS_AMOUNT, 0), '"+CMSUtils.AMTFORMAT+"') CSL_TRANS_AMOUNT, ");
	      genAccntStatement.append(" CSL_TRANS_TYPE,CSL_TRANS_DATE,TO_CHAR (NVL (CSL_CLOSING_BALANCE, 0), '"+CMSUtils.AMTFORMAT+"') CSL_CLOSING_BALANCE, ");
	   //   genAccntStatement.append(" initcap(CSL_TRANS_NARRRATION) CSL_TRANS_NARRRATION,CSL_RRN, ");
	      genAccntStatement.append(" initcap(substr(replace(upper(CSL_TRANS_NARRRATION),'CLAWBACK-'), "
	      		+ "0,INSTR(replace(upper(CSL_TRANS_NARRRATION),'CLAWBACK-'), ' - ', -1)-1)) || decode(upper(substr(CSL_TRANS_NARRRATION,1,9)),'CLAWBACK-',(select initcap(decode(CPP_CLAWBACK_DESC,null,'',' - '|| CPP_CLAWBACK_DESC)) from CMS_PRODUCT_PARAM WHERE cpp_prod_code=csl_prod_code)"
	      		+ "|| substr(CSL_TRANS_NARRRATION,INSTR(CSL_TRANS_NARRRATION, ' - ', -1),length(CSL_TRANS_NARRRATION)), substr(CSL_TRANS_NARRRATION,INSTR(CSL_TRANS_NARRRATION, ' - ', -1),length(CSL_TRANS_NARRRATION))) CSL_TRANS_NARRRATION ,CSL_RRN,  ");
	      genAccntStatement.append(" to_char(TO_DATE (CSL_BUSINESS_DATE, 'yyyymmdd'),'"+CMSUtils.DATEFORMAT+"') TxnDate, ");
	      genAccntStatement.append(" to_char(TO_DATE (CSL_BUSINESS_TIME, 'hh24:mi:ss'),'hh24:mi:ss') TxnTime ");
	      genAccntStatement.append(" ,DECODE(TXN_FEE_FLAG,'Y','02','N','01','00') TXNORDER ");//added by Dnyaneshwar J on 10 June 2013
	      genAccntStatement.append(" ,txn_fee_flag ");
	      genAccntStatement.append(" FROM cms_statements_log,cms_acct_mast WHERE CSL_INST_CODE= ? ");
	      genAccntStatement.append(" AND csl_inst_code = cam_inst_code AND csl_acct_no = cam_acct_no  AND cam_type_code = '1' ");
	     // genAccntStatement.append(" AND TO_CHAR(to_date(CSL_BUSINESS_DATE,'yyyymmdd'),'YYYYMM') >= ? ");//Commented by Dnyaneshwar J on 05 June 2013
	      //genAccntStatement.append(" AND TO_CHAR(to_date(CSL_BUSINESS_DATE,'yyyymmdd'),'YYYYMM') <= ? ");//Commented by Dnyaneshwar J on 05 June 2013
	      genAccntStatement.append(" AND TO_CHAR(csl_Ins_Date,'YYYYMM') >= ? ");//Added by Dnyaneshwar J on 05 June 2013
	      genAccntStatement.append(" AND TO_CHAR(csl_Ins_Date,'YYYYMM') <= ? ");//Added by Dnyaneshwar J on 05 June 2013
	      genAccntStatement.append(" AND csl_acct_no=?  ");
	      genAccntStatement.append(" order by  csl_ins_date,TXNORDER");//added TXNORDER by Dnyaneshwar J on 10 June 2013
	      
	      */
	      genAccntStatement.append("  SELECT TO_CHAR (NVL (CSL_OPENING_BAL, 0), '9,999,999,990.99') CSL_OPENING_BAL,TO_CHAR (NVL (CSL_TRANS_AMOUNT, 0), '9,999,999,990.99') CSL_TRANS_AMOUNT,CSL_TRANS_TYPE,CSL_TRANS_DATE,TO_CHAR (NVL (CSL_CLOSING_BALANCE, 0), '9,999,999,990.99') CSL_CLOSING_BALANCE,");
	      
	      genAccntStatement.append("  CASE   WHEN ( (csl_delivery_channel IN ('10', '07') AND csl_txn_code         = '07') OR (csl_delivery_channel = '13' AND csl_txn_code         = '13') OR (csl_delivery_channel = '03' AND csl_txn_code         = '39')) and TXN_FEE_FLAG ='N' ");
	      genAccntStatement.append(" AND UPPER(CSL_TRANS_NARRRATION)  LIKE '%RVSL%' THEN 'RVSL-CARD TO CARD TRANSFER ' || CASE WHEN csl_trans_type='CR' then ' to '   else ' from ' end ");
	      genAccntStatement.append(" || (select vmscms.fn_dmaps_main(ccm_first_name)||' '||vmscms.fn_dmaps_main(ccm_last_name) from vmscms.cms_cust_mast where ccm_inst_code=csl_inst_code  and ccm_cust_code=(select cap_cust_code from vmscms.cms_appl_pan ");
	      genAccntStatement.append(" where cap_inst_code=csl_inst_code and cap_mbr_numb='000' and cap_pan_code=( (select  CASE WHEN  csl_trans_type='CR' then TOPUP_CARD_NO else CUSTOMER_CARD_NO end ");
	      genAccntStatement.append(" from vmscms.transactionlog where    CSL_DELIVERY_CHANNEL = DELIVERY_CHANNEL AND  CSL_TXN_CODE       = TXN_CODE AND  CSL_RRN            = RRN AND  CSL_AUTH_ID        = AUTH_ID AND  CSL_INST_CODE      = INSTCODE and response_code='00' ))) ) ");
	      genAccntStatement.append(" WHEN ((csl_delivery_channel IN ('10', '07') AND csl_txn_code         = '07') OR (csl_delivery_channel = '13' AND csl_txn_code         = '13') OR (csl_delivery_channel = '03' AND csl_txn_code         = '39')) and TXN_FEE_FLAG ='N'   THEN ");
	      genAccntStatement.append(" 'CARD TO CARD TRANSFER ' || CASE WHEN csl_trans_type='DR' then ' to ' else ' from ' end || (select vmscms.fn_dmaps_main(ccm_first_name)||' '||vmscms.fn_dmaps_main(ccm_last_name) from vmscms.cms_cust_mast ");
	      genAccntStatement.append(" where ccm_inst_code=csl_inst_code and ccm_cust_code=(select cap_cust_code from vmscms.cms_appl_pan where cap_inst_code=csl_inst_code and cap_mbr_numb='000' and cap_pan_code=((select CASE WHEN csl_trans_type='DR' then TOPUP_CARD_NO else CUSTOMER_CARD_NO  end ");
	      genAccntStatement.append(" from vmscms.transactionlog where   CSL_DELIVERY_CHANNEL = DELIVERY_CHANNEL AND  CSL_TXN_CODE       = TXN_CODE AND  CSL_RRN            = RRN AND  CSL_AUTH_ID        = AUTH_ID AND  CSL_INST_CODE      = INSTCODE and response_code='00' ) )) ) ");
	      genAccntStatement.append(" WHEN ((csl_delivery_channel='11' and csl_txn_code in('22','27','32','37') ) or (csl_delivery_channel='03' and csl_txn_code='93')) and TXN_FEE_FLAG ='N'  THEN ");
	      genAccntStatement.append(" decode(csl_txn_code,'22','Direct Deposit ','27','DEBIT FOR CHECKING ACCOUNT ','32','CREDIT FOR SAVINGS ACCOUNT ','37','DEBIT FOR SAVINGS ACCOUNT ','Direct Deposit ') ||' from /'|| NVL(COMPANYNAME,'') ||'/ ' || NVL(COMPENTRYDESC,'') || '/ '||NVL(INDIDNUM,'') || '/ to ' ||INDNAME ");
	      genAccntStatement.append(" WHEN ((csl_delivery_channel='02' and csl_txn_code='37') OR (csl_delivery_channel='02' and csl_txn_code='12' AND    UPPER(trans_desc) LIKE 'MONEYSEND FUNDING%'))  and TXN_FEE_FLAG ='N'  THEN  ");
	      genAccntStatement.append(" CASE WHEN UPPER( CSL_TRANS_NARRRATION)  LIKE '%RVSL%' THEN 'RVSL-' ELSE '' END   || 'Money Send Payment ' || DECODE ( csl_txn_code,'37',' from ', ' to ') ");
	      genAccntStatement.append(" || NVL ( MERCHANT_NAME,'') ||'/' || NVL ( merchant_street,'') ||'/' || NVL ( MERCHANT_CITY,'') ||'/' || NVL ( MERCHANT_STATE,'') ||'/' || NVL ( MERCHANT_ID,'') ||'/' || ( SELECT nvl(cpi_payer_id,'') FROM vmscms.cms_payment_info WHERE CPI_INST_CODE=csl_inst_code AND cpi_RRN        =csl_RRN AND cpi_auth_id        =csl_auth_id AND CPI_PAN_CODE   =csl_PAN_no)   ");
	      genAccntStatement.append("  WHEN csl_delivery_channel IN ('01','02') AND TXN_FEE_FLAG = 'N' THEN DECODE(nvl(regexp_instr(csl_trans_narrration,'RVSL-',1,1,0,'i'),0),0,TRANS_DESC,'RVSL-'||TRANS_DESC)||'/'||DECODE(nvl(merchant_name,CSL_MERCHANT_NAME), NULL, DECODE(delivery_channel, '01', 'ATM', '02', 'Retail Merchant'), nvl(merchant_name,CSL_MERCHANT_NAME) || '/' || terminal_id || '/' || merchant_street || '/' || merchant_city || '/' || merchant_state || '/' || preauthamount || '/' ||business_date ||'/' ||auth_id)    ");
		  genAccntStatement.append("     else   ");
	      
	      genAccntStatement.append("initcap(SUBSTR(REPLACE(upper(CSL_TRANS_NARRRATION),'CLAWBACK-'), 0,INSTR(REPLACE(upper(CSL_TRANS_NARRRATION),'CLAWBACK-'), ' - ', -1)-1)) ");
	      genAccntStatement.append("|| DECODE(upper(SUBSTR(CSL_TRANS_NARRRATION,1,9)),'CLAWBACK-', ");
	      genAccntStatement.append("(SELECT initcap(DECODE(CPP_CLAWBACK_DESC,NULL,'',' - ' ");
	      genAccntStatement.append("|| CPP_CLAWBACK_DESC)) ");
	      genAccntStatement.append("	FROM CMS_PRODUCT_PARAM   WHERE cpp_prod_code=csl_prod_code and cpp_inst_code=csl_inst_code ) ");
	      genAccntStatement.append("|| SUBSTR(CSL_TRANS_NARRRATION,INSTR(CSL_TRANS_NARRRATION, ' - ', -1),LENGTH(CSL_TRANS_NARRRATION)), SUBSTR(CSL_TRANS_NARRRATION,INSTR(CSL_TRANS_NARRRATION, ' - ', -1),LENGTH(CSL_TRANS_NARRRATION))) end CSL_TRANS_NARRRATION ,CSL_RRN, ");
	      genAccntStatement.append("TO_CHAR(TO_DATE (CSL_BUSINESS_DATE, 'yyyymmdd'),'mm/dd/yyyy') TxnDate, ");
	      genAccntStatement.append(" TO_CHAR(TO_DATE (CSL_BUSINESS_TIME, 'hh24:mi:ss'),'hh24:mi:ss') TxnTime , ");
	      genAccntStatement.append(" DECODE(TXN_FEE_FLAG,'Y','02','N','01','00') TXNORDER , txn_fee_flag ");
	      genAccntStatement.append(" FROM cms_statements_log,cms_acct_mast,transactionlog    WHERE CSL_INST_CODE= ?    AND csl_inst_code = cam_inst_code ");
	      genAccntStatement.append("  AND csl_acct_no = cam_acct_no   AND CSL_INST_CODE  = INSTCODE(+) ");
	      genAccntStatement.append("  AND TO_CHAR(csl_Ins_Date,'YYYYMM') >= ? AND TO_CHAR(csl_Ins_Date,'YYYYMM') <= ? AND csl_acct_no   =? ");
	      genAccntStatement.append(" AND CSL_DELIVERY_CHANNEL   = DELIVERY_CHANNEL(+)  AND CSL_TXN_CODE   = TXN_CODE(+) ");
	      genAccntStatement.append(" AND CSL_RRN  = RRN(+)  and csl_auth_id=auth_id(+) order by  csl_ins_date,TXNORDER ");
	      
	     	    	      
	      //System.out.println("Query for genAccntStatement==== " + genAccntStatement);
	      if(loggerUtil.isDebugEnabled())
			{
		      loggerUtil.debug("Query for genAccntStatement==== " + genAccntStatement.toString());
		      loggerUtil.debug("getYear To----> "+accountStatement.getYear()+accountStatement.getMonth());
		      loggerUtil.debug("getYear From----> "+accountStatement.getToYear()+accountStatement.getToMonth());
			}
				ParameterizedRowMapper<AccountStatement> mapper = new ParameterizedRowMapper<AccountStatement>() {
					public AccountStatement mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						
						AccountStatement acntStatement=new AccountStatement();
						
						acntStatement.setTxnAmount(rs.getString("CSL_TRANS_AMOUNT").trim());
						acntStatement.setTxnType(rs.getString("CSL_TRANS_TYPE"));
						String type=rs.getString("CSL_TRANS_TYPE");
						if("CR".equalsIgnoreCase(type))
						{
							acntStatement.setCrTxnAmt("+"+CmsConstants.CURRENCY_SYMBOL+rs.getString("CSL_TRANS_AMOUNT").trim());
						}else{
							acntStatement.setDrTxnAmt("-"+CmsConstants.CURRENCY_SYMBOL+rs.getString("CSL_TRANS_AMOUNT").trim());
						}
						
						acntStatement.setTxnTime(rs.getString("TxnTime"));
						String txnDesc=rs.getString("CSL_TRANS_NARRRATION");
						/*if(txnDesc != null && txnDesc.length()>40){
							txnDesc.trim();
							txnDesc=txnDesc.substring(0,40);
						}*/
						
							try {
							final String[] words = txnDesc.split("\\s+");
							final StringBuilder sb = new StringBuilder();
							for (String w : words) {
							  if (w != null && w.length() > 1) {
								String first = w.substring(0, 1);
								String afterfirst = w.substring(1);
								if (first != null) {
									sb.append(first.toUpperCase());
								}else{
									sb.append(" ");
								}
								if (afterfirst != null) {
									sb.append(afterfirst.toLowerCase());
									sb.append(" ");
								}else{
									sb.append(" ");
								}
								}
							}
							txnDesc = sb.toString().trim();
						} catch (Exception ex) {
							loggerUtil.error("Exception while formatting transaction description----->>>"+ ex);
						}
									
						acntStatement.setTxnDescription(txnDesc);
						acntStatement.setTxnDate(rs.getString("TxnDate"));
						acntStatement.setOpeningBalance(rs.getString("CSL_OPENING_BAL").trim());
						acntStatement.setClosingBalance(CmsConstants.CURRENCY_SYMBOL+rs.getString("CSL_CLOSING_BALANCE").trim());															
						acntStatement.setFeeFlag(rs.getString("txn_fee_flag"));											
						
						return acntStatement;
					}};
					list = getSimpleJdbcTemplate().query(genAccntStatement.toString(), mapper,accountStatement.getInstCode(),
							accountStatement.getYear()+accountStatement.getMonth(),accountStatement.getToYear()+accountStatement.getToMonth()
							,accountStatement.getAccountNumber());
					if (list != null) {
						if(loggerUtil.isDebugEnabled())
						{
							loggerUtil.debug("No of Rows returns from getTxnStatement "+list.size());
						}
					}
	     }
      catch (Exception e) {
		//e.printStackTrace();
		loggerUtil.error("Exception while getting transaction details----->>>>>> "+ e);
	    }
      loggerUtil.logMethodExit("getTxnStatement");
      return list;
    }


@Override
public List<AccountStatement> getSavingTxnStatement(AccountStatement accountStatement) throws CmsGenException{
	
  loggerUtil.logMethodEntry("getTxnSavingsStatement");
  
  List<AccountStatement> list = new ArrayList<AccountStatement>();
  try {
      StringBuffer genAccntStatement = new StringBuffer();
      genAccntStatement.append(" SELECT  TO_CHAR (NVL (CSL_OPENING_BAL, 0), '"+CMSUtils.AMTFORMAT+"') CSL_OPENING_BAL,");
      genAccntStatement.append(" TO_CHAR (NVL (CSL_TRANS_AMOUNT, 0), '"+CMSUtils.AMTFORMAT+"') CSL_TRANS_AMOUNT, ");
      genAccntStatement.append(" CSL_TRANS_TYPE,CSL_TRANS_DATE,TO_CHAR (NVL (CSL_CLOSING_BALANCE, 0), '"+CMSUtils.AMTFORMAT+"') CSL_CLOSING_BALANCE, ");
   //   genAccntStatement.append(" initcap(CSL_TRANS_NARRRATION) CSL_TRANS_NARRRATION,CSL_RRN, ");
      genAccntStatement.append(" initcap(replace(upper(CSL_TRANS_NARRRATION),'CLAWBACK-')) || decode(upper(substr(CSL_TRANS_NARRRATION,1,9)),'CLAWBACK-',(select initcap(decode(CPP_CLAWBACK_DESC,null,'',' - '|| CPP_CLAWBACK_DESC)) from CMS_PRODUCT_PARAM WHERE cpp_prod_code=csl_prod_code),'') CSL_TRANS_NARRRATION ,CSL_RRN,  ");
      genAccntStatement.append(" to_char(TO_DATE (CSL_BUSINESS_DATE, 'yyyymmdd'),'"+CMSUtils.DATEFORMAT+"') TxnDate, ");
      genAccntStatement.append(" to_char(TO_DATE (CSL_BUSINESS_TIME, 'hh24:mi:ss'),'hh24:mi:ss') TxnTime ");
      genAccntStatement.append(" ,DECODE(TXN_FEE_FLAG,'Y','02','N','01','00') TXNORDER ");//added by Dnyaneshwar J on 10 June 2013
      genAccntStatement.append(" FROM cms_statements_log,cms_acct_mast WHERE CSL_INST_CODE= ? ");
      genAccntStatement.append(" AND csl_inst_code = cam_inst_code AND csl_acct_no = cam_acct_no  AND cam_type_code = '2' ");
      /*genAccntStatement.append(" AND TO_CHAR(to_date(CSL_BUSINESS_DATE,'yyyymmdd'),'YYYYMM') >= ? ");//Commented by Dnyaneshwar J on 05 June 2013
      genAccntStatement.append(" AND TO_CHAR(to_date(CSL_BUSINESS_DATE,'yyyymmdd'),'YYYYMM') <= ? ");*///Commented by Dnyaneshwar J on 05 June 2013
      genAccntStatement.append(" AND TO_CHAR(csl_Ins_Date,'YYYYMM') >= ? ");//Added by Dnyaneshwar J on 05 Jun 2013
      genAccntStatement.append(" AND TO_CHAR(csl_Ins_Date,'YYYYMM') <= ? ");//Added by Dnyaneshwar J on 05 Jun 2013
      genAccntStatement.append(" AND csl_acct_no=?  ");
      genAccntStatement.append(" order by  csl_ins_date,TXNORDER");//added TXNORDER by Dnyaneshwar J on 10 June 2013
      
      if(loggerUtil.isDebugEnabled())
		{
    	  	loggerUtil.debug("Query for getTxnSavingsStatement==== " + genAccntStatement);
    	  	 loggerUtil.debug("getYear To----> "+accountStatement.getYear()+accountStatement.getMonth());
		      loggerUtil.debug("getYear From----> "+accountStatement.getToYear()+accountStatement.getToMonth());
		}
				
			ParameterizedRowMapper<AccountStatement> mapper = new ParameterizedRowMapper<AccountStatement>() {
				public AccountStatement mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					
					AccountStatement acntStatement=new AccountStatement();
					acntStatement.setTxnAmount(rs.getString("CSL_TRANS_AMOUNT").trim());
					acntStatement.setTxnType(rs.getString("CSL_TRANS_TYPE"));
					acntStatement.setTxnTime(rs.getString("TxnTime"));
					String txnDesc=rs.getString("CSL_TRANS_NARRRATION");
					if(txnDesc != null && txnDesc.length()>40){
						txnDesc.trim();
						txnDesc=txnDesc.substring(0,40);
					}
								
					acntStatement.setTxnDescription(txnDesc);
					acntStatement.setTxnDate(rs.getString("TxnDate"));
					acntStatement.setOpeningBalance(rs.getString("CSL_OPENING_BAL").trim());
					acntStatement.setClosingBalance(rs.getString("CSL_CLOSING_BALANCE").trim());			
					
					return acntStatement;
				}};
				list = getSimpleJdbcTemplate().query(genAccntStatement.toString(), mapper,accountStatement.getInstCode(),
						accountStatement.getYear()+accountStatement.getMonth()
						,accountStatement.getToYear()+accountStatement.getToMonth()
						,accountStatement.getAccountNumber());
				if (list != null) {
					if(loggerUtil.isDebugEnabled())
					{
						loggerUtil.debug("No of Rows returns from getTxnSavingsStatement "+list.size());
					}
				}
     }
  catch (Exception e) {
	e.printStackTrace();
    }
  loggerUtil.logMethodExit("getTxnSavingsStatement");
  return list;
}


	
public CustomerDetails getMailingAddress(String cardNo)throws Exception
	{
		     try 
		     {   
		    	 
		         loggerUtil.logMethodEntry("detailMailingAddress");
		         CustomerDetails customerDetails=null;
		         StringBuffer viewEditMailingDetails = new StringBuffer();
		     
		     		/*viewEditMailingDetails.append( " select cam_add_one MailingAddress1,cam_add_two MailingAddress2,cam_city_name MailingCity,cam_state_code MailingStateCode,  ");
		     		viewEditMailingDetails.append( " (SELECT UPPER(gsm_state_name) FROM gen_state_mast WHERE gsm_inst_code = addr.cam_inst_code AND gsm_state_code  = cam_state_code ");
		     		viewEditMailingDetails.append( " AND gsm_cntry_code  = cam_cntry_code) MailingState, decode(catt.cpc_encrypt_enable,'Y',fn_dmaps_main(cam_pin_code),cam_pin_code) MailingZIP, cam_cntry_code MailingCountryCode,");
		     		viewEditMailingDetails.append( " (SELECT UPPER(gcm_cntry_name) FROM gen_cntry_mast WHERE gcm_inst_code = addr.cam_inst_code AND gcm_cntry_code  = cam_cntry_code) MailingCountry  ");
		     		viewEditMailingDetails.append( " from cms_appl_pan,cms_appl_mast applmast,cms_cust_mast,cms_addr_mast addr,cms_prod_mast,cms_prod_catg prodcat,cms_prod_cattype catt ");
		     		viewEditMailingDetails.append( " WHERE cap_inst_code = applmast.cam_inst_code AND cap_appl_code = applmast.cam_appl_code  ");
		     		viewEditMailingDetails.append( " AND cap_inst_code = ccm_inst_code  AND cap_cust_code = ccm_cust_code ");
		     		viewEditMailingDetails.append( " AND cap_inst_code = addr.cam_inst_code ");
		     		viewEditMailingDetails.append( " AND ccm_inst_code = addr.cam_inst_code AND ccm_cust_code = addr.cam_cust_code ");
		     		viewEditMailingDetails.append( " AND cap_inst_code = cpm_inst_code AND cap_prod_code = cpm_prod_code ");
		     		viewEditMailingDetails.append( " AND cap_inst_code = prodcat.cpc_inst_code AND cap_prod_catg = prodcat.cpc_catg_code ");
		     		viewEditMailingDetails.append( " and cap_prod_code = catt.cpc_prod_code and cap_card_type= catt.cpc_card_type ");
		     		viewEditMailingDetails.append( " and cap_inst_code =catt.cpc_inst_code AND cam_addr_flag   ='O'  AND cap_pan_code = gethash (?)    ");*/
		     	viewEditMailingDetails.append( " select Decode(catt.cpc_encrypt_enable,'Y',Fn_Dmaps_Main( cam_add_one),cam_add_one ) MailingAddress1,Decode(catt.cpc_encrypt_enable,'Y',Fn_Dmaps_Main( cam_add_two),cam_add_two ) MailingAddress2, ");
		     	viewEditMailingDetails.append( " Decode(catt.cpc_encrypt_enable,'Y',Fn_Dmaps_Main( cam_city_name),cam_city_name ) MailingCity,cam_state_code MailingStateCode,  ");
	     		viewEditMailingDetails.append( " (SELECT UPPER(gsm_state_name) FROM gen_state_mast WHERE gsm_inst_code = addr.cam_inst_code AND gsm_state_code  = cam_state_code ");
	     		viewEditMailingDetails.append( " AND gsm_cntry_code  = cam_cntry_code) MailingState, decode(catt.cpc_encrypt_enable,'Y',fn_dmaps_main(cam_pin_code),cam_pin_code) MailingZIP, cam_cntry_code MailingCountryCode,");
	     		viewEditMailingDetails.append( " (SELECT UPPER(gcm_cntry_name) FROM gen_cntry_mast WHERE gcm_inst_code = addr.cam_inst_code AND gcm_cntry_code  = cam_cntry_code) MailingCountry  ");
	     		viewEditMailingDetails.append( " from cms_appl_pan,cms_appl_mast applmast,cms_cust_mast,cms_addr_mast addr,cms_prod_mast,cms_prod_catg prodcat,cms_prod_cattype catt ");
	     		viewEditMailingDetails.append( " WHERE cap_inst_code = applmast.cam_inst_code AND cap_appl_code = applmast.cam_appl_code  ");
	     		viewEditMailingDetails.append( " AND cap_inst_code = ccm_inst_code  AND cap_cust_code = ccm_cust_code ");
	     		viewEditMailingDetails.append( " AND cap_inst_code = addr.cam_inst_code ");
	     		viewEditMailingDetails.append( " AND ccm_inst_code = addr.cam_inst_code AND ccm_cust_code = addr.cam_cust_code ");
	     		viewEditMailingDetails.append( " AND cap_inst_code = cpm_inst_code AND cap_prod_code = cpm_prod_code ");
	     		viewEditMailingDetails.append( " AND cap_inst_code = prodcat.cpc_inst_code AND cap_prod_catg = prodcat.cpc_catg_code ");
	     		viewEditMailingDetails.append( " and cap_prod_code = catt.cpc_prod_code and cap_card_type= catt.cpc_card_type ");
	     		viewEditMailingDetails.append( " and cap_inst_code =catt.cpc_inst_code AND cam_addr_flag   ='O'  AND cap_pan_code = gethash (?)    ");

		     	
		     	
		     		if(loggerUtil.isDebugEnabled())
		    		{
		     			loggerUtil.debug("Query for Mailing Details detailMailingAddress====  "+ viewEditMailingDetails);
		    		}
				ParameterizedRowMapper<CustomerDetails> mapper1 = new ParameterizedRowMapper<CustomerDetails>() {
					public CustomerDetails mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						CustomerDetails Stmnt=new CustomerDetails();
						
						String mailingAddr1=rs.getString("MailingAddress1");
						String mailingAddr2=rs.getString("MailingAddress2");
						String mailingCity=rs.getString("MailingCity");
						if(mailingAddr1!=null)
							Stmnt.setMailingAddress1(mailingAddr1.trim());
						if(mailingAddr2!=null)
							Stmnt.setMailingAddress2(mailingAddr2.trim());
						Stmnt.setMailingState(rs.getString("MailingState"));
						Stmnt.setMailingStateCode(rs.getString("MailingStateCode"));
						if(mailingCity!=null)
							Stmnt.setMailingCity(mailingCity.trim());
						Stmnt.setMailingZIP(rs.getString("MailingZIP"));
						Stmnt.setMailingCountry(rs.getString("MailingCountry"));
						Stmnt.setMailingCountryCode(rs.getString("MailingCountryCode"));
						return Stmnt;
					}
				};
				customerDetails=getSimpleJdbcTemplate().queryForObject(viewEditMailingDetails.toString(), mapper1,cardNo);
			     loggerUtil.logMethodExit("detailMailingAddress");
			     return customerDetails;


			  } 
		     catch (Exception e)
		     {
		    	 this.loggerUtil.error("Error Occured while getting Mailing Details in detailMailingAddress " + e);
				 e.printStackTrace();
				 throw e;
			  }

	}
	
	public String getAcctNo(String cardNumber) throws Exception{
		try{
			String accountNumber="";
	    	String sql="select cam_acct_no from cms_acct_mast,cms_appl_pan where " +
			           " cam_acct_no=cap_acct_no "+
			           " and cam_inst_code= cap_inst_code "+
			           " and cap_pan_code=gethash(?) ";
		
	    	accountNumber=getSimpleJdbcTemplate().queryForObject(sql,String.class,cardNumber);
			return accountNumber;
		}
		catch (Exception e) {
			loggerUtil.error("Exception in getAcctNo------>>>>>> "+ e.getMessage());
			throw(e);
		}
	}
	
	

	public String getEmailId(String cardNumber) throws Exception{
		
		try{
			String mailId="";
			/*String sql="select cam_email from cms_addr_mast,cms_appl_pan where cam_inst_code= cap_inst_code "
					+" and cam_cust_code= cap_cust_code "
					+" and cam_addr_flag='P' "
					+" and cap_pan_code=gethash(?) ";*/
			/*String sql="select Decode(Cpc_Encrypt_Enable,'Y',Fn_Dmaps_Main(Cam_Email),Cam_Email ) from cms_addr_mast,cms_appl_pan,cms_prod_cattype where cam_inst_code= cap_inst_code "
					+" and cam_cust_code= cap_cust_code "
					+" and cam_addr_flag='P'  "
					+ " and  cap_prod_code=cpc_prod_code "
					+ " and cap_card_type =cpc_card_type"
					+" and cap_pan_code=gethash(?) ";*/
			String sql="select Fn_Dmaps_Main(Cam_Email)  from cms_addr_mast,cms_appl_pan where cam_inst_code= cap_inst_code "
			+" and cam_cust_code= cap_cust_code "
			+" and cam_addr_flag='P' "
			+" and cap_pan_code=gethash(?) ";
			mailId=getSimpleJdbcTemplate().queryForObject(sql,String.class,cardNumber);
			return mailId;
		}
		catch (Exception e) {
			loggerUtil.error("Exception in getEmailId------>>>>>> "	+ e.getMessage());
			throw(e);
		}
	}
	@Override
	public AccountStatement updatePassword(AccountStatement accountStatement)
			throws Exception {
		
		loggerUtil.logMethodEntry("updatePassword");
		String result = "";
		try {

			DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
			Date l_date = new Date();
			String formateddate = dateFormat.format(l_date);
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("Update SP -- SP_RESETCUSTOMER_PASSWORD -- parameters");
			}
			int instcode = Integer.parseInt(accountStatement.getInstCode().toString());
			String pan_code = accountStatement.getPanNumber();
			loggerUtil.logCardNumber(pan_code);
			String delivery_channel = accountStatement.getDeliveryChannel();
			String txn_code = accountStatement.getTxnCode();
			String rrn = accountStatement.getRrn();
			String password = accountStatement.getPassword();
			String txn_mode = accountStatement.getTxnMode();
			String trandate = formateddate.substring(0, 8);
			String trantime = formateddate.substring(8);
			String ipAddress = accountStatement.getIpAddress();
			String currcode = accountStatement.getCurrencyCode();
			String rvsl_code = accountStatement.getReversalCode();
			String bank_code = accountStatement.getBankCode();
			String msg_type = accountStatement.getMsgType();
			String memb_num = accountStatement.getMembNum();
			String stan = accountStatement.getStan();
			int call_id = Integer.parseInt(accountStatement.getCallID().toString());
			int ins_user = Integer.parseInt(accountStatement.getUserId().toString());
			String remark = accountStatement.getRemark();
			
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("instcode : " + instcode);
				loggerUtil.debug("delivery_channel : " + delivery_channel);
				loggerUtil.debug("txn_code : " + txn_code);
				loggerUtil.debug("rrn : " + rrn);
				loggerUtil.debug("password : " + password);
				loggerUtil.debug("txn_mode : " + txn_mode);
				loggerUtil.debug("trandate : " + trandate);
				loggerUtil.debug("trantime : " + trantime);
				loggerUtil.debug("ipAddress : " + ipAddress);
				loggerUtil.debug("currcode : " + currcode);
				loggerUtil.debug("rvsl_code : " + rvsl_code);
				loggerUtil.debug("bank_code : " + bank_code);
				loggerUtil.debug("msg type : " + msg_type);
				loggerUtil.debug("memb_num : " + memb_num);
				loggerUtil.debug("stan : " + stan);
				loggerUtil.debug("call_id : " +call_id);
				loggerUtil.debug("ins_user : " + ins_user);
				loggerUtil.debug("remark : " + remark);
			}
						
			Map<String, Object> map = new HashMap<String, Object>();
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(getDataSource());
			simpleJdbcCall = simpleJdbcCall
					.withProcedureName("SP_RESETCUSTOMER_PASSWORD")
					.withSchemaName(cmsParameters.getProperty("SCHEMANAME"))
					.withoutProcedureColumnMetaDataAccess()
					.useInParameterNames("p_instcode","p_pan_code","p_delivery_channel",
							"p_txn_code","p_rrn","p_password","p_txn_mode","p_rvsl_code",
							"p_tran_date","p_tran_time","p_ipaddress", "p_curr_code",
							"p_bank_code","p_msg","p_mbrnumb","p_stan","p_call_id",
							"p_ins_user","p_remark","p_resp_code","p_resmsg")
					.declareParameters(
							new SqlParameter("p_instcode", Types.NUMERIC),
							new SqlParameter("p_pan_code", Types.VARCHAR),
							new SqlParameter("p_delivery_channel",Types.VARCHAR),
							new SqlParameter("p_txn_code", Types.VARCHAR),
							new SqlParameter("p_rrn", Types.VARCHAR),
							new SqlParameter("p_password", Types.VARCHAR),
							new SqlParameter("p_txn_mode", Types.VARCHAR),
							new SqlParameter("p_tran_date", Types.VARCHAR),
							new SqlParameter("p_tran_time", Types.VARCHAR),
							new SqlParameter("p_ipaddress", Types.VARCHAR),
							new SqlParameter("p_curr_code", Types.VARCHAR),
							new SqlParameter("p_rvsl_code", Types.VARCHAR),
							new SqlParameter("p_bank_code", Types.VARCHAR),
							new SqlParameter("p_msg", Types.VARCHAR),
							new SqlParameter("p_mbrnumb", Types.VARCHAR),
							new SqlParameter("p_stan", Types.VARCHAR),
							new SqlParameter("p_call_id", Types.NUMERIC),
							new SqlParameter("p_ins_user", Types.NUMERIC),
							new SqlParameter("p_remark", Types.VARCHAR),
							new SqlOutParameter("p_resp_code", Types.VARCHAR),
							new SqlOutParameter("p_resmsg", Types.VARCHAR));

			map.put("p_instcode", instcode);
			map.put("p_pan_code", pan_code);
			map.put("p_delivery_channel", delivery_channel);
			map.put("p_txn_code", txn_code);
			map.put("p_rrn", rrn);
			map.put("p_password", password);
			map.put("p_txn_mode", txn_mode);
			map.put("p_tran_date", trandate);
			map.put("p_tran_time", trantime);
			map.put("p_ipaddress", ipAddress);
			map.put("p_curr_code", currcode);
			map.put("p_rvsl_code", rvsl_code);
			map.put("p_bank_code", rvsl_code);
			map.put("p_msg", msg_type);
			map.put("p_mbrnumb", memb_num);
			map.put("p_stan", stan);
			map.put("p_call_id", call_id);
			map.put("p_ins_user", ins_user);
			map.put("p_remark", remark);
					
			SqlParameterSource in = new MapSqlParameterSource().addValues(map);
			Map<String, Object> out = simpleJdbcCall.execute(in);
			
			result = (String) out.get("p_resmsg");
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("Reset Password procedure out " + out);
				loggerUtil.debug("Result from SP_RESETCUSTOMER_PASSWORD : " + result);
			}
			accountStatement.setRespCode(out.get("p_resp_code").toString());
			accountStatement.setRespMsg(out.get("p_resmsg").toString());
			accountStatement.setTxnDate(trandate);
			accountStatement.setTxnTime(trantime);
		} catch (Exception e) {
			loggerUtil.error("Exception in updatePassword------>>>>>> "
					+ e.getMessage());
		}
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("Response after profile updation "
				+ accountStatement.getRespCode() + "  "
				+ accountStatement.getRespMsg());
		}
		loggerUtil.logMethodExit("updatePassword");
		return accountStatement;
	}

	@Override
	public String findCustomerPasswordLength(String instCode) throws Exception {
		try{
			String custPassLength="";
			String sql="select CIP_PARAM_VALUE from cms_inst_param where cip_param_key=? and cip_inst_code=? ";
			
			custPassLength=getSimpleJdbcTemplate().queryForObject(sql,String.class,CmsConstants.CUSTOMER_PASSWORD_LENGTH_KEY,instCode);
			return custPassLength;
		}
		catch (Exception e) {
			loggerUtil.error("Exception in findCustomerPasswordLength------>>>>>> "	+ e.getMessage());
			throw(e);
		}
	}
	
	//This method added by Dnyaneshwar on 09 May 2012 For 
	//Upgrading Starter card to GPR card
	@Override
	public CardReplacement upgradeToPersonalizedGPR(CardReplacement bean) throws Exception {
		Connection con = null;
		CallableStatement cstmt = null;
		String tranDate= CMSUtils.getFormattedDate("yyyyMMdd");
		String tranTime= CMSUtils.getFormattedDate("HHmmss");
		String result="";
	
		try{
			CardReplacement dtl = new CardReplacement();
			String prm_resp_code=null;
			String prm_resp_msg=null;
			CSRUtils csrUtil= new CSRUtils();
			KeyValueBean keyValue = new KeyValueBean();
			keyValue = csrUtil.getSeqNoForRRNAndStan();
			String spName="SP_UPGRADE_TO_PERSONALISEDCARD";
			
//			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(getDataSource());
			String[] currencyCode=new String[2];
//			csrUtil.setSimpleJdbcTemplate(getSimpleJdbcTemplate());
			String productCardtype=csrUtil.getProdCodeandCardType(bean.getClearPan());
			con = getDataSource().getConnection();
			cstmt = con.prepareCall("{call vmscms.SP_UPGRADE_TO_PERSONALISEDCARD(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");//23 arguments
			cstmt.setInt(1,Integer.parseInt(bean.getInstCode()) );
			cstmt.setString(2,CmsConstants.TXN_0200_NORMAL_MSG_TYPE);//Modified by Abhay R on 12 June 2013
			cstmt.setString(3,bean.getHidMembNum());
			cstmt.setString(4,bean.getClearPan());
			if(bean.getCardUpgraderadio().equals("radioNewPAN"))
			{
				cstmt.setString(5,CmsConstants.TXN_CODE_UPGRADETO_PERSONALIZED);
			}
			else
			{
				cstmt.setString(5,CmsConstants.TXN_CODE_UPGRADETO_PERSONALIZED_EXPEDITED_SHIPPING);	
			}
			cstmt.setString(6,CmsConstants.DELIVERY_CHANNEL);
			cstmt.setString(7,keyValue.getRRN());
			cstmt.setString(8,CmsConstants.TXN_MODE_OFFLINE);
			cstmt.setString(9,keyValue.getSTAN());
			cstmt.setString(10,tranDate);
			cstmt.setString(11,tranTime);
			cstmt.setString(12,NullUtilities.returnBlank(currencyCode[0]));
			cstmt.setInt(13,new Integer(1));
			cstmt.setInt(14,new Integer(1));
			cstmt.setString(15,bean.getCallId());
			cstmt.setInt(16,new Integer(1));//bean.getHidCurrCode());
			cstmt.setString(17,bean.getRemark() );
			cstmt.setString(18,"1" );//added by Dnyaneshwar J on 30 May 2012
			
			//Added by Dnyaneshwar J on 22 Jun 2012
			cstmt.setString(19,CmsConstants.TXN_NONREVERSAL_CODE);
			cstmt.setString(20,"");
			cstmt.setString(21,"");
			cstmt.setString(22,bean.getIpAddress());//Added by Dnyaneshwar J on 07 Oct 2012.
			
			cstmt.registerOutParameter(23, Types.VARCHAR);
			cstmt.executeUpdate();

			result = cstmt.getString(23);
			prm_resp_code=(String)cstmt.getString("P_RESP_CODE");
			prm_resp_msg=(String)cstmt.getString("P_RESP_MSG");
			try{
				//currencyCode=StartOfProcess.curncyDetl.get(bean.getClearPan().substring(0, 6)).split(",");
				currencyCode=StartOfProcess.curncyDetl.get(productCardtype).split(",");
				
				
			}catch(Exception e){
					loggerUtil.error("Error occured while Getting the Profile Currency Code : "+ e);
			}			
			
			
//		    csrUtil.setSimpleJdbcTemplate(getSimpleJdbcTemplate());
		    
		    
		    loggerUtil.logCardNumber(bean.getClearPan());
		    
		    if(loggerUtil.isDebugEnabled())
			{
		    	loggerUtil.debug("spName "+spName);
				loggerUtil.debug("RRN "+keyValue.getRRN());
				loggerUtil.debug("STAN "+keyValue.getSTAN());
				loggerUtil.debug("tranDate "+tranDate);
				loggerUtil.debug("tranTime "+tranTime);
				loggerUtil.debug("SP NAME  			 :"+spName);
				loggerUtil.debug("p_inst_code        :"+Integer.parseInt(bean.getInstCode()) );
				loggerUtil.debug("p_msg_type         :"+CmsConstants.TXN_0200_NORMAL_MSG_TYPE);//Modified by Abhay R on 12 June 2013
				loggerUtil.debug("p_mbr_numb         :"+bean.getHidMembNum());
				loggerUtil.debug("P_TXN_CODE         :"+CmsConstants.TXN_CODE_UPGRADETO_PERSONALIZED);
				loggerUtil.debug("p_delivery_channel :"+CmsConstants.DELIVERY_CHANNEL);
				loggerUtil.debug("p_txn_mode         :"+CmsConstants.TXN_MODE_OFFLINE);
				loggerUtil.debug("p_rrn         	 :"+keyValue.getRRN());
				loggerUtil.debug("p_stan         	 :"+keyValue.getSTAN());
				loggerUtil.debug("p_tran_date        :"+tranDate);
				loggerUtil.debug("p_tran_time        :"+tranTime);
				loggerUtil.debug("p_curr_code        :"+NullUtilities.returnBlank(currencyCode[0]));
				loggerUtil.debug("p_consodium_code   :"+new Integer(1));
				loggerUtil.debug("p_partner_code     :"+new Integer(1));
				loggerUtil.debug("p_call_id          :"+bean.getCallId());
				loggerUtil.debug("p_reason_code      :"+new Integer(99));//bean.getHidTermId());
				loggerUtil.debug("p_remark           :"+bean.getRemark());
				loggerUtil.debug("p_ins_user         :"+bean.getUserId());
				loggerUtil.debug("p_ipaddress        :"+bean.getIpAddress());
				
				//Added by Dnyaneshwar J on 22 Jun 2012
				loggerUtil.debug("p_rvsl_code        :"+"00");
				loggerUtil.debug("p_merchant_name    :"+"");
				loggerUtil.debug("p_merchant_city    :"+"");
			}
			
/*			simpleJdbcCall = simpleJdbcCall.withProcedureName(spName);
			simpleJdbcCall = simpleJdbcCall.withSchemaName(cmsParameters.getProperty("SCHEMANAME"));
			
			Map<String,Object> map = new HashMap();	
			map.put("P_INST_CODE",Integer.parseInt(bean.getInstCode()) );
			map.put("P_MSG_type",CmsConstants.TXN_0200_NORMAL_MSG_TYPE);//Modified by Abhay R on 12 June 2013
			map.put("P_MBR_NUMB",bean.getHidMembNum());
			map.put("P_starter_CARD",bean.getClearPan());
			if(bean.getCardUpgraderadio().equals("radioNewPAN"))
			{
			map.put("P_TXN_CODE",CmsConstants.TXN_CODE_UPGRADETO_PERSONALIZED);
			}
			else
			{
				map.put("P_TXN_CODE",CmsConstants.TXN_CODE_UPGRADETO_PERSONALIZED_EXPEDITED_SHIPPING);	
			}
			map.put("P_DELIVERY_CHANNEL",CmsConstants.DELIVERY_CHANNEL);
			map.put("P_RRN",keyValue.getRRN());
			map.put("P_TXN_MODE",CmsConstants.TXN_MODE_OFFLINE);
			map.put("P_STAN",keyValue.getSTAN());
			map.put("P_TRAN_DATE",tranDate);
			map.put("P_TRAN_TIME",tranTime);
			map.put("P_CURR_CODE",NullUtilities.returnBlank(currencyCode[0]));
			map.put("p_consodium_code",new Integer(1));
			map.put("p_partner_code",new Integer(1));
			map.put("p_call_id",bean.getCallId());
			map.put("p_reason_code",new Integer(1));//bean.getHidCurrCode());
			map.put("P_REMARK",bean.getRemark() );
			map.put("P_INS_USER","1" );//added by Dnyaneshwar J on 30 May 2012
			
			//Added by Dnyaneshwar J on 22 Jun 2012
			map.put("P_RVSL_CODE",CmsConstants.TXN_NONREVERSAL_CODE);
			map.put("P_MERCHANT_NAME","");
			map.put("P_MERCHANT_CITY","");
			map.put("P_IPADDRESS",bean.getIpAddress());//Added by Dnyaneshwar J on 07 Oct 2012.*/
			
//			SqlParameterSource in = new MapSqlParameterSource().addValues(map);				
//			Map <String , Object> out  =  simpleJdbcCall.execute(in);
			
//			prm_resp_code=(String)out.get("P_RESP_CODE");
//			prm_resp_msg=(String)out.get("P_RESP_MSG");
			
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("P_RESP_CODE "+prm_resp_code);
				loggerUtil.debug("P_RESP_MSG "+prm_resp_msg);
			}
			
			dtl.setPrm_resp_code(prm_resp_code);
			dtl.setPrm_resp_msg(prm_resp_msg);
			
			if(prm_resp_msg!=null && prm_resp_msg.equals("OK")){
				
				CardReplacement newGPRCrd=new CardReplacement();
				newGPRCrd=getNewCardDetails(bean.getClearPan(),bean.getInstCode());
				
				if(newGPRCrd.getNewCardNumber()!=null && !(newGPRCrd.getNewCardNumber().equals(""))
					&& newGPRCrd.getNewCardStatus()!=null && !(newGPRCrd.getNewCardStatus().equals(""))){
					dtl.setNewCardNumber(newGPRCrd.getNewCardNumber());
					dtl.setNewCardStatus(newGPRCrd.getNewCardStatus());
				}
			}
			
			bean.setBusinessDate(tranDate);//sn-Added by Dnyaneshwar J on 18 Mar 2013
			bean.setBusinessTime(tranTime);
			bean.setRrn(keyValue.getRRN());
			bean.setTxnCode(CmsConstants.TXN_CODE_UPGRADETO_PERSONALIZED);
			
			this.UpdateUserRegistartion(bean);//en-Added by Dnyaneshwar J on 18 Mar 2013
			return dtl;

		}
		catch (Exception e) {

			throw(e);
		}
		finally {
			if (cstmt != null) {
				cstmt.close();
			}
			if (con != null) {
				con.close();
			}
		}
	}
	
	//Added by Dnyaneshwar on 14 May 2012 to get new card details on basis of starter card
	public CardReplacement getNewCardDetails(String oldCardNumber,String instCode){
		loggerUtil.logMethodEntry("getNewCardDetails");
		
		StringBuffer sql=new StringBuffer();
		CardReplacement cardDtl=new CardReplacement();
		
		sql.append(" select * from ( ");
		sql.append(" select fn_dmaps_main(cap_pan_code_encr) cap_pan_code_encr,fn_getmaskpan(fn_dmaps_main(cap_pan_code_encr)) cardnumber,");
		sql.append("(SELECT ccs_stat_desc");
		sql.append(" FROM cms_card_stat WHERE ccs_inst_code = ? "); //Lince J removed hard coded inst code on 06-Sep-2012
		sql.append(" AND ccs_stat_code   = cap_card_stat) cardStatus");
		sql.append(" FROM cms_appl_pan");
		sql.append(" where cap_acct_no=(select cap_acct_no from cms_appl_pan where cap_pan_code=gethash(?)) AND cap_startercard_flag='N' order by cap_ins_date desc ) where rownum=1");

		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("Query for getting new generatedcard : "+sql.toString());
			loggerUtil.logCardNumber(oldCardNumber);
		}
		
		ParameterizedRowMapper<CardReplacement> mapper = new ParameterizedRowMapper<CardReplacement>() {
			public CardReplacement mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				CardReplacement newCrd=new CardReplacement();

				newCrd.setNewCardNumber(rs.getString("cardnumber"));
				newCrd.setNewCardStatus(rs.getString("cardStatus"));
				
				return newCrd;
			}
		};
		cardDtl=getSimpleJdbcTemplate().queryForObject(sql.toString(), mapper,instCode,oldCardNumber);
		
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.logCardNumber(cardDtl.getNewCardNumber());
			loggerUtil.debug("New card Status : "+cardDtl.getNewCardStatus());
		}
		
		loggerUtil.logMethodExit("getNewCardDetails");
		return cardDtl;
	}

	@Override
	public String getAccuredRate(AccountStatement accountStatement)
			throws Exception {
		String accuredInterest=null;
		String startDate=null;
		try{
			
			//String sql=" select  TO_CHAR (nvl(cam_interest_amount,0), '"+CMSUtils.AMTFORMAT+"') InterestAmount from cms_acct_mast where cam_inst_code=? and cam_acct_no=? and cam_type_code='2'  ";
			 String sql=" select to_char(nvl(sum(CID_INTEREST_AMOUNT),'0'), '99999999999999990.99') as interest_accrued "+             
             " from  cms_interest_detl "+
             " where trunc(cid_calc_date) between to_date(?,'DDMMYYYY') and Last_day(to_date( ?,'DDMMYYYY')) "+           
             " and cid_acct_no=? "+
             " and cid_inst_code=? ";
			
			
			loggerUtil.debug("Query for interset detl getAccuredRate : "+sql);
			
			startDate="01"+accountStatement.getToMonth()+accountStatement.getToYear();
			accuredInterest=getSimpleJdbcTemplate().queryForObject(sql,String.class,startDate,startDate,accountStatement.getAccountNumber(),accountStatement.getInstCode());
			loggerUtil.debug("interset detl accuredInterest : "+accuredInterest);
			
			if("0.00".equals(accuredInterest.trim()))
			{
				 String sqlHist=" select to_char(nvl(sum(CID_INTEREST_AMOUNT),'0'), '99999999999999990.99') as interest_accrued "+             
	             " from  cms_interest_detl_hist "+
	             " where trunc(cid_calc_date) between to_date(?,'DDMMYYYY') and Last_day(to_date( ?,'DDMMYYYY')) "+           
	             " and cid_acct_no=? "+
	             " and cid_inst_code=? ";
								
				loggerUtil.debug("Query for interest detl hist getAccuredRate : "+sqlHist);
				
				startDate="01"+accountStatement.getToMonth()+accountStatement.getToYear();
				accuredInterest=getSimpleJdbcTemplate().queryForObject(sqlHist,String.class,startDate,startDate,accountStatement.getAccountNumber(),accountStatement.getInstCode());
				loggerUtil.debug("interset detl hist accuredInterest : "+accuredInterest);
			}
			
			
			return accuredInterest;
		}
		catch (Exception e) {
			loggerUtil.error("Exception in getAccuredRate------>>>>>> "	+ e.getMessage());
			accuredInterest="0.00";
			throw(e);
		}
	}
	/*
	@Override
	public String getInterestRate(String instCode,String prodCode) throws Exception {//Modified by Dntyanehwar J on 04 Oct 2013
		try{
			String interestRate="";
			String sql=" select TO_CHAR (nvl(cdp_param_value,0), '"+CMSUtils.AMTFORMAT+"') InterestRate  from cms_dfg_param where cdp_inst_code=? and cdp_param_key=? and cdp_prod_code = ? ";//Modified by Dnyaneshwar J on 04- Oct 2013
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("Query for getInterestRate : "+sql);
				loggerUtil.debug("Inst Code    : "+instCode);//Added by Dnyaneshwar J on 04 Oct 2013
				loggerUtil.debug("Product Code : "+prodCode);//Added by Dnyaneshwar J on 04 Oct 2013
			}
			interestRate=getSimpleJdbcTemplate().queryForObject(sql,String.class,instCode,CmsConstants.SAVING_ACCOUNT_INTEREST_RATE,prodCode);//Modified by Dnyaneshwar J on 04- Oct 2013
			return interestRate;
		}
		catch (EmptyResultDataAccessException emty) {//sn-Added by Dnyaneshwar J on 04 Oct 2013
			loggerUtil.error("Empty Resultset Occured While Getting Interest Rate : ",emty);
			loggerUtil.info("Interest Rate set to 0.00 default.");
			return "0.00";
		}//en-Added by Dnyaneshwar J on 04 Oct 2013
		catch (Exception e) {
			loggerUtil.error("Exception in getInterestRate------>>>>>> "	+ e.getMessage());
			throw(e);
		}		
	}
	*/

	@Override
	public AccountStatement getInterestPaid(AccountStatement accountStatement)
			throws Exception {
		try{
			StringBuffer sql=new StringBuffer();
			AccountStatement stmtDetail=new AccountStatement();
			sql.append(" select  TO_CHAR(round(nvl(to_char(sum(csl_trans_amount)),'0.00'),2),'"+CMSUtils.AMTFORMAT+"') Amount,count(1) Count ");
			sql.append(" FROM cms_statements_log, cms_acct_mast WHERE csl_acct_no = cam_acct_no ");
			sql.append(" AND cam_type_code = '2' AND csl_delivery_channel = '05' ");
			sql.append(" AND csl_txn_code = '13' ");
			sql.append(" AND to_char(csl_trans_date, 'MMYYYY') >= ?");//Adde by Narsing on 7th Feb 2014
			sql.append(" AND to_char(csl_trans_date, 'MMYYYY') <= ?");
			sql.append(" AND csl_acct_no=? ");
			
			
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("Query for getInterestPaid : "+sql.toString());
			}
						
			ParameterizedRowMapper<AccountStatement> mapper = new ParameterizedRowMapper<AccountStatement>() {
				public AccountStatement mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					AccountStatement acctStmt=new AccountStatement();

					acctStmt.setTxnAmount(rs.getString("Amount"));
					acctStmt.setCount(rs.getInt("Count"));
					
					return acctStmt;
				}
			};
			stmtDetail=getSimpleJdbcTemplate().queryForObject(sql.toString(), mapper,accountStatement.getFromMonthNo()+""+accountStatement.getYear(),accountStatement.getToMonthNo()+""+accountStatement.getToYear(),accountStatement.getAccountNumber());
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("Amount         "+stmtDetail.getTxnAmount());
			}
			return stmtDetail;
		}
		catch (Exception e) {
			loggerUtil.error("Exception in getInterestPaid------>>>>>> "	+ e.getMessage());
			throw(e);
		}
	}
	
	@Override
	public AccountStatement doStatementGenerationLog(AccountStatement accountStatement)
	throws Exception {
		Connection con = null;
		CallableStatement cstmt = null;
		String result = "";
		
		try{
			loggerUtil.logMethodEntry("doStatementGenerationLog");
			AccountStatement accStatementOut=new AccountStatement();
			
			
			String deliveryChannel=CmsConstants.DELIVERY_CHANNEL;
			String [] result = new String[3];
		
			KeyValueBean keyValue=new KeyValueBean();
		    CSRUtils csrUtil= new CSRUtils();
//		    csrUtil.setSimpleJdbcTemplate(getSimpleJdbcTemplate());
		    keyValue = csrUtil.getSeqNoForRRNAndStan();
		    
		    DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		    Date l_date = new Date();
		    String formateddate=dateFormat.format(l_date);
			String trandate=formateddate.substring(0, 8);
			String trantime=formateddate.substring(8);

			/*SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(getDataSource());
			simpleJdbcCall = simpleJdbcCall.withProcedureName("sp_customer_services_csr");
			simpleJdbcCall = simpleJdbcCall.withSchemaName(cmsParameters.getProperty("SCHEMANAME"));*/
			
			con = getDataSource().getConnection();
			cstmt = con.prepareCall("{call vmscms.sp_customer_services_csr(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			cstmt.setInt(1,Integer.parseInt(accountStatement.getInstCode()));
			cstmt.setString(2,accountStatement.getMsgType() );
			cstmt.setString(3,accountStatement.getClearPanNumber() );//STAN
			cstmt.setString(4,accountStatement.getMembNum() );
			//map.put("p_acct_num",accountStatement.getAccountNumber() );
			cstmt.setString(5,keyValue.getRRN() );
			cstmt.setInt(6,Integer.parseInt(keyValue.getSTAN()) );//STAN
			cstmt.setString(7,deliveryChannel );
			cstmt.setString(8,accountStatement.getTxnCode());
			cstmt.setString(9,accountStatement.getTxnMode());
			cstmt.setString(10,trandate );//Transaction date YYYYMMDD
			cstmt.setString(11,trantime );//Trnsaction time HHmmss
			cstmt.setString(12,accountStatement.getRemark().trim());
			cstmt.setInt(13,Integer.parseInt(accountStatement.getCallID()) );
			cstmt.setInt(14,Integer.parseInt(accountStatement.getUserId()) );
			cstmt.setString(15,accountStatement.getCurrencyCode());
			cstmt.setString(16,accountStatement.getReversalCode());
			cstmt.setString(17,accountStatement.getFeeApplicable());
			cstmt.setString(18,accountStatement.getIpAddress());//Added by Dnyaneshwar J on 07 Oct 2012.
			cstmt.setLong(19,(long) accountStatement.getFeeAmount());
			cstmt.registerOutParameter(20, Types.VARCHAR);
			cstmt.executeUpdate();
			result = cstmt.getString(20);
			loggerUtil.logCardNumber(accountStatement.getClearPanNumber() );//STAN
			
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("SP parameters-----------------");
				 
				loggerUtil.debug("p_inst_code  "+Integer.parseInt(accountStatement.getInstCode()));
				loggerUtil.debug("p_msg_type  "+accountStatement.getMsgType() );
				loggerUtil.debug("p_mbr_numb  "+accountStatement.getMembNum() );
			//	loggerUtil.debug("p_acct_num"+accountStatement.getAccountNumber() );
				loggerUtil.debug("p_rrn  "+keyValue.getRRN() );
				loggerUtil.debug("p_stan  "+Integer.parseInt(keyValue.getSTAN()) );//STAN
				loggerUtil.debug("p_delivery_channel  "+deliveryChannel );
				loggerUtil.debug("p_txn_code  "+accountStatement.getTxnCode());
				loggerUtil.debug("p_txn_mode  "+accountStatement.getTxnMode());
				loggerUtil.debug("p_tran_date  "+trandate );//Transaction date YYYYMMDD
				loggerUtil.debug("p_tran_time  "+trantime );//Trnsaction time HHmmss
				loggerUtil.debug("p_remark  "+accountStatement.getRemark() );
				loggerUtil.debug("p_call_id  "+Integer.parseInt(accountStatement.getCallID()) );
				loggerUtil.debug("p_ins_user  "+Integer.parseInt(accountStatement.getUserId()) );
				loggerUtil.debug("p_curr_code  "+accountStatement.getCurrencyCode());
				loggerUtil.debug("p_rvsl_code  "+accountStatement.getReversalCode());
				loggerUtil.debug("p_fee_calc  "+accountStatement.getFeeApplicable());
				loggerUtil.debug("p_ipaddress  "+accountStatement.getIpAddress());//Added by Dnyaneshwar J on 07 Oct 2012.
				loggerUtil.debug("p_fee_amt  "+accountStatement.getFeeAmount());
			}
				
				
				/*Map<String,Object> map = new HashMap<String,Object>();	
				
				
				map.put("p_inst_code",Integer.parseInt(accountStatement.getInstCode()));
				map.put("p_msg_type",accountStatement.getMsgType() );
				map.put("p_pan_code",accountStatement.getClearPanNumber() );//STAN
				map.put("p_mbr_numb",accountStatement.getMembNum() );
				//map.put("p_acct_num",accountStatement.getAccountNumber() );
				map.put("p_rrn",keyValue.getRRN() );
				map.put("p_stan",Integer.parseInt(keyValue.getSTAN()) );//STAN
				map.put("p_delivery_channel",deliveryChannel );
				map.put("p_txn_code",accountStatement.getTxnCode());
				map.put("p_txn_mode",accountStatement.getTxnMode());
				map.put("p_tran_date",trandate );//Transaction date YYYYMMDD
				map.put("p_tran_time",trantime );//Trnsaction time HHmmss
				map.put("p_remark",accountStatement.getRemark().trim());
				map.put("p_call_id",Integer.parseInt(accountStatement.getCallID()) );
				map.put("p_ins_user",Integer.parseInt(accountStatement.getUserId()) );
				map.put("p_curr_code",accountStatement.getCurrencyCode());
				map.put("p_rvsl_code",accountStatement.getReversalCode());
				map.put("p_fee_calc",accountStatement.getFeeApplicable());
				map.put("p_ipaddress",accountStatement.getIpAddress());//Added by Dnyaneshwar J on 07 Oct 2012.
				map.put("p_fee_amt",accountStatement.getFeeAmount());*/

				
/*				SqlParameterSource in = new MapSqlParameterSource().addValues(map);				
				Map <String , Object> out  = simpleJdbcCall.execute(in);*/
				
				result[0] = (String) cstmt.getString("P_RESP_CODE");
				result[1] = (String) cstmt.getString("P_RESP_MSG");
				
				if(loggerUtil.isDebugEnabled())
				{
					loggerUtil.debug("Statement  procedure out "+cstmt);
					loggerUtil.debug("result[0] "+result[0]);
					loggerUtil.debug("result[1] "+result[1]);
				}
				
				accStatementOut.setRespCode(String.valueOf(cstmt.getString(result[0])));
				accStatementOut.setRrn(keyValue.getRRN());
				accStatementOut.setTxnDate(trandate);
				accStatementOut.setTxnTime(trantime);
				
				if(result[0]=="00" || result[1].equals("OK")){
					accStatementOut.setSP_OUT_1((String)cstmt.getString(result[1]));
					accStatementOut.setSpResult("SUCCESS");
					
				}
				else{
					accStatementOut.setSP_OUT_1((String)cstmt.getString(result[1]));
					accStatementOut.setSpResult("FAILED");
				}
				
				if (cstmt.getString(result[1]).toString().indexOf("ORA") > 0) {
					if (cstmt.getString(result[0]).toString() != "00") {
						accStatementOut.setSP_OUT_1("Error Occurred while processing");
						accStatementOut.setSpResult("FAILED");
					} else
						accStatementOut.setSP_OUT_1("Statement Generation Failed");
					accStatementOut.setSpResult("FAILED");
				} 
				
				if(loggerUtil.isDebugEnabled())
				{
					loggerUtil.debug("SP Executed......doStatementGenerationLog");
				}
				loggerUtil.logMethodExit("doStatementGenerationLog");
				return accStatementOut;
				
		}
		catch (Exception e) {
			e.printStackTrace();
			throw(e);
			
		}finally {
			if (cstmt != null) {
				cstmt.close();
			}
			if (con != null) {
				con.close();
			}
		}
	}

	/**
	 * Method using for get Opening BAlance and Closing BAlance
	 */
	//Added by Lince J on 25 Sept 2012
	@Override
	public AccountStatement getPreviousOpeningBal(AccountStatement accountStatement) {
		loggerUtil.logMethodEntry("getPrevMonthOpeningBal");
		String prevMonthOpeningBal="";
		StringBuffer sql = new StringBuffer();
		AccountStatement ob=null;
		
		sql.append(" select ");
		sql.append("  NVL(TRIM(TO_CHAR(SUM(CSL_OPENING_BAL),'"+CMSUtils.AMTFORMAT+"')),'0.00') OPENINGBALANCE, ");  
		sql.append(" nvl(trim(TO_CHAR(SUM(csl_closing_balance),'"+CMSUtils.AMTFORMAT+"')),'0.00') ClosingBalance ");
		sql.append(" FROM ");
		sql.append("  (SELECT csl_opening_bal, ");
		sql.append("    csl_closing_balance ");
		sql.append("  from CMS_STATEMENTS_LOG ");
		sql.append("  where TO_DATE(TO_CHAR(TO_DATE(CSL_BUSINESS_DATE,'yyyymmdd'),'YYYYMM'),'YYYYMM') < TO_DATE(?,'YYYYMM') ");
		sql.append("  AND csl_acct_no  = ? ");
		
		if(cmsParameters.ORDER_POSTING_DATE_FLAG!=null && cmsParameters.ORDER_POSTING_DATE_FLAG.equalsIgnoreCase("YES")){
			sql.append(" order by  csl_ins_date desc ");
		}
		else{
			sql.append(" ORDER BY to_date(CSL_BUSINESS_DATE||CSL_BUSINESS_TIME,'yyyymmddhh24miss') DESC ");
		}
		sql.append(" ) WHERE ROWNUM < 2 ");
		
		if(loggerUtil.isDebugEnabled()){
			loggerUtil.debug("Account Number : "+accountStatement.getAccountNumber());
			loggerUtil.debug("Year And Month : "+accountStatement.getYear()+accountStatement.getMonth());
			loggerUtil.debug("Query For Getting Prevoius Month Opening Balance : "+sql.toString());
		}
		ParameterizedRowMapper<AccountStatement> mapper = new ParameterizedRowMapper<AccountStatement>() {
			public AccountStatement mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				
				AccountStatement acntStatement=new AccountStatement();
				acntStatement.setOpeningBalance(rs.getString("OPENINGBALANCE"));
				acntStatement.setClosingBalance(rs.getString("ClosingBalance"));
				return acntStatement;
			}};
			ob = getSimpleJdbcTemplate().queryForObject(sql.toString(), mapper,
					accountStatement.getYear()+accountStatement.getMonth(),accountStatement.getAccountNumber());
			
		
		if(loggerUtil.isDebugEnabled()){
			loggerUtil.debug("prevMonthOpeningBal "+ob.getOpeningBalance());
			loggerUtil.debug("prevMonthClosingBal "+ob.getClosingBalance());
		}
		
	
		
		loggerUtil.logMethodExit("getPrevMonthOpeningBal");
		return ob;
	}
	
	/**
	 * Added by Dnyaneshwar J on 18 Mar 2013
	 * to log user id in transactionlog table
	 */
	@Override
	public void UpdateUserRegistartion(CardReplacement bean) throws Exception{
		loggerUtil.logMethodEntry("UpdateUserRegistartion");	
		
		StringBuffer updateUser=new StringBuffer("UPDATE TRANSACTIONLOG SET ADD_INS_USER =? WHERE RRN=? AND TXN_CODE=?");
				updateUser.append(" AND DELIVERY_CHANNEL=? ");
				updateUser.append(" AND MSGTYPE=? AND BUSINESS_DATE =? ");
				updateUser.append(" AND BUSINESS_TIME=?");
		
		int inserRecord=getSimpleJdbcTemplate().update(updateUser.toString(),bean.getUserId(),bean.getRrn(),bean.getTxnCode(),
				CmsConstants.DELIVERY_CHANNEL,CmsConstants.TXN_0200_NORMAL_MSG_TYPE,bean.getBusinessDate(),bean.getBusinessTime());//Modified by Abhay R on 12 June 2013
		
		if(inserRecord==1){
			loggerUtil.debug("user id Updated for -> rrn -->"+bean.getRrn());
		}
		else{
			loggerUtil.debug("No. Of Rows Updated : "+inserRecord);
		}
		loggerUtil.logMethodExit("UpdateUserRegistartion");
	}

	/**
	 * This method will return the email address which is configured for paper statement
	 */
	//Added by Dnyaneshwar J on 06 May 2013
	@Override
	public String getEmailIdForPaperStatement(AccountStatement accountStatement) {
		loggerUtil.logMethodEntry("getEmailIdForPaperStatement");
		StringBuffer sql = new StringBuffer();
		sql.append(" SELECT cpC_email_id FROM CMS_PROD_CATTYPE WHERE (CPC_PROD_CODE,CPC_CARD_TYPE) =(select cap_prod_code,cap_card_type from cms_appl_pan where cap_pan_code=gethash(?) and CAP_INST_CODE = ? ) and cpc_inst_code=? ");
		String configuredEmail="";
		
		loggerUtil.debug("Query To Get Configured E-Mail For Paper Statement : "+sql.toString());
		loggerUtil.debug("instCode "+accountStatement.getInstCode());
		
		configuredEmail=getSimpleJdbcTemplate().queryForObject(sql.toString(),String.class,accountStatement.getClearPanNumber(),accountStatement.getInstCode(),accountStatement.getInstCode());
		
		loggerUtil.logMethodExit("getEmailIdForPaperStatement");
		return configuredEmail;
	}

	@Override
	public String getOnlineUserName(String cardNo, String instCode) {
		loggerUtil.logMethodEntry("getOnlineUserName");
		String onlineUserName="";
		StringBuffer sql = new StringBuffer();
		
		/*sql.append(" SELECT ccm_user_name from cms_appl_pan,cms_cust_mast");
		sql.append(" WHERE cap_inst_code = ccm_inst_code  ");
		sql.append(" AND cap_cust_code   = ccm_cust_code ");
		sql.append(" AND cap_pan_code    = getHash(?)");
		sql.append(" AND cap_inst_code   = ? ");*/
		
		/*sql.append(" SELECT decode(cpc_encrypt_enable,'Y',fn_dmaps_main(ccm_user_name),ccm_user_name) ccm_user_name from cms_appl_pan,cms_cust_mast,cms_prod_cattype ");
		sql.append(" WHERE cap_inst_code = ccm_inst_code  ");
		sql.append(" AND cap_cust_code   = ccm_cust_code  and cap_inst_code=cpc_inst_code and cap_prod_code=cpc_prod_code and cap_card_type=cpc_card_type ");
		sql.append(" AND cap_pan_code    = getHash(?)");
		sql.append(" AND cap_inst_code   = ? ");*/
		sql.append(" SELECT fn_dmaps_main(ccm_user_name) from cms_appl_pan,cms_cust_mast");
		sql.append(" WHERE cap_inst_code = ccm_inst_code  ");
		sql.append(" AND cap_cust_code   = ccm_cust_code ");
		sql.append(" AND cap_pan_code    = getHash(?)");
		sql.append(" AND cap_inst_code   = ? ");
		loggerUtil.debug("Query To Get Online User Name : "+sql.toString());
		loggerUtil.debug("instCode "+instCode);
		
		try{
			onlineUserName=getSimpleJdbcTemplate().queryForObject(sql.toString(),String.class,cardNo,instCode);
			if(onlineUserName!=null && !"".equals(onlineUserName)){}
			else{
				onlineUserName="Customer Not Registered";
			}
		}
		catch(Exception e){
			loggerUtil.error("Error Occurred In getOnlineUserName Method : "+e,e);
			onlineUserName="";
		}
		
		loggerUtil.logMethodExit("getOnlineUserName");
		return onlineUserName;
	}

	/**
	 * This method will return the APYE value calculate from tables as below logic :-
	 * 1. First it will chaeck any recent APYE value exist on CMS_INTEREST_DETL, if value found the same value considered as APYE.
	 * 2. If value not found in above table then it will check for any recent APYE value exist on CMS_INTEREST_DETL_HIST, if value found the same value considered as APYE.
	 * 3. in both above case no record found default APYE value will be set as '0.00'.
	 * 4. If any Exception found during fetching all above queries, default  APYE value will be set as '0.00'.
	 */	
	@Override
	public String getInterestRate(AccountStatement beanVal)throws Exception {
		loggerUtil.logMethodEntry("getInterestRate");		
		String interestRate=null;
		try{			
			
			String sqlIntrstRate=
				" select cid_interest_rate "+
				" FROM CMS_INTEREST_DETL A "+
				" WHERE A.CID_ACCT_NO =? "+
				" AND cid_inst_code   =? "+
				" and a.CID_CALC_DATE = "+
				" (SELECT MAX(B.CID_CALC_DATE) "+
				" FROM CMS_INTEREST_DETL B "+
				" WHERE B.CID_ACCT_NO                 = ? "+
				" and CID_INST_CODE                   = ? "+
				" and TO_CHAR(CID_CALC_DATE,'MMYYYY') = ? "+
				" ) ";
			
			loggerUtil.debug("Check IntersetRate from CMS_INTEREST_DETL table : "+sqlIntrstRate);
			
			interestRate=getSimpleJdbcTemplate().queryForObject(sqlIntrstRate,String.class,beanVal.getAccountNumber(),beanVal.getInstCode(),beanVal.getAccountNumber(),beanVal.getInstCode(),beanVal.getToMonth()+beanVal.getToYear());			
			
			loggerUtil.debug("Check IntersetRate from CMS_INTEREST_DETL table interestRate: "+interestRate);
			
		}
		catch(EmptyResultDataAccessException emty) {
			try{
				String sqlIntrstHistRate=
					" select cid_interest_rate "+
					" FROM CMS_INTEREST_DETL_HIST A "+
					" WHERE A.CID_ACCT_NO =? "+
					" AND cid_inst_code   =? "+
					" and a.CID_CALC_DATE = "+
					" (SELECT MAX(B.CID_CALC_DATE) "+
					" FROM CMS_INTEREST_DETL_HIST B "+
					" WHERE B.CID_ACCT_NO                 = ? "+
					" and CID_INST_CODE                   = ? "+
					" and TO_CHAR(CID_CALC_DATE,'MMYYYY') = ? "+
					" ) ";
				
				loggerUtil.debug("Check IntersetRate from CMS_INTEREST_DETL_HIST table : "+sqlIntrstHistRate);
				
				interestRate=getSimpleJdbcTemplate().queryForObject(sqlIntrstHistRate,String.class,beanVal.getAccountNumber(),beanVal.getInstCode(),beanVal.getAccountNumber(),beanVal.getInstCode(),beanVal.getToMonth()+beanVal.getToYear());			
				
				loggerUtil.debug("Check IntersetRate from CMS_INTEREST_DETL_HIST table interestRate: "+interestRate);	
								
			}
			catch(EmptyResultDataAccessException emtyHist) {
				loggerUtil.error("No Records Found in CMS_INTEREST_DETL_HIST table : ",emtyHist);	
				interestRate= "0.00";				
			}
			catch (Exception e) {
				loggerUtil.error("Error Occurred While getting APYE Amount from CMS_INTEREST_DETL_HIST table : "+e,e);	
				interestRate= "0.00";
			}
		}
		catch (Exception e) {
			loggerUtil.error("Error Occurred While getting APYE Amount from CMS_INTEREST_DETL table : "+e,e);	
			interestRate= "0.00";
		}		
		loggerUtil.logMethodExit("getInterestRate");
		return interestRate;
	}
	
	@Override
	public String getAPYEamount(AccountStatement beanVal)throws Exception {
		loggerUtil.logMethodEntry("getAPYEamount");		
		String apyeAmount=null;
		String startDate=null;
		try{			
			
			String sqlApyeAmountDetl=
				" select round((power (1+(round(sum(cid_interest_amount),2) / trunc(avg((cid_close_balance +(select nvl(sum(cid_qtly_interest_accr),0) " +
				" from CMS_INTEREST_DETL where CID_ACCT_NO=? and cid_inst_code=? " +
				" and trunc(cid_calc_date) = last_day(to_date(?,'DDMMYYYY')-1)   ))    -cid_interest_amount) " +
				" *(trunc(max(cid_calc_date)-min(cid_calc_date)+1) / to_char(last_day(max(cid_calc_date)),'dd')),2)), " +
				" (365/to_char(last_day(max(cid_calc_date)),'dd')))-1)*100,2) as p_percentage_yield " +
				" FROM CMS_INTEREST_DETL  WHERE CID_ACCT_NO=? and cid_inst_code=? " +
				" and trunc(cid_calc_date) between to_date(?,'DDMMYYYY') and Last_day(to_date( ?,'DDMMYYYY'))"; 
             					
			loggerUtil.debug("Check sqlApyeAmountDetl : "+sqlApyeAmountDetl);
			startDate="01"+beanVal.getToMonth()+beanVal.getToYear();
			
			apyeAmount=getSimpleJdbcTemplate().queryForObject(sqlApyeAmountDetl,String.class,beanVal.getAccountNumber(),beanVal.getInstCode(),startDate,beanVal.getAccountNumber(),beanVal.getInstCode(),startDate,startDate);			
			
			loggerUtil.debug("Check apyeAmount detl val : "+apyeAmount);
			
			if(apyeAmount == null)
			{
				String sqlApyeAmountDetlHist=
					" select round((power (1+(round(sum(cid_interest_amount),2) / trunc(avg((cid_close_balance +(select nvl(sum(cid_qtly_interest_accr),0) " +
					" from CMS_INTEREST_DETL_HIST where CID_ACCT_NO=? and cid_inst_code=? " +
					" and trunc(cid_calc_date) = last_day(to_date(?,'DDMMYYYY')-1)   ))    -cid_interest_amount) " +
					" *(trunc(max(cid_calc_date)-min(cid_calc_date)+1) / to_char(last_day(max(cid_calc_date)),'dd')),2)), " +
					" (365/to_char(last_day(max(cid_calc_date)),'dd')))-1)*100,2) as p_percentage_yield " +
					" FROM CMS_INTEREST_DETL_HIST  WHERE CID_ACCT_NO=? and cid_inst_code=? " +
					" and trunc(cid_calc_date) between to_date(?,'DDMMYYYY') and Last_day(to_date( ?,'DDMMYYYY'))"; 
	             					
				loggerUtil.debug("Check sqlApyeAmountDetlHist : "+sqlApyeAmountDetlHist);
				startDate="01"+beanVal.getToMonth()+beanVal.getToYear();
				
				apyeAmount=getSimpleJdbcTemplate().queryForObject(sqlApyeAmountDetlHist,String.class,beanVal.getAccountNumber(),beanVal.getInstCode(),startDate,beanVal.getAccountNumber(),beanVal.getInstCode(),startDate,startDate);			
				
				loggerUtil.debug("Check apyeAmount detl hist val : "+apyeAmount);
				if(apyeAmount == null)
				{
					apyeAmount="0.00";
				}
			}
							
		}		
		catch (Exception e) {
			loggerUtil.error("Error Occurred While getting APYE Amount : "+e,e);	
			apyeAmount= "0.00";			
		}		
		loggerUtil.logMethodExit("getAPYEamount");
		return apyeAmount;
	}
	
	//Added for MYCAN840
	@Override
	public HashMap<String,List<String>> getDDAFormMsgFields(String prodCode) {
		
		loggerUtil.logMethodEntry("getDDAFormMsgFields");		
		final HashMap<String,List<String>> map=new HashMap<String,List<String>>();						
		StringBuffer msgFieldsQuery = new StringBuffer();
		
		msgFieldsQuery.append(" SELECT vdm_support_lang,vdm_field1_msg,vdm_field2_msg,vdm_field3_msg,vdm_field4_msg,vdm_field5_msg,vdm_field6_msg,");  
		msgFieldsQuery.append(" vdm_field7_msg,vdm_field8_msg,vdm_field9_msg  ");		
		msgFieldsQuery.append("  from vms_dda_form_msg WHERE vdm_prod_code = ?");				
		
		try{
			ParameterizedRowMapper<List<String>> mapper = new ParameterizedRowMapper<List<String>>() {
				public List<String> mapRow(ResultSet rs, int rowNum)
						throws SQLException {				
					List<String> lst=new ArrayList<String>();
					
					lst.add(rs.getString(2));
					lst.add(rs.getString(3));
					lst.add(rs.getString(4));
					lst.add(rs.getString(5));
					lst.add(rs.getString(6));
					lst.add(rs.getString(7));
					lst.add(rs.getString(8));
					lst.add(rs.getString(9));
					lst.add(rs.getString(10));					
											
					map.put(rs.getString(1),lst);				
					
					return lst;
				}
			};
			getSimpleJdbcTemplate().query(msgFieldsQuery.toString(), mapper,prodCode);
			
		}
		catch(Exception e){
			loggerUtil.error("Error Occurred In getOnlineUserName Method : "+e,e);			
		}
		
		loggerUtil.logMethodExit("getDDAFormMsgFields");
		return map;
	}

	@Override
	public String getYTDFeeAmount(AccountStatement acctstmt) {
		loggerUtil.logMethodEntry("getYTDFeeAmount");		
		String ytdAmt=null;		
		final HashMap<String,String> map=new HashMap<String,String>();	
		try{			
			
			String ytdAmtQry=
					"select to_char(sum(decode(CSL_TRANS_TYPE,'DR',1,-1)*NVL (CSL_TRANS_AMOUNT, 0)), '9,999,999,990.99') CSL_TRANS_AMOUNT "+
					"from cms_statements_log  "+
					"where csl_acct_no=?   "+
					"and TO_CHAR(csl_Ins_Date,'YYYYMM') between ? and ? "+
					"and txn_fee_flag='Y' AND CSL_INST_CODE= ?";	
					
             					
			loggerUtil.debug("Check ytdAmtQry : "+ytdAmtQry);			
			if(!acctstmt.getYear().equals(acctstmt.getToYear()))
			{
				ytdAmt=" ";
			}else{
				
			ytdAmt=getSimpleJdbcTemplate().queryForObject(ytdAmtQry,String.class,acctstmt.getAccountNumber(),
					acctstmt.getYear()+"01",acctstmt.getToYear()+acctstmt.getToMonth()
					,acctstmt.getInstCode());			
											
				if(ytdAmt==null)
				{
					ytdAmt="0.00";
				}
				ytdAmt=ytdAmt.trim();
			}
			loggerUtil.debug("Get apyeAmount val : "+ytdAmt);				
		}		
		catch (Exception e) {
			loggerUtil.error("Error Occurred While getting getYTDFeeAmount : "+e,e);	
			ytdAmt= "0.00";			
		}		
		loggerUtil.logMethodExit("getYTDFeeAmount");
		return ytdAmt;
	}
	
	@Override
	public String getPreviousMonthFee(AccountStatement acctstmt) {
		loggerUtil.logMethodEntry("getPreviousMonthFee");		
		String PreviousMonthFeearray[]=null;
		String PreviousMonthFee=null;
		final HashMap<String,String> map=new HashMap<String,String>();	
		try{			
			
			String PreviousMonthFeeqry=
					" with DATE_CALC as   (SELECT to_date('01' || ?,'DDMMYYYY') l_start_date, to_date(to_char(last_day(to_date('01' || ?,'DDMMYYYY')),'ddmmyyyy')||'23:59:59','ddmmyyyyhh24:mi:ss') l_end_date, "+
			        " ADD_MONTHS( to_date(to_char(last_day(to_date('01' || ?,'DDMMYYYY')),'ddmmyyyy')||'23:59:59','ddmmyyyyhh24:mi:ss'),-1) l_prev_end_date "+
					" from dual)  select TO_CHAR(nvl(sum(case when csl_ins_date  between  A.l_start_date  and A.l_end_date then (decode(csl_trans_type,'DR',csl_trans_amount,'CR',-csl_trans_amount))  "+
					" else 0 end),0),'9,999,999,990.99') ||':'|| TO_CHAR(nvl(sum(case when csl_ins_date between  ADD_MONTHS(A.l_start_date,-1)  and l_prev_end_date then"+
                    " (decode(csl_trans_type,'DR',csl_trans_amount,'CR',-csl_trans_amount)) else   "+
					" 0 end),0),'9,999,999,990.99') ||':'|| INITCAP(to_char(ADD_MONTHS(A.l_start_date,-1),'MONTH')) ||':'||  TO_CHAR(LAST_DAY(add_months(a.l_start_date,-1)),'DD') || ':' || to_char(ADD_MONTHS(A.l_start_date,-1),'YYYY') as previousFee  from cms_statements_log, DATE_CALC A where csl_inst_code = 1 and csl_acct_no = ?"+
					"and TXN_FEE_FLAG = 'Y' and csl_ins_date between ADD_MONTHS(A.l_start_date,-1)  and A.l_end_date";	
					
             					
			loggerUtil.debug("Check PreviousMonthFeeqry : "+PreviousMonthFeeqry);			
			
				
			
			
			
			 PreviousMonthFee = getSimpleJdbcTemplate().queryForObject(PreviousMonthFeeqry.toString(),String.class,acctstmt.getMonth()+acctstmt.getYear(),acctstmt.getToMonth()+acctstmt.getToYear(),acctstmt.getMonth()+acctstmt.getYear(),acctstmt.getAccountNumber());
											
				
			
			loggerUtil.debug("Get Previuos month Fee : "+PreviousMonthFee);				
		}		
		catch (Exception e) {
			loggerUtil.error("Error Occurred While getting PreviousMonthFeeqry : "+e,e);	
				
		}		
		loggerUtil.logMethodExit("getPreviousMonthFee");
		return PreviousMonthFee;
	}
}