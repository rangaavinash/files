package com.fss.csr.preauth.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import oracle.jdbc.OracleTypes;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import com.fss.csr.common.bean.KeyValueBean;
import com.fss.csr.common.util.CMSUtils;
import com.fss.csr.common.util.CSRUtils;
import com.fss.csr.common.util.CmsConstants;
import com.fss.csr.common.util.cmsParameters;
import com.fss.csr.common.util.fileupload.bean.FileBean;
import com.fss.csr.common.util.logger.LoggerUtil;
import com.fss.csr.preauth.bean.PreAuthReversal;
import com.fss.csr.prm.action.PRMBD;


/**
* 
*==========================================================================================================
*   Version      Date          Author                Reason
*==========================================================================================================
*     1.0      15-02-12       Abhaynarayan R      Initial Version    
*     1.1      16-05-12       Dnyaneshwar J       Add new IN parameter for calling sp_preauth_hold_release
*     1.2	   24-05-12		  Dnyaneshwar J       removed NA which is applied to merchant parameters
*     1.3      23-05-12       Abhaynarayan R      For Date Format MM/DD/YYYY
*     1.4	   24-05-12		  Dnyaneshwar J		  remove NA from merchant parameters
*     1.5      13-07-12       Lince J             For PRM Changes 
*     1.6      23-07-12       Dnyaneshwar J		  update file table on successfull preauth transaction. 
*     1.7      25-07-12       Dnyaneshwar J		  update account number into file table
*     1.8      30-07-12       Lince J             Add User Id in PRM 
*     1.9      24-08-12       Abhaynarayan R      For Debug Enable Flag
*     2.0      31-08-12       Dnyaneshwar J       Set SP Out parameter
*     2.1      11-09-12       Dnyaneshwar J       add Amount validation in query.
*     2.2      13-09-12       Abhay R             Added order by Clause for Posting Date
*     2.3      14-09-12       Abhay R             For IN Parameter for Sp Original Txn Code & Original DEl Channel
*     2.4      20-09-12       Lince J             Changed query- Removed checking Preauth Completed condition
*     2.5      21-09-12       Dnyaneshwar J		  Change column name to display total hold amount.
*     2.6      24-09-12       Abhay R		  	  Changes done for amount Format & Query Change for GPR Card Replacement.
*     2.7      25-09-12       Dnyaneshwar J       apply formating method while displaying amount on preauth successfull completion.
*     2.8      01-10-12       Abhay R             Display Proper Error message.
*     2.9      07-10-12       Dnyaneshwar J	 	  Changes done for ipAddress logging.
*     3.0      26-10-12       Dnyaneshwar J	 	  add column which Update file upload stat column in update method.
*     3.1      30-01-13       Abhay R	          Add tranRowdid concept to fire pop-up query 
*     3.2      27-02-13       Dnyaneshwar J		  changes made in Hold query comment out Reversal flag 
*     3.3      30-09-13       Dnyaneshwar J		  Modify calling SP part to pass new parameter for
*     												MVCSD-4480:Pre-Auth on Starter Card Won't Release on Personalized Card 
*     3.4      25-10-13       Dnyaneshwar J		  Modify preauth hold query to display preauth transaction details (Production Issue LYFEHOST-714)
*     3.5      17-01-14       Narsing I			  Modify the preauth reversal successful for matis Id-0013472
*     3.6      13-03-14  	  Dnyaneshwar J	      Added Code for Claw back recovery Mantis : 13886
*==========================================================================================================
*This Class is used for Pre Auth Reversal.
*/
public class PreAuthReversalDaoImpl  extends SimpleJdbcDaoSupport implements PreAuthReversalDao{

	private final static String CLASS_NAME="PreAuthReversalDaoImpl";
	private LoggerUtil loggerUtil = new LoggerUtil(CLASS_NAME);
	private SimpleJdbcTemplate simpleJdbcTemplate;
	HashMap PRMHashMap=new HashMap<String, String>();
	public PRMBD prm;
	public PRMBD getPrm() {
		return prm;
	}


	public void setPrm(PRMBD prm) {
		this.prm = prm;
	}
	public SimpleJdbcTemplate getSimpleJdbcTemplate() {
		return simpleJdbcTemplate;
	}

	public void setSimpleJdbcTemplate(SimpleJdbcTemplate simpleJdbcTemplate) {
		
		this.simpleJdbcTemplate = simpleJdbcTemplate;
	
	}

	public List<PreAuthReversal> getTxnAppliedForPreAuth(String cardNumber)
			throws Exception {
		try{
			loggerUtil.logMethodEntry("getTxnAppliedForPreAuth");
			 List <PreAuthReversal> list= new ArrayList<PreAuthReversal>();
			 String feeDtlQuery= new String();
			 
			 if(cmsParameters.ORDER_POSTING_DATE_FLAG!=null && cmsParameters.ORDER_POSTING_DATE_FLAG.equalsIgnoreCase("YES"))
				{
				 feeDtlQuery ="SELECT rrn TransactionID,business_date,business_time," +
				 			   " txn_code,delivery_channel,CUSTOMER_CARD_NO_ENCR customer_card_no," +
				 			   "fn_dmaps_main (customer_card_no_encr), rrn,fn_emaps_main(a.ROWID) tranRowId,"+
				 			   " TO_CHAR (TO_DATE (business_date, 'yyyymmdd'), '"+CMSUtils.DATEFORMAT+"') Bdate,"+
							   " TO_CHAR (TO_DATE (business_time, 'hh24miss'), 'hh24:mi:ss') Btime,"+
							   " (SELECT cdm_channel_desc"+
							   " FROM cms_delchannel_mast"+
							   " WHERE cdm_channel_code = delivery_channel) delivery_channel,"+
							   " fn_emaps_main(a.ROWID) feerowid, ctm_tran_desc,"+
							   " to_char(CPT_TOTALHOLD_AMT,'"+CMSUtils.AMTFORMAT+"') amount,"+//Added by Dnyaneshwar J on 21 Sept 2012
							   //" to_char(CPT_TXN_AMNT,'"+CMSUtils.AMTFORMAT+"') amount,"+//Changed by Dnyaneshwar J on 21 Sept 2012
							   " to_char(ACCT_BALANCE,'"+CMSUtils.AMTFORMAT+"') availablebalance,to_char(LEDGER_BALANCE,'"+CMSUtils.AMTFORMAT+"')  ledgerbalance,"+
							   " DECODE (response_code, '00', 'Approved', 'Decline') response,"+
							   " case when nvl(reversal_code,0) = 0 and CTM_CREDIT_DEBIT_FLAG IN('CR','DR','NA') THEN CTM_CREDIT_DEBIT_FLAG "+//Added by Dnyaneshwar J on 03 Jul 2012
						       " WHEN nvl(reversal_code,0) <> 0 AND  CTM_CREDIT_DEBIT_FLAG ='CR' THEN 'DR' "+
						       " WHEN nvl(reversal_code,0) <> 0 AND  CTM_CREDIT_DEBIT_FLAG ='DR' THEN 'CR' "+
						       " WHEN nvl(reversal_code,0) <> 0 AND  CTM_CREDIT_DEBIT_FLAG ='NA' THEN 'NA' "+
						       " END CRDR_FLAG "+
							   " FROM transactionlog a, cms_preauth_transaction, cms_transaction_mast"+
							   " WHERE instcode = cpt_inst_code"+
							   " AND customer_card_no = CPT_CARD_NO"+
							   " AND rrn = cpt_rrn"+
							   " AND business_date = CPT_TXN_DATE"+
							   " AND business_time = CPT_TXN_TIME"+
							   " AND txn_code = ctm_tran_code"+
							   " AND DELIVERY_CHANNEL = ctm_delivery_channel"+
							//   " AND CPT_CARD_NO = gethash (?)"+
							   " AND CPT_CARD_NO in (SELECT CAP_PAN_CODE FROM cms_appl_pan WHERE CAP_ACCT_NO = "+
							   " (SELECT CAP_ACCT_NO  FROM CMS_APPL_PAN WHERE CAP_PAN_CODE = gethash (?) ))"+
							   " and CPT_PREAUTH_VALIDFLAG ='Y'"+
							   " and CPT_COMPLETION_FLAG ='N'"+
							   " and CPT_EXPIRY_FLAG ='N'"+
							   " and CPT_TOTALHOLD_AMT > 0"+
							//   " AND cpt_transaction_flag not in ('C','R')" +//Commented by Line J on 20 September 2012
							   //" AND cpt_transaction_flag <> 'R' " +//Commented by Dnyaneshwar J to display partial reversed preatuth transactions
							   " order by ADD_INS_DATE desc";
				}
			 else
			 {
				 feeDtlQuery ="SELECT rrn TransactionID,business_date,business_time," +
				 		   " txn_code,delivery_channel,CUSTOMER_CARD_NO_ENCR customer_card_no,fn_emaps_main(a.ROWID) tranRowId," +
				 		   "fn_dmaps_main (customer_card_no_encr), rrn,"+
			 			   " TO_CHAR (TO_DATE (business_date, 'yyyymmdd'), '"+CMSUtils.DATEFORMAT+"') Bdate,"+
						   " TO_CHAR (TO_DATE (business_time, 'hh24miss'), 'hh24:mi:ss') Btime,"+
						   " (SELECT cdm_channel_desc"+
						   " FROM cms_delchannel_mast"+
						   " WHERE cdm_channel_code = delivery_channel) delivery_channel,"+
						   " fn_emaps_main(a.ROWID) feerowid, ctm_tran_desc,"+
						   " to_char(CPT_TOTALHOLD_AMT,'"+CMSUtils.AMTFORMAT+"') amount,"+//Added by Dnyaneshwar J on 21 Sept 2012
						   //" to_char(CPT_TXN_AMNT,'"+CMSUtils.AMTFORMAT+"') amount,"+//Changed by Dnyaneshwar J on 21 Sept 2012
						   " to_char(ACCT_BALANCE,'"+CMSUtils.AMTFORMAT+"') availablebalance,to_char(LEDGER_BALANCE,'"+CMSUtils.AMTFORMAT+"')  ledgerbalance,"+
						   " DECODE (response_code, '00', 'Approved', 'Decline') response,"+
						   " case when nvl(reversal_code,0) = 0 and CTM_CREDIT_DEBIT_FLAG IN('CR','DR','NA') THEN CTM_CREDIT_DEBIT_FLAG "+//Added by Dnyaneshwar J on 03 Jul 2012
					       " WHEN nvl(reversal_code,0) <> 0 AND  CTM_CREDIT_DEBIT_FLAG ='CR' THEN 'DR' "+
					       " WHEN nvl(reversal_code,0) <> 0 AND  CTM_CREDIT_DEBIT_FLAG ='DR' THEN 'CR' "+
					       " WHEN nvl(reversal_code,0) <> 0 AND  CTM_CREDIT_DEBIT_FLAG ='NA' THEN 'NA' "+
					       " END CRDR_FLAG "+
						   " FROM transactionlog a, cms_preauth_transaction, cms_transaction_mast"+
						   " WHERE instcode = cpt_inst_code"+
						   " AND customer_card_no = CPT_CARD_NO"+
						   " AND rrn = cpt_rrn"+
						   " AND business_date = CPT_TXN_DATE"+
						   " AND business_time = CPT_TXN_TIME"+
						   " AND txn_code = ctm_tran_code"+
						   " AND DELIVERY_CHANNEL = ctm_delivery_channel"+
							//   " AND CPT_CARD_NO = gethash (?)"+
						   " AND CPT_CARD_NO in (SELECT CAP_PAN_CODE FROM cms_appl_pan WHERE CAP_ACCT_NO = "+
						   " (SELECT CAP_ACCT_NO  FROM CMS_APPL_PAN WHERE CAP_PAN_CODE = gethash (?) ))"+
						   " and CPT_PREAUTH_VALIDFLAG ='Y'"+
						   " and CPT_COMPLETION_FLAG ='N'"+
						   " and CPT_EXPIRY_FLAG ='N'"+
						   " and CPT_TOTALHOLD_AMT > 0"+
						//   " AND cpt_transaction_flag not in ('C','R')" +//Commented by Line J on 20 September 2012
						  // " AND cpt_transaction_flag <> 'R' " +//Commented by Dnyaneshwar J to display partial reversed preatuth transactions
						   " order by TO_DATE (business_date||' '||business_time, 'yyyymmdd hh24miss') desc";
				 
			 }
				 if(loggerUtil.isDebugEnabled())
					{
					 	loggerUtil.debug("Query in getTxnAppliedForPreAuth()===="+feeDtlQuery);
					}
			 
			 List <PreAuthReversal> feeList= new ArrayList <PreAuthReversal> ();
			 
			 try{
	
	            ParameterizedRowMapper<PreAuthReversal> mapper = new ParameterizedRowMapper<PreAuthReversal>() {
					public PreAuthReversal mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						PreAuthReversal userTxnDet = new PreAuthReversal();
						//userTxnDet.setCardNumber(rs.getString("customer_card_no_encr"));
						userTxnDet.setRrn(rs.getString("rrn"));
						userTxnDet.setTransDate(rs.getString("Bdate"));
						userTxnDet.setTransTime(rs.getString("Btime"));
						userTxnDet.setAvailblBal("$ "+rs.getString("availablebalance"));
						userTxnDet.setAcctBal("$ "+rs.getString("ledgerbalance"));
						userTxnDet.setTxnAmt("$ "+rs.getString("amount"));
						//userTxnDet.setTxnFeeAmt(rs.getString("tranfee"));
						userTxnDet.setTxnType(rs.getString("ctm_tran_desc"));
						userTxnDet.setHidBdate(rs.getString("business_date"));
						userTxnDet.setHidBtime(rs.getString("business_time"));
						userTxnDet.setHidViewCardNo(rs.getString("customer_card_no"));
						userTxnDet.setHidRrn(rs.getString("TransactionID"));
						userTxnDet.setHidViewTxnCode(rs.getString("txn_code"));
						userTxnDet.setHidDeliveryChanl(rs.getString("delivery_channel"));
						userTxnDet.setTranRowId(rs.getString("tranRowId"));//Added by abhay J on 30 Jan 2013
						userTxnDet.setResponseCode(rs.getString("response"));
						userTxnDet.setRowId(rs.getString("feerowid"),rs.getString("response"));
						userTxnDet.setDrCrFlag(rs.getString("CRDR_FLAG"));//Added by Dnyaneshwar J on 03 Jul 2012 
											
						return userTxnDet;
					}
				};
				feeList = getSimpleJdbcTemplate().query(feeDtlQuery, mapper,cardNumber);
				
				if (list != null) {
					if(loggerUtil.isDebugEnabled())
					{
							loggerUtil.debug("No of Rows returns after search in viewTxnApplyForPreAuthList()  " + feeList.size());
					}
				}
			 
			 }
			 catch (Exception e) {
				 if(loggerUtil.isDebugEnabled())
					{
					 loggerUtil.debug("Error occured while fetching records from table : "+e.getMessage());
					}
				e.printStackTrace();
			}
			 
			 loggerUtil.logMethodExit("getTxnAppliedForPreAuth");
			 return feeList;
		}
		catch (Exception e) {
			throw(e);
		}

	}
	
	public PreAuthReversal doPreAuthReversTxn(PreAuthReversal preAuthReversal)throws Exception{
		try{
			loggerUtil.logMethodEntry("doPreAuthReversTxn");
			PreAuthReversal preAuthRevTxnOut=new PreAuthReversal();
			PreAuthReversal txnRecrd=null;
			
			
			String deliveryChannel=CmsConstants.DELIVERY_CHANNEL;
			String [] result = new String[3];
		
			KeyValueBean keyValue=new KeyValueBean();
		    CSRUtils csrUtil= new CSRUtils();
		    csrUtil.setSimpleJdbcTemplate(getSimpleJdbcTemplate());
		    keyValue = csrUtil.getSeqNoForRRNAndStan();
		    
		    DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		    Date l_date = new Date();
		    String formateddate=dateFormat.format(l_date);
			String trandate=formateddate.substring(0, 8);
			String trantime=formateddate.substring(8);
	    
	    String sqlGetOrgnlTxnDtl=
				"SELECT " +
				" fn_dmaps_main(customer_card_no_encr) CardNumber,rrn, system_trace_audit_no,terminal_id," +
				" fn_maskpan_csr (?, customer_card_no_encr,?) dispOrgnlMaskPAN ,"+//Modified by Dnyaneshwar J on 26 Sept 2013
				" business_date, business_time,  nvl(TO_CHAR(amount,'"+CMSUtils.AMTFORMAT+"'),'0.00') amount, " +
		 		" txn_code, delivery_channel,tranfee_amt," +
		 		" to_char(sysdate, 'yyyymmdd') CurrDate,to_char(sysdate,'hh24miss') CurrTime," +
		 		" trans_desc,TO_CHAR(to_date(business_date,'yyyymmdd'),'"+CMSUtils.DATEFORMAT+"')  diispDate," +
		 		" TO_CHAR(to_date(business_time,'hh24miss'),'hh24:mi:ss') diispTime " +
		 		" FROM " +
	 			" TRANSACTIONLOG " +
	 			" WHERE " +
	 			" rowid=?";
	    if(loggerUtil.isDebugEnabled())
		{
	    loggerUtil.debug(" sqlGetOrgnlTxnDtl "+sqlGetOrgnlTxnDtl);
		loggerUtil.debug(" variable "+preAuthReversal.getHidRowId());
		}
		
		ParameterizedRowMapper<PreAuthReversal> mapper = new ParameterizedRowMapper<PreAuthReversal>() {
			public PreAuthReversal mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				PreAuthReversal userTxnDet = new PreAuthReversal();
				
				userTxnDet.setOrgnlTranDate(rs.getString("business_date"));
				userTxnDet.setOrgnlTranTime(rs.getString("business_time"));
				userTxnDet.setOrgnlTxnAmt(rs.getString("amount").trim());
				userTxnDet.setOrgnlTxnCode(rs.getString("txn_code"));
				userTxnDet.setOrgnlRRN(rs.getString("rrn"));
				userTxnDet.setOrgnlTermId(rs.getString("terminal_id"));
				userTxnDet.setOrgnlDeliveryChannel(rs.getString("delivery_channel"));
				userTxnDet.setOrgnlMaskPAN(rs.getString("dispOrgnlMaskPAN"));//Added by Dnyaneshwar J on 30 Sept 2013
				userTxnDet.setOrgnlPAN(rs.getString("CardNumber"));//Added by Dnyaneshwar J on 30 Sept 2013
				if(loggerUtil.isDebugEnabled())
				{
				loggerUtil.debug("Details -----------");
				loggerUtil.debug("Original TRAN DATE "+userTxnDet.getOrgnlTranDate());
				loggerUtil.debug("Original TRAN TIME "+userTxnDet.getOrgnlTranTime());
				loggerUtil.debug("Original TRAN AMT "+userTxnDet.getOrgnlTxnAmt());
				loggerUtil.debug("Original TRAN CODE "+userTxnDet.getOrgnlTxnCode());
				loggerUtil.debug("Original delivery_channel "+userTxnDet.getOrgnlDeliveryChannel());
				loggerUtil.debug("Original RRN "+userTxnDet.getOrgnlRRN());
				loggerUtil.debug("Original TerMInal Id "+userTxnDet.getOrgnlTermId());
				}
									
				return userTxnDet;
			}
		};

		loggerUtil.debug("Inst Code : "+preAuthReversal.getInstCode());
		loggerUtil.debug("User Id : "+preAuthReversal.getHidUserPin());
		txnRecrd = getSimpleJdbcTemplate().queryForObject(sqlGetOrgnlTxnDtl, mapper,preAuthReversal.getInstCode(),preAuthReversal.getHidUserPin(),preAuthReversal.getHidRowId());//Modified by Dnyaneshwar J on 26 Sept 2013

		if (txnRecrd != null) {
					loggerUtil.debug("No of Rows returns after search in   " + txnRecrd);
		}
		
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(getDataSource());	
		simpleJdbcCall = simpleJdbcCall.withProcedureName("sp_preauth_hold_release");
		simpleJdbcCall = simpleJdbcCall.withSchemaName(cmsParameters.getProperty("SCHEMANAME")).declareParameters(
				 new SqlParameter("prm_inst_code",OracleTypes.NUMBER),
                 new SqlParameter("prm_msg_typ",OracleTypes.VARCHAR),
                 new SqlParameter("prm_rvsl_code",OracleTypes.VARCHAR),
                 new SqlParameter("prm_rrn",OracleTypes.VARCHAR),
                 new SqlParameter("prm_delv_chnl",OracleTypes.VARCHAR),
                 new SqlParameter("prm_terminal_id",OracleTypes.VARCHAR),
                 new SqlParameter("prm_merc_id",OracleTypes.VARCHAR),
                 new SqlParameter("prm_txn_code",OracleTypes.VARCHAR),
                 new SqlParameter("prm_txn_type",OracleTypes.VARCHAR),
                 new SqlParameter("prm_txn_mode",OracleTypes.VARCHAR),
                 new SqlParameter("prm_business_date",OracleTypes.VARCHAR),
                 new SqlParameter("prm_business_time",OracleTypes.VARCHAR),
                 new SqlParameter("prm_card_no",OracleTypes.VARCHAR),
                 new SqlParameter("prm_actual_amt",OracleTypes.VARCHAR),
                 new SqlParameter("prm_bank_code",OracleTypes.VARCHAR),
                 new SqlParameter("prm_stan",OracleTypes.VARCHAR),
                 new SqlParameter("prm_orgnl_business_date",OracleTypes.VARCHAR),
                 new SqlParameter("prm_orgnl_business_time",OracleTypes.VARCHAR),
                 new SqlParameter("prm_orgnl_txn_code",OracleTypes.VARCHAR),
                 new SqlParameter("prm_orgnl_delivery_chnl",OracleTypes.VARCHAR),
                 new SqlParameter("prm_orgnl_rrn",OracleTypes.VARCHAR),
                 new SqlParameter("prm_mbr_numb",OracleTypes.VARCHAR),
                 new SqlParameter("prm_orgnl_terminal_id",OracleTypes.VARCHAR),
                 new SqlParameter("prm_curr_code",OracleTypes.VARCHAR),
                 new SqlParameter("prm_remark",OracleTypes.VARCHAR),
                 new SqlParameter("prm_reason_code",OracleTypes.VARCHAR),
                 new SqlParameter("prm_reason_desc",OracleTypes.VARCHAR),
                 new SqlParameter("prm_call_id",OracleTypes.NUMBER),
                 new SqlParameter("prm_ins_user",OracleTypes.NUMBER),
                 new SqlParameter("prm_merchant_name",OracleTypes.VARCHAR),
                 new SqlParameter("prm_merchant_city",OracleTypes.VARCHAR),
                 new SqlParameter("prm_merc_state",OracleTypes.VARCHAR),
                 new SqlParameter("prm_ipaddress",OracleTypes.VARCHAR),
                 new SqlParameter("prm_call_card_no",OracleTypes.VARCHAR),
                 new SqlOutParameter("prm_resp_cde",OracleTypes.VARCHAR),
                 new SqlOutParameter("prm_acct_bal",OracleTypes.VARCHAR),
                 new SqlOutParameter("prm_resp_msg",OracleTypes.VARCHAR)
                 );		
		try{
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("SP parameters-----------------");
				loggerUtil.debug("SP parameters Name-->sp_preauth_hold_release");
				loggerUtil.debug("prm_inst_code"+Integer.parseInt(preAuthReversal.getInstCode()));
				loggerUtil.debug("prm_msg_typ"+preAuthReversal.getHidMsgType() );
				loggerUtil.debug("prm_rvsl_code"+preAuthReversal.getHidRevCode() );
				loggerUtil.debug("prm_rrn"+keyValue.getRRN() );//RRN
				loggerUtil.debug("prm_delv_chnl"+deliveryChannel );
				loggerUtil.debug("prm_terminal_id"+preAuthReversal.getTerminalId());//+txnRecrd.getOrgnlTranDate() );
				loggerUtil.debug("prm_merc_id"+" ");//+txnRecrd.getOrgnlTranTime() );
				loggerUtil.debug("prm_txn_code"+preAuthReversal.getHidTxnCode());
				loggerUtil.debug("prm_txn_type"+preAuthReversal.getTxnType() );//STAN
				loggerUtil.debug("prm_txn_mode"+preAuthReversal.getHidTxnMode());
				loggerUtil.debug("prm_business_date"+trandate );//Transaction date YYYYMMDD
				loggerUtil.debug("prm_business_time"+trantime );//Trnsaction time HHmmss
				
			}
				loggerUtil.logCardNumber(preAuthReversal.getCardNumber());//STAN
				if(loggerUtil.isDebugEnabled())
				{
				loggerUtil.debug("prm_actual_amt"+preAuthReversal.getTransAmt().trim() );
				loggerUtil.debug("prm_bank_code"+" ");
				loggerUtil.debug("prm_stan"+keyValue.getSTAN() );//STAN
				loggerUtil.debug("prm_orgnl_business_date"+txnRecrd.getOrgnlTranDate());//+txnRecrd.getOrgnlTranDate() );
				loggerUtil.debug("prm_orgnl_business_time"+txnRecrd.getOrgnlTranTime());//+txnRecrd.getOrgnlTranTime() );
				loggerUtil.debug("prm_orgnl_rrn"+txnRecrd.getOrgnlRRN() );
				loggerUtil.debug("prm_mbr_numb"+preAuthReversal.getHidMbrNumb() );
				loggerUtil.debug("prm_orgnl_terminal_id"+txnRecrd.getOrgnlTermId() );
				loggerUtil.debug("prm_curr_code"+preAuthReversal.getHidTxnCurrCode() );
				loggerUtil.debug("prm_merchant_name"+"" );
				loggerUtil.debug("prm_merchant_city"+"" );
				loggerUtil.debug("prm_call_id"+Integer.parseInt(preAuthReversal.getCallID()) );
				loggerUtil.debug("prm_ins_user"+preAuthReversal.getHidUserPin() );//Added by Dnyaneshwar J on 07 Oct 2012
				loggerUtil.logCardNumber(""+"");
				
				loggerUtil.debug("prm_orgnl_txn_code "+txnRecrd.getOrgnlTxnCode());    
				loggerUtil.debug("prm_orgnl_delivery_chnl "+txnRecrd.getOrgnlDeliveryChannel());
				loggerUtil.debug("reason Code===========>"+preAuthReversal.getHidReasonCode());
				loggerUtil.debug("reason Desc===========>"+preAuthReversal.getHidReasonTxt());
				loggerUtil.debug("remark Desc===========>"+preAuthReversal.getHidRemarkTxt());
				loggerUtil.debug("prm_ipaddress "+preAuthReversal.getIpAddress());
				}
				
				Map<String,Object> map = new HashMap();	
				map.put("prm_inst_code",Integer.parseInt(preAuthReversal.getInstCode()) );
				map.put("prm_msg_typ",preAuthReversal.getHidMsgType() );
				map.put("prm_rvsl_code",preAuthReversal.getHidRevCode() );
				map.put("prm_rrn",keyValue.getRRN() );//RRN
				map.put("prm_delv_chnl",deliveryChannel );
				map.put("prm_terminal_id",preAuthReversal.getTerminalId());//,txnRecrd.getOrgnlTranDate() );
				map.put("prm_merc_id","");//,txnRecrd.getOrgnlTranTime() );
				map.put("prm_txn_code",preAuthReversal.getHidTxnCode());
				map.put("prm_txn_type",preAuthReversal.getTxnType() );//STAN
				map.put("prm_txn_mode",preAuthReversal.getHidTxnMode());
				map.put("prm_business_date",trandate );//Transaction date YYYYMMDD
				map.put("prm_business_time",trantime );//Trnsaction time HHmmss
				map.put("prm_card_no",txnRecrd.getOrgnlPAN() );//Original PAN for which Preauth Hold is initiated Modified by Dnyaneshwar J on 30 Sept 2013
				map.put("prm_actual_amt",preAuthReversal.getTransAmt().trim() );
				map.put("prm_bank_code","");
				map.put("prm_stan",keyValue.getSTAN() );//STAN
				map.put("prm_orgnl_business_date",txnRecrd.getOrgnlTranDate());//,txnRecrd.getOrgnlTranDate() );
				map.put("prm_orgnl_business_time",txnRecrd.getOrgnlTranTime());//,txnRecrd.getOrgnlTranTime() );
				map.put("prm_orgnl_txn_code",txnRecrd.getOrgnlTxnCode() );
				map.put("prm_orgnl_delivery_chnl",txnRecrd.getOrgnlDeliveryChannel());
				map.put("prm_orgnl_rrn",txnRecrd.getOrgnlRRN() );
				map.put("prm_mbr_numb",preAuthReversal.getHidMbrNumb() );
				map.put("prm_orgnl_terminal_id",txnRecrd.getOrgnlTermId());
				map.put("prm_curr_code",preAuthReversal.getHidTxnCurrCode() );
				map.put("prm_merchant_name","");//removed NA by dnyaneshwar J on 24 May 2012
				map.put("prm_merchant_city","" );//removed NA by dnyaneshwar J on 24 May 2012
				map.put("prm_merc_state","" );//added by Dnyaneshwar J on 16 May 2012 new In parameter.
				map.put("prm_call_id",Integer.parseInt(preAuthReversal.getCallID()));
				map.put("prm_ins_user",preAuthReversal.getHidUserPin());
				map.put("prm_reason_code",preAuthReversal.getHidReasonCode());
				map.put("prm_reason_desc",preAuthReversal.getHidReasonTxt());
				map.put("prm_remark",preAuthReversal.getHidRemarkTxt());
				map.put("prm_ipaddress",preAuthReversal.getIpAddress());//Added by Dnyaneshwar J on 07 Oct 2012
				map.put("prm_call_card_no",preAuthReversal.getCardNumber());//Added by Dnyaneshwar J on 30 Sept 2013
				
				SqlParameterSource in = new MapSqlParameterSource().addValues(map);				
				Map <String , Object> out  =  simpleJdbcCall.execute(in);
				if(loggerUtil.isDebugEnabled())
				{
					loggerUtil.debug("Pre Autth  procedure out "+out);
				}
				
				result[0] = (String) out.get("prm_resp_cde");
				result[1] = (String) out.get("prm_acct_bal");
				result[2] = (String) out.get("prm_resp_msg");
				if(loggerUtil.isDebugEnabled())
				{
				loggerUtil.debug("result[0] "+result[0]);
				loggerUtil.debug("result[1] "+result[1]);
				loggerUtil.debug("result[2] "+result[2]);
				loggerUtil.debug("SP Executed......");
				}
				
				preAuthRevTxnOut.setClosingBalance((String)out.get("prm_acct_bal"));
				preAuthRevTxnOut.setCheckAttrib((String)out.get("prm_resp_cde"));
				
				if(result[0]=="00" || result[2].equals("OK")){
					//added by Dnyaneshwar J on 25 July 2012
					if(loggerUtil.isDebugEnabled())
					{
					loggerUtil.debug("Account Number : "+preAuthReversal.getAccountNumber());
					}
					
					//Added by Dnyaneshwar J on 23 July 2012 to update the file upload table
					String updateTxnInFileTable="update cms_fileupload_detl set cfu_BUSINESS_DATE=?, cfu_BUSINESS_time=?," +
					" cfu_txn_code=?,cfu_delivery_channel=?,cfu_rrn=?,cfu_pan_code=gethash(?)," +
					" cfu_pan_code_encr=(select cap_pan_code_encr from cms_appl_pan where cap_pan_code=gethash(?)),CFU_ACCT_NO=?" +////added by Dnyaneshwar J on 25 July 2012
					" ,CFU_UPLOAD_STAT='C'" +//Added by Dnyaneshwar J on 26 oct 2012.
					" where cfu_ref_number=?";
					if(loggerUtil.isDebugEnabled())
					{
					loggerUtil.debug("Updaing record in cms_fileupload_detl table query : "+updateTxnInFileTable);
					}
					
					int rowsUpdate=getSimpleJdbcTemplate().update(updateTxnInFileTable,trandate,
							trantime,preAuthReversal.getHidTxnCode(),CmsConstants.DELIVERY_CHANNEL,keyValue.getRRN(),
							preAuthReversal.getCardNumber(),preAuthReversal.getCardNumber(),preAuthReversal.getAccountNumber(),txnRecrd.getOrgnlRRN());
					if(loggerUtil.isDebugEnabled())
					{
					loggerUtil.debug("No. of Rows Updated in cms_fileupload_detl table : "+rowsUpdate+" againast "+txnRecrd.getOrgnlRRN());
					}
					preAuthRevTxnOut.setSP_OUT_1(result[0]);
					preAuthRevTxnOut.setSP_OUT_3(result[2]);//Added by Dnyaneshwar J on 31 Aug 2012
					preAuthRevTxnOut.setSP_OUT_2("Reversal Successful"); //Modified by Narsing I on 17th Jan 2014 
					
					try{//sn-Added by Dnyaneshwar J on 13 Mar 2014 for Mantis-13886 
						StringBuffer sql = new StringBuffer();
						sql.append("select cap_pan_code from cms_appl_pan where cap_pan_code=gethash(?) and cap_inst_code=?");
						String hashPAN="";
						hashPAN=getSimpleJdbcTemplate().queryForObject(sql.toString(),String.class,txnRecrd.getOrgnlPAN(),preAuthReversal.getInstCode());
						
						loggerUtil.debug("Calling ClawBack Recovery SP for Successful Case...");
						String spClawBack="SP_CLAWBACK_RECOVERY";
						loggerUtil.debug(spClawBack);
						
						/*SimpleJdbcCall spClawBackCall = new SimpleJdbcCall(getDataSource());
						spClawBackCall = spClawBackCall.withProcedureName(spClawBack);
						spClawBackCall = spClawBackCall.withSchemaName(cmsParameters.getProperty("SCHEMANAME"));*/
						Connection con = null;
						CallableStatement cstmt = null;
						
						con = getDataSource().getConnection();
						cstmt = con.prepareCall("{call vmscms.SP_CLAWBACK_RECOVERY(?,?,?,?)}");
						cstmt.setString(1, userId);
						
					//	Map<String,Object> spMapInPrm = new HashMap<String, Object>();
						loggerUtil.debug("PRM_INST_CODE : "+Integer.parseInt(preAuthReversal.getInstCode()) );
						loggerUtil.debug("PRM_CARD_NO   : "+hashPAN);
						loggerUtil.debug("PRM_MBR_NUMB  : "+preAuthReversal.getHidMbrNumb() );
						
						cstmt.setString(1,Integer.parseInt(preAuthReversal.getInstCode()) );
						cstmt.setString(2,hashPAN );
						cstmt.setString(3,preAuthReversal.getHidMbrNumb() );
						cstmt.registerOutParameter(4, Types.VARCHAR);
						cstmt.executeUpdate();
						result = cstmt.getString(4);
						
						SqlParameterSource sqlPrmIn = new MapSqlParameterSource().addValues(spMapInPrm);				
						Map <String , Object> spMapOutPrm  =  spClawBackCall.execute(sqlPrmIn);
						if(spMapOutPrm!=null && spMapOutPrm.get("PRM_RESP_MSG")!=null){
							loggerUtil.debug("SP Out Parameter : "+spMapOutPrm.get("PRM_RESP_MSG"));
						}
					}
					catch (Exception e) {
						loggerUtil.error("Error Occured While Calling Clawback Recovery SP..."+e,e);
					}//en-Added by Dnyaneshwar J on 13 Mar 2014 for Mantis-13886
					finally {
						if (cstmt != null) {
							cstmt.close();
						}
						if (con != null) {
							con.close();
						}
					}
				}
				else{
					preAuthRevTxnOut.setSP_OUT_2("Reversal Failed"); //Modified by Narsing I on 17th Jan 2014 
					preAuthRevTxnOut.setSP_OUT_3((String)out.get("prm_resp_msg"));
					
					if(out.get("prm_resp_msg").toString().indexOf("ORA")>0){
						if(result[1]!="00"){
							preAuthRevTxnOut.setSP_OUT_3("Error Occured while Processing.");
						}
						else
							preAuthRevTxnOut.setSP_OUT_3(result[2]);
					}
					else{
						preAuthRevTxnOut.setSP_OUT_3("Reversal Failed "+(String)out.get("prm_resp_msg"));//Modified by Narsing I on 17th Jan 2014 
					}
					
				}
				
				//Displayin items on report jsp page
				preAuthRevTxnOut.setTransDate(preAuthReversal.getTransDate());
				preAuthRevTxnOut.setTransTime(preAuthReversal.getTransTime());
				preAuthRevTxnOut.setTxnAmt(csrUtil.getFormattedAmt(preAuthReversal.getTransAmt()));//Added by Dnyaneshwar J on 25 Sept 2012 to display the amount in proper format.
				preAuthRevTxnOut.setTransDesc(preAuthReversal.getTxnInfo());
				preAuthRevTxnOut.setCardNumber(txnRecrd.getHidCardNo());//Modified by Dnyaneshwar J on 26 Sept 2013
				
				//Below code added for PRM
				
				PRMHashMap.put(CmsConstants.PRM_DELIVERYCHNL, CmsConstants.DELIVERY_CHANNEL);
				PRMHashMap.put(CmsConstants.PRM_RRN, keyValue.getRRN());
				PRMHashMap.put(CmsConstants.PRM_BUSINESS_DATE, trandate);
				PRMHashMap.put(CmsConstants.PRM_BUSINESS_TIME, trantime);
				PRMHashMap.put(CmsConstants.PRM_INSTCODE,preAuthReversal.getInstCode());
				PRMHashMap.put(CmsConstants.PRM_CARDNO, preAuthReversal.getCardNumber());
				PRMHashMap.put(CmsConstants.PRM_TRANS_CODE,preAuthReversal.getHidTxnCode());
				PRMHashMap.put(CmsConstants.PRM_AMOUNT, preAuthReversal.getTransAmt());
				PRMHashMap.put(CmsConstants.PRM_REASON_CODE, preAuthReversal.getHidReasonCode());
				PRMHashMap.put(CmsConstants.PRM_BIN,preAuthReversal.getCardNumber().substring(0,6));
				PRMHashMap.put(CmsConstants.PRM_MSG_TYPE, preAuthReversal.getHidMsgType());
				PRMHashMap.put(CmsConstants.PRM_MEMB_NUM, preAuthReversal.getHidMbrNumb());
				PRMHashMap.put(CmsConstants.PRM_CURR_CODE, preAuthReversal.getHidTxnCurrCode());
				PRMHashMap.put(CmsConstants.PRM_ACCT_TYPE, "1");
				PRMHashMap.put(CmsConstants.PRM_INS_USER,preAuthReversal.getHidUserPin());
				PRMHashMap.put(CmsConstants.PRM_RESPONSE_CODE, result[0]);
				prm.getPRMBussinessService(PRMHashMap, result);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw(e);
		}
		
		//sn-Added by Dnyaneshwar J on 30 Sept 2013
		/**
		 * Following block will display PAN on result screen
		 */
		if(txnRecrd.getOrgnlMaskPAN()!=null && !("".equals(txnRecrd.getOrgnlMaskPAN()))){
			preAuthRevTxnOut.setOrgnlMaskPAN(txnRecrd.getOrgnlMaskPAN());
		}//en-Added by Dnyaneshwar J on 30 Sept 2013
		
		loggerUtil.logMethodExit("doPreAuthReversTxn");
		return preAuthRevTxnOut;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw(e);
			
		}
	}

	public PreAuthReversal getPreAuthReverslTxn(PreAuthReversal bean) throws Exception {//Modified by Dnyaneshwar J on 26 Sept 2013
		try{
			loggerUtil.logMethodEntry("getPreAuthReverslTxn");
			PreAuthReversal txnRecrd=null;
		 String feeDtlQuery= new String();

		 feeDtlQuery="SELECT fn_dmaps_main (customer_card_no_encr) CardNumber, rrn RRN,"+
		 	" fn_maskpan_csr (?, customer_card_no_encr,?) dispOrgnlMaskPAN ,"+
		   " TO_CHAR (TO_DATE (business_date, 'yyyymmdd'), '"+CMSUtils.DATEFORMAT+"') Bdate,"+
	       " TO_CHAR (TO_DATE (business_time, 'hh24miss'), 'hh24:mi:ss') Btime,"+
	       " (SELECT cdm_channel_desc"+
	          " FROM cms_delchannel_mast"+
	         " WHERE cdm_channel_code = delivery_channel) delivery_channel,"+
	       " a.ROWID feerowid, ctm_tran_desc,"+
	       " CPT_TOTALHOLD_AMT amount,a.terminal_id,a.txn_type,TO_CHAR(NVL(CPT_TOTALHOLD_AMT,0),'"+CMSUtils.AMTFORMAT+"') tranAmt, "+//Added by Dnyaneshwar J on 11 Sept 2012 for hold amount display 
	       " ACCT_BALANCE availablebalance, LEDGER_BALANCE ledgerbalance,"+
	       " DECODE (response_code, '00', 'Approved', 'Decline') response"+
	  " FROM transactionlog a, cms_preauth_transaction, cms_transaction_mast"+
	 " WHERE instcode = cpt_inst_code"+
	   " AND customer_card_no = CPT_CARD_NO"+
	   " AND rrn = cpt_rrn"+
	   " AND business_date = CPT_TXN_DATE"+
	   " AND business_time = CPT_TXN_TIME"+
	   " AND txn_code = ctm_tran_code"+
	   " AND DELIVERY_CHANNEL = ctm_delivery_channel"+
	  // " AND CPT_CARD_NO = gethash (?)"+
	   " and CPT_PREAUTH_VALIDFLAG ='Y'"+
	   " and CPT_COMPLETION_FLAG ='N'"+
	   " and CPT_EXPIRY_FLAG ='N'"+
	   " and CPT_TOTALHOLD_AMT > 0"+
	   " and CTM_PREAUTH_FLAG='Y' "+//en-Modified by Dnyaneshwar J on 25 Oct 2013 (Production Issue LYFEHOST-714)
	   " and CTM_INITIAL_PREAUTH_IND = 'Y' "+
	   " and response_code='00'  "+
	   " and CTM_CREDIT_DEBIT_FLAG='NA' "+//en-Modified by Dnyaneshwar J on 25 Oct 2013 (Production Issue LYFEHOST-714)
	   //" AND cpt_transaction_flag not in ('C','R')"+Commented by Dnyaneshwar J on 21 Sept 2012
	   //" AND cpt_transaction_flag <> 'R' "+ //Added by Dnyaneshwar J on 21 Sept 2012//commented by Dnyaneshwar J on 27 Feb 2013
		 
	   //" and TRAN_REVERSE_FLAG ='N'" +
	   " and a.rowid =fn_dmaps_main(?)";
			 
/*			 String test="select fn_getmaskpan(fn_dmaps_main(CSL_PAN_NO_ENCR)) CardNumber, "+
	        " csl_rrn  TransactionID,csl_trans_date  DateTime, "+   //Type,"+
	        " csl_trans_narrration Description, csl_trans_amount  Amount,csl_closing_balance Availablebalance, "+
	        " csl_closing_balance  ledgerbalance, " +
	        " rowid"+  
	        " from cms_statements_log "+
	        " where rowid = ?"; */
		 if(loggerUtil.isDebugEnabled())
			{
		 loggerUtil.debug("Query in getPreAuthReverslTxn()===="+feeDtlQuery);
			}
		 
		 try{

           ParameterizedRowMapper<PreAuthReversal> mapper = new ParameterizedRowMapper<PreAuthReversal>() {
				public PreAuthReversal mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					PreAuthReversal userTxnDet = new PreAuthReversal();
					
					userTxnDet.setCardNumber(rs.getString("dispOrgnlMaskPAN"));
					userTxnDet.setRrn(rs.getString("RRN"));
					userTxnDet.setTransDate(rs.getString("Bdate"));
					userTxnDet.setTransTime(rs.getString("Btime"));
					userTxnDet.setTxnInfo(rs.getString("ctm_tran_desc"));
					userTxnDet.setTxnAmt(rs.getString("amount"));
					
					userTxnDet.setSRowId(rs.getString("feerowid"));
					userTxnDet.setTerminalId(rs.getString("terminal_id"));
					userTxnDet.setTxnType(rs.getString("txn_type"));
					userTxnDet.setTransAmt(rs.getString("tranAmt").trim());
					if(loggerUtil.isDebugEnabled())
					{
					loggerUtil.debug("Particular Pre Auth record Details===>");
					}
					loggerUtil.logCardNumber(userTxnDet.getCardNumber());
					if(loggerUtil.isDebugEnabled())
					{
					loggerUtil.debug("txnId "+userTxnDet.getRrn());
					loggerUtil.debug("txnDateTime "+userTxnDet.getTransDate());
					loggerUtil.debug("txnDesc "+userTxnDet.getTxnInfo());
					loggerUtil.debug("txnAmt "+userTxnDet.getTxnAmt());
					loggerUtil.debug("sRowId "+userTxnDet.getSRowId());
					loggerUtil.debug("terminal_id "+userTxnDet.getTerminalId());
					loggerUtil.debug("txn_type "+userTxnDet.getTxnType());
					loggerUtil.debug("tran_amt "+userTxnDet.getTransAmt());
					}
										
					return userTxnDet;
				}
			};
			txnRecrd = getSimpleJdbcTemplate().queryForObject(feeDtlQuery, mapper,bean.getInstCode(),bean.getUserId(),bean.getHidRowId());
			
			if (txnRecrd != null) {
				if(loggerUtil.isDebugEnabled())
				{
						loggerUtil.debug("No of Rows returns after search in getPreAuthReverslTxn()  " + txnRecrd);
				}
			}
		 
		 }
		 catch (Exception e) {
			 if(loggerUtil.isDebugEnabled())
				{
			 loggerUtil.debug("Error occured while fetching records from table : "+e.getMessage());
				}
			e.printStackTrace();
			throw(e);
		}
		 loggerUtil.logMethodExit("getPreAuthReverslTxn");
		 return txnRecrd;
		}
		catch (Exception e) {
			throw(e);
		}

	}

	@Override
	public List<FileBean> getMerchantFileRecords(String cardNumber)
			throws Exception {
		loggerUtil.logMethodEntry("getFileRecordDao");
		/*String getFileDtlQuery=
			" select cfu_filepath, cfu_row_id,cfu_filename_ext,  cfu_file_size, cfu_lupd_user,to_char(TO_DATE (CFU_DATEOF_UPLOAD, 'dd-mm-yy'),'DD-MON-YYYY') CFU_DATEOF_UPLOAD "+
			" from cms_file_upload where cfu_row_id=?";*/
		
		String getFileDtlQuery=
			" select CFU_FILE_PATH, CFU_REF_NUMBER,CFU_FILE_SIZE,cum_lgin_code," +
			"to_char(TO_DATE (CFU_INS_DATE, 'dd-mm-yy'),'"+CMSUtils.DATEFORMAT+"') CFU_INS_DATE "+
			" from CMS_FILEUPLOAD_DETL,cms_userdetl_mast" +
			" where CFU_REF_NUMBER=?"+
			" and cum_user_code=CFU_INS_USER";
		
		
		List<FileBean> merchantFileList= new ArrayList <FileBean> ();
		try{

			
			ParameterizedRowMapper<FileBean> mapper = new ParameterizedRowMapper<FileBean>() {
				public FileBean mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					
					FileBean merchantFiledata = new FileBean();
					
					String fileNameWithPath=rs.getString("CFU_FILE_PATH");
					String fileName=fileNameWithPath.substring(fileNameWithPath.lastIndexOf("/")+1);
					if(loggerUtil.isDebugEnabled())
					{
					loggerUtil.debug("fileNameWithPath "+fileNameWithPath);
					loggerUtil.debug("fileName "+fileName);
					}
					merchantFiledata.setFileName(fileName);
					//kycFailedUser.setRowID(rs.getString("cfu_row_id"));
					merchantFiledata.setFileSize(rs.getString("CFU_FILE_SIZE"));
					//kycFailedUser.setFileAddLupdUser(rs.getString("cfu_lupd_user"));
					merchantFiledata.setFileDateOfUpload(rs.getString("CFU_INS_DATE"));
					merchantFiledata.setFileInsUser(rs.getString("cum_lgin_code"));
					merchantFiledata.setUploadDocsBtn(fileName);
					merchantFiledata.setFilePath(rs.getString("CFU_FILE_PATH"));
					merchantFiledata.setDeleteFile(merchantFiledata.getFilePath());
					merchantFiledata.setFolderName(rs.getString("CFU_REF_NUMBER"));
					
					return merchantFiledata;
				}
			};
			
			merchantFileList = getSimpleJdbcTemplate().query(getFileDtlQuery, mapper,cardNumber);
			 loggerUtil.logMethodExit("getFileRecordDao");
			return merchantFileList;
		 
		 
		}
		catch (Exception e) {
			e.printStackTrace();
			throw(e);
		}
	}
	
	public List<FileBean> getFileRecordDao(String rowId) throws Exception {
		loggerUtil.logMethodEntry("getFileRecordDao");
		/*String getFileDtlQuery=
			" select cfu_filepath,cfu_filename_ext, cfu_row_id,  cfu_file_size, cfu_lupd_user,to_char(TO_DATE (CFU_DATEOF_UPLOAD, 'dd-mm-yy'),'DD-MON-YYYY') CFU_DATEOF_UPLOAD "+
			" from cms_file_upload where cfu_row_id=?";*/
		
		String getFileDtlQuery=
			" select CFU_FILE_PATH, CFU_REF_NUMBER,  CFU_FILE_SIZE, CFU_INS_USER," +
			"to_char(TO_DATE (CFU_INS_DATE, 'dd-mm-yy'),'"+CMSUtils.DATEFORMAT+"') CFU_INS_DATE "+
			" from CMS_FILEUPLOAD_DETL where CFU_REF_NUMBER=?";
		
		List<FileBean> fileList= new ArrayList <FileBean> ();
		try{

			
			ParameterizedRowMapper<FileBean> mapper = new ParameterizedRowMapper<FileBean>() {
				public FileBean mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					
					FileBean fileBean = new FileBean();
					
					String fileNameWithPath=rs.getString("CFU_FILE_PATH");
					String fileName=fileNameWithPath.substring(fileNameWithPath.lastIndexOf("/")+1);
					if(loggerUtil.isDebugEnabled())
					{
					loggerUtil.debug("fileNameWithPath "+fileNameWithPath);
					loggerUtil.debug("fileName "+fileName);
					}
					fileBean.setFileName(fileName);
					//kycFailedUser.setRowID(rs.getString("cfu_row_id"));
					fileBean.setFileSize(rs.getString("CFU_FILE_SIZE"));
					fileBean.setFileInsUser(rs.getString("CFU_INS_USER"));
					fileBean.setFileDateOfUpload(rs.getString("CFU_INS_DATE"));
					fileBean.setUploadDocsBtn(fileName);
					fileBean.setFilePath(rs.getString("CFU_FILE_PATH"));
					fileBean.setDeleteFile(fileBean.getFilePath());
					fileBean.setFolderName(rs.getString("CFU_REF_NUMBER"));
					
					return fileBean;
				}
			};
			
			fileList = getSimpleJdbcTemplate().query(getFileDtlQuery, mapper,rowId);
			 loggerUtil.logMethodExit("getFileRecordDao");
			return fileList;
		 
		 
		}
		catch (Exception e) {
			e.printStackTrace();
			loggerUtil.error("Error occurred while executing getFileRecordDao method "+e.getMessage());
			throw(e);
		}
	}
}