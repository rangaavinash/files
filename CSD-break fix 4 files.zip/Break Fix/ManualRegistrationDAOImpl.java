package com.fss.csr.manualregistration.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.fss.csr.common.bean.KeyValueBean;
import com.fss.csr.common.util.CSRUtils;
import com.fss.csr.common.util.CmsConstants;
import com.fss.csr.common.util.cmsParameters;
import com.fss.csr.common.util.logger.LoggerUtil;
import com.fss.csr.manualregistration.bean.ManualRegistration;

/**
* 
*==========================================================================================================================================
*   Version      Date          Author                Reason
*==========================================================================================================================================
*     1.0      30-03-12       Dnyaneshwar J      Initial Version
*     1.1      19-04-12       Dnyaneshwar J      remove response code value from query
*     												add Map parameter to updateRequestXML
*     												 function
*     1.2	   02-05-12		  Dnyaneshwar J		 remove hard coding of result="OK"
*     1.3	   15-05-12		  Dnyaneshwar J		 add sysdate as registration date
*     1.4      23-05-12       Abhay R      		 For Date Format
*     1.5	   29-05-12		  Dnyaneshwar J		 change in query for displaying product category
*     1.6	   22-06-12		  Dnyaneshwar J		 Log card number in mask format
*     1.4	   05-07-12	  	  Dnyaneshwar J 	 Add Country code and state code validation     
*     1.5	   10-07-12	  	  Dnyaneshwar J 	 Add method which return ecrypted rowid
*     1.6	   28-08-12       Kinjal P			 Change made for Checking Debug Flag condition
*     1.7	   28-08-12       Dnyaneshwar J		 remove logging of XML
*     1.8	   10-09-12       Dnyaneshwar J		 Add method which return account number 
*     1.9	   09-02-13	  	  Dnyaneshwar J 	 Add method which List of Id type taking from master table
*     2.0	   05-03-13	  	  Dnyaneshwar J 	 Add method to get response message & card details in case of SN
*     2.1      11-03-13       Dnyaneshwar J      changes made for adding new feature of GPR card issuance
*     2.2      18-03-13       Dnyaneshwar J      Add method to log user id in transactionlog
*     2.3      22-03-13       Dnyaneshwar J      handle null pointer while setting values into bean object
*     2.4      07-08-13       Dnyaneshwar J      Chnages made while inserting the Req XML.
*     2.5      21-12-13       Dnyaneshwar J      Modify getCardDetails method, validateStarterCard method, add new method to get Product description
*     2.6      21-12-13       Dnyaneshwar J      Modify getSSNFailDetails method to get ssn failed records in case of Starter-To-GPR registration.
*     2.7      18-09-14		  Ramesh A			 Changes done for  MVCSD-5381(KYCFLAG)
*     2.8      01-07-15       Mageshkumar S      Changes done for MVCAN-77
*==========================================================================================================================================
*This Class is used for Manual Registration.
*/
public class ManualRegistrationDAOImpl extends SimpleJdbcDaoSupport implements ManualRegistrationDAO {

	private static LoggerUtil loggerUtil = new LoggerUtil(ManualRegistrationDAOImpl.class);
	
	@Override
	public ManualRegistration getCardDetails(ManualRegistration bean)//Modified by Dnyaneshwar J on 18 dec 2013
			throws Exception {
		loggerUtil.logMethodEntry("getCardDetails");
		ManualRegistration manualReg=new ManualRegistration();

		StringBuffer getProdCodeQuery = new StringBuffer();
		List<KeyValueBean> prodCodeList = new ArrayList<KeyValueBean>();
		List<KeyValueBean> cardTypeList = new ArrayList<KeyValueBean>();
		
		getProdCodeQuery.append(" select cpm_prod_code,cpm_prod_desc  ");
		getProdCodeQuery.append(" from cms_prod_mast,cms_prod_bin ");
		getProdCodeQuery.append(" where cpm_prod_code=cpb_prod_code ");
		getProdCodeQuery.append(" and cpb_inst_bin in ("+bean.getAuthBIN()+") ");//Modified by Dnyaneshwar J on 18 dec 2013
		
		loggerUtil.debug("Query For Getting Master List Of ID Types : "+getProdCodeQuery.toString());
		
		ParameterizedRowMapper<KeyValueBean> prodCodeMastermapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		prodCodeList = getSimpleJdbcTemplate().query(getProdCodeQuery.toString(), prodCodeMastermapper);
		
		if(prodCodeList!=null && prodCodeList.size()>0){
			if(manualReg!=null){
				manualReg.setProdCodeList(prodCodeList);
				
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey("Select");
				keyValue.setValue("NOT SELECTED");
				cardTypeList.add(keyValue);
				manualReg.setCardTypeList(cardTypeList);
			}
		}
		
		StringBuffer getMasterIdType = new StringBuffer();
		getMasterIdType.append(" select cim_idtype_code,cim_idtype_desc from CMS_IDTYPE_MAST where CIM_IDTYPE_FLAG='U' order by cim_idtype_code desc");
		loggerUtil.debug("Query For Getting Master List Of ID Types : "+getMasterIdType.toString());
		
		ParameterizedRowMapper<KeyValueBean> IdTypeMastermapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		List<KeyValueBean> idTypeList = getSimpleJdbcTemplate().query(getMasterIdType.toString(), IdTypeMastermapper);
		
		if(idTypeList!=null && idTypeList.size()>0){
			if(manualReg!=null){
				manualReg.setIdTypeMast(idTypeList);
			}
		}
		
		StringBuffer getcountryList = new StringBuffer();
		getcountryList.append(" select GCM_SWITCH_CNTRY_CODE,gcm_cntry_name from gen_cntry_mast where GCM_CNTRY_CODE in (2,3) order by gcm_cntry_name ");
		loggerUtil.debug("Query For Getting Country List : "+getcountryList.toString());
		
		ParameterizedRowMapper<KeyValueBean> countryListmapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		List<KeyValueBean> countryList = getSimpleJdbcTemplate().query(getcountryList.toString(), countryListmapper);
		List<KeyValueBean> idProvinceList = new ArrayList<KeyValueBean>();
		
		if(countryList!=null && countryList.size()>0){
			if(manualReg!=null){
				manualReg.setIdCountryList(countryList);
				manualReg.setIdProvinceList(idProvinceList);
				
			}
		}
		
		StringBuffer getOccupationList = new StringBuffer();
		getOccupationList.append(" select VOM_OCCU_CODE,VOM_OCCU_NAME from VMS_OCCUPATION_MAST  order by VOM_OCCU_NAME ");
		loggerUtil.debug("Query For Getting Occupation List : "+getOccupationList.toString());
		
		ParameterizedRowMapper<KeyValueBean> occupationListmapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		List<KeyValueBean> occupationList = getSimpleJdbcTemplate().query(getOccupationList.toString(), occupationListmapper);
		
		if(occupationList!=null && occupationList.size()>0){
			if(manualReg!=null){
				manualReg.setOccupationList(occupationList);
			}
		}
		
		//VMS-207
		StringBuffer getreasonForNoTaxList = new StringBuffer();
		getreasonForNoTaxList.append(" select VPC_PARAM_ID,VPC_PARAM_NAME from vms_param_config_mast where vpc_param_type='Reason_For_Not_Having_Tax' order by VPC_PARAM_ID");
		loggerUtil.debug("Query For Getting Reason For No Tax Id List : "+getreasonForNoTaxList.toString());
		
		ParameterizedRowMapper<KeyValueBean> getreasonForNoTaxListmapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		List<KeyValueBean> reasonForNoTaxList = getSimpleJdbcTemplate().query(getreasonForNoTaxList.toString(), getreasonForNoTaxListmapper);
		
		if(reasonForNoTaxList!=null && reasonForNoTaxList.size()>0){
			if(manualReg!=null){
				manualReg.setReasonForNoTaxList(reasonForNoTaxList);
				
			}
		}
		
		
		StringBuffer getallcountryList = new StringBuffer();
		getallcountryList.append(" select GCM_SWITCH_CNTRY_CODE,gcm_cntry_name from gen_cntry_mast where GCM_ISO_CNTRY_CODE <> '999' order by gcm_cntry_name ");
		loggerUtil.debug("Query For Getting ALL Country List : "+getallcountryList.toString());
		
		ParameterizedRowMapper<KeyValueBean> allcountryListmapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		List<KeyValueBean> allcountryList = getSimpleJdbcTemplate().query(getallcountryList.toString(), allcountryListmapper);
		
		if(allcountryList!=null && allcountryList.size()>0){
			if(manualReg!=null){
				manualReg.setAllCountryList(allcountryList);
				
			}
		}
		
		StringBuffer getallthirdpartycountryList = new StringBuffer();
		getallthirdpartycountryList.append(" select GCM_SWITCH_CNTRY_CODE,gcm_cntry_name from gen_cntry_mast where GCM_ISO_CNTRY_CODE <> '999'order by gcm_cntry_name ");
		loggerUtil.debug("Query For Getting ALL Third Party Country List : "+getallthirdpartycountryList.toString());
		
		ParameterizedRowMapper<KeyValueBean> allcountrythirdpartyListmapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		List<KeyValueBean> allthirdpartycountryList = getSimpleJdbcTemplate().query(getallthirdpartycountryList.toString(), allcountrythirdpartyListmapper);
		List<KeyValueBean> thirdPartyStateList = new ArrayList<KeyValueBean>();
		if(allthirdpartycountryList!=null && allthirdpartycountryList.size()>0){
			if(manualReg!=null){
				manualReg.setAllThirdPartyCountryList(allthirdpartycountryList);
				manualReg.setThirdPartyStateList(thirdPartyStateList);
				
			}
		}
		
		loggerUtil.logMethodExit("ManualRegistration");
		
		return manualReg; 
	}
	
	@Override
	public int logRequestXML(String xml, ManualRegistration bean)
			throws Exception {
		int insertROW=0;
		loggerUtil.logMethodEntry("logRequestXML");
		StringBuffer insertXMLLog=new StringBuffer();
		insertXMLLog.append("INSERT INTO cms_csr_xml_log(cxl_rrn,cxl_request_xml,");
		insertXMLLog.append("cxl_ins_date,cxl_ins_user," );
		insertXMLLog.append("cxl_DELIVERY_CHANNEL,cxl_inst_code,cxl_txn_code) ");
		insertXMLLog.append("values(?,?,SYSDATE,?,?,?,?)");//sn-Modified by Dnyaneshwar J on 07 Aug 2013
		
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("insertXMLLog query : "+insertXMLLog.toString());
			loggerUtil.debug("Delivery Channel : "+bean.getDeliveryChannel());
			loggerUtil.debug("Inst Code : "+bean.getInstCode());
			loggerUtil.debug("Transaction Code : "+bean.getTxnCode());
		}
		insertROW=getSimpleJdbcTemplate().update(insertXMLLog.toString(),bean.getRrnNumber(),xml,bean.getInsUser(),bean.getDeliveryChannel(),bean.getInstCode(),bean.getTxnCode());//Modified by Dnyaneshwar J on 07 Aug 2013
		
		if(loggerUtil.isDebugEnabled())
		{	
			loggerUtil.debug("No. of Rows inserted : "+insertROW);
		}
		return insertROW;
	}

	//add Map parameter to  function by Dnyaneshwar J on 19 April 2012
	@Override
	public int updateRequestXML(String xml, ManualRegistration bean,Map<String,String> respData)
	throws Exception {
		int insertROW=0;
		loggerUtil.logMethodEntry("updateRequestXML");
		StringBuffer updateXMLLog=new StringBuffer();
		String respCardNo="";
		updateXMLLog.append("UPDATE cms_csr_xml_log set cxl_response_xml=?,");
		updateXMLLog.append("cxl_lupd_date=SYSDATE,cxl_lupd_user=?,cxl_resp_code=?,");
		
		if(respData.get("CardNumber")!=null && !("".equals(respData.get("CardNumber")))){
			respCardNo=respData.get("CardNumber");
			updateXMLLog.append("cxl_pan_code=gethash(?),cxl_pan_code_encr=fn_emaps_main(?)");
		}
		else{
			updateXMLLog.append("cxl_pan_code=?,cxl_pan_code_encr=?");
		}
		
		updateXMLLog.append(" where cxl_rrn=? ");//Modified by Dnyaneshwar J on 07 Aug 2013
		
		String respCode=respData.get("RespCode");
		
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("updattion Query query : "+updateXMLLog.toString());
			loggerUtil.debug("RRN : "+bean.getRrnNumber());
			loggerUtil.debug("RespCode "+respCode);
		}
		
		insertROW=getSimpleJdbcTemplate().update(updateXMLLog.toString(),xml,bean.getInsUser(),respCode,respCardNo,respCardNo,bean.getRrnNumber());//Modified by Dnyaneshwar J on 07 Aug 2013
		
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("No. of Rows inserted : "+insertROW);
		}
		return insertROW;
	}

	@Override
	public KeyValueBean getRRN_STAN() throws Exception {
		
		loggerUtil.logMethodEntry("getRRN_STAN");
		KeyValueBean keyValue = new KeyValueBean();
		CSRUtils csrUtil= new CSRUtils();
	    csrUtil.setSimpleJdbcTemplate(getSimpleJdbcTemplate());
	    keyValue = csrUtil.getSeqNoForRRNAndStan();
	    loggerUtil.logMethodExit("getRRN_STAN");
	    
		return keyValue;
	}

	public String checkStarterCard(ManualRegistration bean) throws Exception {
		String result="";
		String approveFlag="N";
		Connection con = null;
		CallableStatement cstmt = null;
		loggerUtil.logMethodEntry("checkStarterCard");
		//Added by Abdul Hameed M.A for MVHOST-1263
		if(bean.getRoleId()!=null && bean.getRoleId().equals("3"))
		{
			approveFlag="Y";
		}
		if(authorizeBIN(bean.getClearPan(), bean.getAuthBIN())){
			try {
			/*SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(getDataSource());
			String spName = "SP_CHECK_STARTER_CARD"; 
			simpleJdbcCall = simpleJdbcCall.withProcedureName(spName);
			simpleJdbcCall = simpleJdbcCall.withSchemaName(cmsParameters.getProperty("SCHEMANAME"));*/
			
			con = getDataSource().getConnection();
			cstmt = con.prepareCall("{call vmscms.SP_CHECK_STARTER_CARD(?,?,?,?,?,?)}");
			
			loggerUtil.logCardNumber(bean.getClearPan());
			loggerUtil.debug("instCode "+bean.getInstCode());
			loggerUtil.debug("txnCode "+bean.getTxnCode());
			loggerUtil.debug("deliveryChannel "+CmsConstants.DELIVERY_CHANNEL);
				
	//		Map<String, Object> map = new HashMap<>();	
			cstmt.setInt(1,Integer.parseInt(bean.getInstCode()) );
			cstmt.setString(2,bean.getClearPan() );
			cstmt.setString(3,bean.getTxnCode() );
			cstmt.setString(4,CmsConstants.DELIVERY_CHANNEL );
			cstmt.setString(5, approveFlag);
			
			cstmt.registerOutParameter(6, Types.VARCHAR);
			cstmt.executeUpdate();
			result = cstmt.getString(6);
			
			/*SqlParameterSource in = new MapSqlParameterSource().addValues(map);				
			Map <String , Object> out  =  simpleJdbcCall.execute(in);*/
			
			if(cstmt!=null && cstmt.getString("PRM_ERR_MSG")!=null){
				result = (String)cstmt.getString("PRM_ERR_MSG");
				
				/**
				 * Checking only ORA cinditiona so no else require below.
				 */
				if(result!=null && "ORA".contains(result)){
					result="Error Occured While Starter Card Validation";
				}
			}
			else{
				result="Error Occured While Starter Card Validation";
			}
		}
			catch (Exception e) {
				loggerUtil.info("Exception: " + e.getMessage());
				loggerUtil.error("Exception: " + e.getMessage(), e);
			} finally {
				if (cstmt != null) {
					cstmt.close();
				}
				if (con != null) {
					con.close();
				}
			}
		}
		else{
			loggerUtil.debug("BIN validation failed");
			result="You are not authorized to search this BIN Series";
		}
		
		loggerUtil.debug("result : "+result);
		
		loggerUtil.logMethodExit("checkStarterCard");
		return result;
	}
	
	public boolean authorizeBIN(String cardNumber,String authBIN)throws Exception{
		loggerUtil.logMethodEntry("authorizeBIN");
		
		boolean flag = false;
		
		if(cardNumber!=null && !("".equals(cardNumber))){
			String currntCardBIN = cardNumber.substring(0,6);
			if(currntCardBIN!=null && !("".equals(currntCardBIN))){
				if(authBIN.contains(currntCardBIN)){
					flag = true;
				}
				else{
					loggerUtil.debug("Unauthorize BIN search attept For Manual Registration");
					flag=false;
				}
			}
		}
		
		loggerUtil.logMethodExit("authorizeBIN");
		return flag;
	}

	//Added by Dnyaneshwar J on 05 Jul 2012 to validate Country and state code
	@Override
	public String validateCountryCode(String instCode,String cntryCntryCode) throws Exception {
		loggerUtil.logMethodEntry("validateCountryState");
		
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("instCode       "+instCode);
			loggerUtil.debug("cntryStateCode "+cntryCntryCode);
		}
		
		CSRUtils csr = new CSRUtils();
		csr.setSimpleJdbcTemplate(getSimpleJdbcTemplate());
		
		if(csr.validateCountryCode(instCode,cntryCntryCode).equals(CmsConstants.VALIDATE_INVALID_CHAR)){
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("Code not matching");
			}
			return "invalid";
		}
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("Code matching");
		}
		return "valid";
	}
	
	//Added by Dnyaneshwar J on 05 Jul 2012 to validate Country and state code
	@Override
	public String validateStateCode(int instCode,String cntryStateCode) throws Exception {
		loggerUtil.logMethodEntry("validateCountryState");
		
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("instCode       "+instCode);
			loggerUtil.debug("cntryStateCode "+cntryStateCode);
		}
		
		CSRUtils csr = new CSRUtils();
		csr.setSimpleJdbcTemplate(getSimpleJdbcTemplate());
		
		if(csr.validateStateCode(instCode,cntryStateCode).equals(CmsConstants.VALIDATE_INVALID_CHAR)){
			if(loggerUtil.isDebugEnabled())
			{
				loggerUtil.debug("Code not matching");
			}
			return "invalid";
		}
		if(loggerUtil.isDebugEnabled())
		{
			loggerUtil.debug("Code matching");
		}
		return "valid";
	}

	//Added by Dnyaneshwar on 10 July 2012 for getting inked to Profile page with encrypted rowid
	@Override
	public String getEncryptedRowIdForCardNumber(String cardNumber, String instCode)
			throws Exception {
		loggerUtil.logMethodEntry("getEncryptedRowIdForCardNumber");
		loggerUtil.logCardNumber(cardNumber);
		String encrRowId="";
    	String sql="select fn_emaps_main(rowid) from cms_appl_pan where cap_pan_code=gethash(?) and CAP_INST_CODE=?";
    	
    	encrRowId=getSimpleJdbcTemplate().queryForObject(sql,String.class,cardNumber,instCode);
    	if(loggerUtil.isDebugEnabled())
		{
	    	loggerUtil.debug("getting Encryted rowid query : "+sql);
	    	loggerUtil.debug("encrRowId "+encrRowId);
		}
	    	
    	loggerUtil.logMethodExit("getEncryptedRowIdForCardNumber");
		return encrRowId;
	}

	//Added by Dnyaneshwar J on 10 Sept 2012 for getting Account numner on basis of starter card
	@Override
	public String getAcctNumber(String cardNumber,String instCode) throws Exception {
		loggerUtil.logMethodEntry("getAcctNumber");
		
		String accountNumber="";
    	String sql="select cap_acct_no from cms_appl_pan where cap_pan_code=gethash(?) and CAP_INST_CODE=?";
    	accountNumber=getSimpleJdbcTemplate().queryForObject(sql,String.class,cardNumber,instCode);
    	
		loggerUtil.logMethodExit("getAcctNumber");
		return accountNumber;
	}

	@Override
	public List<KeyValueBean> listIdTypes(String currCode) throws Exception {
		loggerUtil.logMethodEntry("listIdTypes");
		
		List<KeyValueBean> idTypeList = new ArrayList<KeyValueBean>();
		StringBuffer getMasterIdType = new StringBuffer();
		getMasterIdType.append(" select cim_idtype_code,cim_idtype_desc from CMS_IDTYPE_MAST ");
		if(CmsConstants.CURRENCY_CODE_CANADA.equalsIgnoreCase(currCode))
		{
			getMasterIdType.append(" where CIM_IDTYPE_FLAG ='C' ");	
		}
		else
		{
			getMasterIdType.append(" where CIM_IDTYPE_FLAG ='U' ");	
		}
		getMasterIdType.append(" ORDER BY cim_idtype_desc ");	
		
		loggerUtil.debug("Query For Getting Master List Of ID Types : "+getMasterIdType.toString());
		
		ParameterizedRowMapper<KeyValueBean> IdTypeMastermapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		idTypeList = getSimpleJdbcTemplate().query(getMasterIdType.toString(), IdTypeMastermapper);
		
		loggerUtil.logMethodExit("listIdTypes");
		return idTypeList;
		
	}

	@Override
	public ManualRegistration getSSNFailDetails(ManualRegistration reqBeanData)throws Exception {
		loggerUtil.logMethodEntry("getSSNFailDetails");
		StringBuffer getSSNFailedCardDtl = new StringBuffer();
		ManualRegistration temp = new ManualRegistration();
		String searchBy="";
		
		if(reqBeanData.getTxnCode()!=null && (CmsConstants.TXN_CODE_STARTER_MANUAL_REG.equals(reqBeanData.getTxnCode()) || CmsConstants.TXN_CODE_NONUS_STARTER_MANUAL_REG.equals(reqBeanData.getTxnCode()))){ //Added for MVCAN-77 of 3.1 release
			/*
			 * Fetching failed card details from CMS_CAF_INFO_ENTRY in case of Starter-To-GPR on basis of application code.
			 * so need to get first appl code from CMS_APPL_PAN and then fire query on CMS_CAF_INFO_ENTRY to reduce cost using two different queries.
			 */
			String sql=" select cap_appl_code from cms_appl_pan where cap_pan_code=gethash(?) and CAP_INST_CODE=? ";
	    	String applCode="";
	    	applCode=getSimpleJdbcTemplate().queryForObject(sql,String.class,reqBeanData.getClearPan(),reqBeanData.getInstCode());
	    	
	    	getSSNFailedCardDtl.append(" SELECT cci_ssnfail_dtls ssnFailDtls,cci_process_msg processMsg FROM cms_caf_info_entry WHERE CCI_APPL_CODE=? ");//Modified by Dnyaneshwar J on 21 Feb 2014
	    	searchBy=applCode;
		}
		else if(reqBeanData.getTxnCode()!=null && CmsConstants.TXN_CODE_GPR_MANUAL_REG.equals(reqBeanData.getTxnCode())){
			getSSNFailedCardDtl.append(" SELECT SSN_FAIL_DTLS ssnFailDtls,ERROR_MSG processMsg FROM transactionlog WHERE RRN=? ");
			searchBy=reqBeanData.getRrnNumber();
		}
		
		loggerUtil.debug("Query For Getting SSN Failed Card Details : "+getSSNFailedCardDtl.toString());
		loggerUtil.debug("Search By        : "+searchBy);
		loggerUtil.debug("Transaction Code : "+reqBeanData.getTxnCode());
		
		ParameterizedRowMapper<ManualRegistration> mapper = new ParameterizedRowMapper<ManualRegistration>() {
			public ManualRegistration mapRow(ResultSet rs, int rowNum)throws SQLException {
				
				ManualRegistration ssnFailedCustDtl = new ManualRegistration();
				
				ssnFailedCustDtl.setRespDescription(rs.getString("processMsg"));
				ssnFailedCustDtl.setSsnFailDtls(rs.getString("ssnFailDtls"));
				
				return ssnFailedCustDtl;
			}
		};

		if(searchBy!=null && !("".equals(searchBy))){
			temp = getSimpleJdbcTemplate().queryForObject(getSSNFailedCardDtl.toString(), mapper,searchBy);
		}
		
		loggerUtil.logMethodExit("getSSNFailDetails");
		return temp;
	}

	@Override
	public List<KeyValueBean> getCardTypeList(String prodCode, String instCode) {
		loggerUtil.logMethodEntry("getCardTypeList");
		List<KeyValueBean> cardTypeList = new ArrayList<KeyValueBean>();
		
		/**
		 * Below IF condition will check if Product is 'Select'(i.e. from front end)
		 * it means no category will get populate & ultimately cardTypeList will be of zero size
		 * and this list will display on front end with blank data under Product Category list.
		 */
		if(prodCode!=null && !"Select".equals(prodCode)){
			StringBuffer getCardType = new StringBuffer();
			getCardType.append(" select cpc_card_type,cpc_cardtype_desc from cms_prod_cattype where cpc_prod_code=?  and cpc_inst_code=?");
			loggerUtil.debug("Query For Getting Master List Of ID Types : "+getCardType.toString());
			
			ParameterizedRowMapper<KeyValueBean> IdTypeMastermapper = new ParameterizedRowMapper<KeyValueBean>() {
				public KeyValueBean mapRow(ResultSet rs, int rowNum)throws SQLException {
					
					KeyValueBean keyValue = new KeyValueBean();
					keyValue.setKey(rs.getString(1));
					keyValue.setValue(rs.getString(2));
	
					return keyValue;
				}
			};
			cardTypeList = getSimpleJdbcTemplate().query(getCardType.toString(), IdTypeMastermapper,prodCode,instCode);
		}
		else{
			KeyValueBean keyValue = new KeyValueBean();
			keyValue.setKey("Select");
			keyValue.setValue("NOT SELECTED");
			cardTypeList.add(keyValue);
		}
		
		loggerUtil.logMethodExit("getCardTypeList");
		return cardTypeList;
	}

	@Override
	public boolean checkForProducCodeCardType(String productCode,String cardType) {
		loggerUtil.logMethodEntry("checkForProducCodeCardType");
		boolean flag=false;
		int count=0;
		
		StringBuffer sql = new StringBuffer();
		sql.append(" SELECT Count(1) from cms_prod_cattype where cpc_prod_code=?  and cpc_card_type=? ");
		loggerUtil.debug("Query For Checking The Combination Of Product Code & Card Type : "+sql.toString());
		
		count=getSimpleJdbcTemplate().queryForInt(sql.toString(),productCode,cardType);
		
		if(count==1){
			flag=true;
		}
		
		loggerUtil.debug("Product Code & Card Type Validation Flag : "+flag);
		
		loggerUtil.logMethodExit("checkForProducCodeCardType");
		return flag;
	}

	@Override
	public List<KeyValueBean> getProdCodeList(String authBIN) {
		loggerUtil.logMethodEntry("getProdCodeList");
		
		StringBuffer getProdCodeQuery = new StringBuffer();
		List<KeyValueBean> prodCodeList = new ArrayList<KeyValueBean>();
		
		getProdCodeQuery.append(" select cpm_prod_code,cpm_prod_desc  ");
		getProdCodeQuery.append(" from cms_prod_mast,cms_prod_bin ");
		getProdCodeQuery.append(" where cpm_prod_code=cpb_prod_code ");
		getProdCodeQuery.append(" and cpb_inst_bin in ("+authBIN+") ");
		
		loggerUtil.debug("Query For Getting Master List Of ID Types : "+getProdCodeQuery.toString());
		
		ParameterizedRowMapper<KeyValueBean> IdTypeMastermapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		prodCodeList = getSimpleJdbcTemplate().query(getProdCodeQuery.toString(), IdTypeMastermapper);
		
		loggerUtil.logMethodExit("getProdCodeList");
		return prodCodeList;
	}

	@Override
	public String getMaskPan(String cardNumber, String instCode) {
		loggerUtil.logMethodEntry("getMaskPan");
		StringBuffer sql = new StringBuffer();
		sql.append("select cap_mask_pan cardNumber from cms_appl_pan where cap_pan_code=gethash(?) and cap_inst_code=?");
		String maskPAN="";
		
		loggerUtil.debug("Converting clear PAN to mask PAN query : "+sql.toString());
		loggerUtil.debug("instCode "+instCode);
		
		maskPAN=getSimpleJdbcTemplate().queryForObject(sql.toString(),String.class,cardNumber,instCode);
		
		loggerUtil.logMethodExit("getMaskPan");
		return maskPAN;	
	}

	@Override
	public ManualRegistration getSSNFailDetailsFromSP(ManualRegistration reqBeanData) {
		loggerUtil.logMethodEntry("getSSNFailDetailsFromSP");
		ManualRegistration temp = new ManualRegistration();
		Connection con = null;
		CallableStatement cstmt = null;
		//SimpleJdbcCall simpleJdbcCall=null;
		String spName="sp_check_ssn_threshold";
	//	Map<String,Object> map = new HashMap<String, Object>();
		
		try {
			con = getDataSource().getConnection();
			cstmt = con.prepareCall("{call vmscms.sp_check_ssn_threshold(?,?,?,?,?,?,?)}");
		
		
	//	simpleJdbcCall = new SimpleJdbcCall(getDataSource());
		if(con!=null){
			/*simpleJdbcCall = simpleJdbcCall.withProcedureName(spName);
			simpleJdbcCall = simpleJdbcCall.withSchemaName(cmsParameters.getProperty("SCHEMANAME"));*/
			String hashKeyValue = getHashKeyValue(reqBeanData);//Added for MVCAN-77 of 3.1 release
			loggerUtil.debug(spName+" procedure call start");
			loggerUtil.debug("p_instcode        : "+reqBeanData.getInstCode());
			loggerUtil.debug("p_prod_code       : "+reqBeanData.getGprRegProdCode());
			loggerUtil.debug("p_card_type       : "+reqBeanData.getGprRegCardType());
			loggerUtil.debug("p_strtogpr_flag   : "+"EN");
			loggerUtil.debug("p_fldob_key         : "+hashKeyValue);
			
			
			
			//map = new HashMap<String,Object>();
			
			cstmt.setString(1,reqBeanData.getInstCode());
			cstmt.setString(2,reqBeanData.getOtherIdNumber());
			cstmt.setString(3,reqBeanData.getGprRegProdCode());
			cstmt.setString(4,reqBeanData.getGprRegCardType());			
			cstmt.setString(5,"EN");
			cstmt.setString(6, hashKeyValue); //Added for MVCAN-77 of 3.1 release
			
			/*SqlParameterSource in = new MapSqlParameterSource().addValues(map);				
			Map <String , Object> out  =  simpleJdbcCall.execute(in);*/
			cstmt.registerOutParameter(7, Types.VARCHAR);
			cstmt.executeUpdate();
			
			if(cstmt!=null ){
				if(cstmt.getString("P_CARDDTLS")!=null && !("".equals(cstmt.getString("P_CARDDTLS")))){//Handle nullpointer by Dnyaneshwar J on 22 Mar 2013
					temp.setSsnFailDtls(((String)cstmt.getString("P_CARDDTLS")).trim());
				}
				if(cstmt.getString("P_RESP_MSG")!=null && !("".equals(cstmt.getString("P_RESP_MSG")))){//Handle nullpointer by Dnyaneshwar J on 22 Mar 2013
					temp.setRespDescription(((String)cstmt.getString("P_RESP_MSG")).trim());
				}
			}
		}
		} catch (Exception e) {
			loggerUtil.info("Exception: " + e.getMessage());
			loggerUtil.error("Exception: " + e.getMessage(), e);
		} finally {
			if (cstmt != null) {
				cstmt.close();
			}
			if (con != null) {
				con.close();
			}
		}
		
		loggerUtil.logMethodExit("getSSNFailDetailsFromSP");
		return temp;
	}
	
	/**
	 * Added by Dnyaneshwar J on 18 Mar 2013
	 * to update user id in transactionlog
	 */
	@Override
	public void UpdateUserRegistartion(ManualRegistration bean) throws Exception{
		loggerUtil.logMethodEntry("UpdateUserRegistartion");	
		
		StringBuffer updateUser=new StringBuffer("UPDATE TRANSACTIONLOG SET ADD_INS_USER =? WHERE RRN=? AND TXN_CODE=?");
				updateUser.append(" AND DELIVERY_CHANNEL=? ");
				updateUser.append(" AND MSGTYPE=? AND BUSINESS_DATE =? ");
				updateUser.append(" AND BUSINESS_TIME=?");
		
		int inserRecord=getSimpleJdbcTemplate().update(updateUser.toString(),bean.getInsUser(),bean.getRrnNumber(),bean.getTxnCode(),
				CmsConstants.DELIVERY_CHANNEL,CmsConstants.TXN_0200_NORMAL_MSG_TYPE,bean.getBusinessDate(),bean.getBusinessTime());
		
		if(inserRecord==1){
			loggerUtil.debug("user id Updated for -> rrn -->"+bean.getRrnNumber());
		}
		else{
			loggerUtil.debug("No. Of Rows Updated : "+inserRecord);
		}
		loggerUtil.logMethodExit("UpdateUserRegistartion");
	}

	/**
	 * This method will return Product description
	 * to display on result screen of Registration.
	 * This method will execute only in case of Successful Manual Registration.
	 */
	@Override
	public String getProductCode(ManualRegistration bean) throws Exception {
		String prodDesc="";
		
		StringBuffer sql = new StringBuffer();
		if(bean.getTxnCode()!=null){
			if(CmsConstants.TXN_CODE_GPR_MANUAL_REG.equals(bean.getTxnCode())){
				sql.append(" select cpm_prod_desc from cms_prod_mast where cpm_prod_code=? and cpm_inst_code=? ");
				loggerUtil.debug("Query For Getting Product Details : "+sql);
				prodDesc=getSimpleJdbcTemplate().queryForObject(sql.toString(),String.class,bean.getGprRegProdCode(),bean.getInstCode());
			}
			else if(CmsConstants.TXN_CODE_STARTER_MANUAL_REG.equals(bean.getTxnCode()) || CmsConstants.TXN_CODE_NONUS_STARTER_MANUAL_REG.equals(bean.getTxnCode())){  //Modified for FWR 70
				sql.append(" SELECT cpm_prod_desc ");
				sql.append(" FROM cms_appl_pan,cms_prod_mast ");
				sql.append(" WHERE cap_prod_code=cpm_prod_code ");
				sql.append(" and cap_inst_code=cpm_inst_code ");
				sql.append(" and cap_inst_code=? ");
				sql.append(" and cap_pan_code=gethash(?) ");
				loggerUtil.debug("Query For Getting Product Details : "+sql);
				prodDesc=getSimpleJdbcTemplate().queryForObject(sql.toString(),String.class,bean.getInstCode(),bean.getClearPan());
			}
		}
		
		return prodDesc;
	}
	

	@Override
	public String getKYCFlag(String cardNumber,String instCode) throws Exception {
		loggerUtil.logMethodEntry("getKYCFlag");
		
		String kycFlag="";
    	String sql=" select ccm_kyc_flag from cms_appl_pan,cms_cust_mast "+
				   " where cap_pan_code=gethash(?) and cap_cust_code=ccm_cust_code "+
				   " and CAP_INST_CODE=ccm_inst_code and CAP_INST_CODE=?";
    	kycFlag=getSimpleJdbcTemplate().queryForObject(sql,String.class,cardNumber,instCode);
    	
		loggerUtil.logMethodExit("getKYCFlag");
		return kycFlag;
	}

	//Added for FWR 70
	/**
	 * This method will return Currency code
	 * 
	 */
	@Override
	public String getCurrencyCode(String cardNo,String instCode) throws Exception {
		String currCode="";
		 
		StringBuffer sql = new StringBuffer();	
		sql.append(" SELECT CBP_PARAM_VALUE ");
		sql.append(" FROM CMS_BIN_PARAM ,  CMS_PROD_CATTYPE,  CMS_APPL_PAN ");
		sql.append(" WHERE CBP_PROFILE_CODE =CPC_PROFILE_CODE ");
		sql.append(" AND CBP_PARAM_NAME     = 'Currency' ");
		sql.append(" AND CPC_PROD_CODE      =CAP_PROD_CODE");
		sql.append(" AND CPC_CARD_TYPE      =CAP_CARD_TYPE ");
		sql.append(" AND cap_pan_code=gethash(?) ");
		sql.append(" AND CAP_INST_CODE      =? ");
				loggerUtil.debug("Query For Getting Currency Code : "+sql);
				currCode=getSimpleJdbcTemplate().queryForObject(sql.toString(),String.class,cardNo,instCode);
				loggerUtil.debug("currCode : "+currCode);

				return currCode;

	}
	//Added for MVCAN-77 of 3.1 release
	public String getHashKeyValue(ManualRegistration bean) {
		
		loggerUtil.logMethodEntry("getHashKeyValue");
		String hashValue="";
		StringBuffer strBuffer = new StringBuffer();
		strBuffer.append(bean.getCustFnm().trim().toUpperCase());
		strBuffer.append("||");
		strBuffer.append(bean.getCustLnm().trim().toUpperCase());
		strBuffer.append("||");
		strBuffer.append(bean.getCustDob());
		
		String sql = "SELECT GETHASH(?) FROM DUAL";
		
		hashValue=getSimpleJdbcTemplate().queryForObject(sql,String.class,strBuffer.toString());
		loggerUtil.logMethodExit("getHashKeyValue");
		return hashValue;
	}
	
	@Override
	public List<KeyValueBean> getProvinceList(String countryCode, String instCode) throws Exception{
		loggerUtil.logMethodEntry("getProvinceList");
		List<KeyValueBean> provinceList = new ArrayList<KeyValueBean>();

		if(countryCode!=null && !"-1".equals(countryCode)){
			StringBuffer getprovince = new StringBuffer();
			//getprovince.append(" select GSM_SWITCH_STATE_CODE,gsm_state_name from gen_state_mast where GSM_SWITCH_CNTRY_CODE=? and gsm_inst_code=? order by gsm_state_name");
			getprovince.append(" select GSM_SWITCH_STATE_CODE,gsm_state_name from gen_state_mast where GSM_ALPHA_CNTRY_CODE=(select gcm_alpha_cntry_code from gen_cntry_mast where gcm_switch_cntry_code=? and gcm_inst_code= ?) and gsm_inst_code=? order by gsm_state_name");
			loggerUtil.debug("Query For Getting Master List Of ID Types : "+getprovince.toString());
			
			ParameterizedRowMapper<KeyValueBean> provinceListmapper = new ParameterizedRowMapper<KeyValueBean>() {
				public KeyValueBean mapRow(ResultSet rs, int rowNum)throws SQLException {
					
					KeyValueBean keyValue = new KeyValueBean();
					keyValue.setKey(rs.getString(1));
					keyValue.setValue(rs.getString(2));
	
					return keyValue;
				}
			};
			provinceList = getSimpleJdbcTemplate().query(getprovince.toString(), provinceListmapper,countryCode,instCode,instCode);
		}
		/*else{
			KeyValueBean keyValue = new KeyValueBean();
			keyValue.setKey("Select");
			keyValue.setValue("NOT SELECTED");
			cardTypeList.add(keyValue);
		}*/
		
		loggerUtil.logMethodExit("getProvinceList");
		return provinceList;
	}
	
	@Override
	public List<KeyValueBean> getCountryList() throws Exception {
		loggerUtil.logMethodEntry("getCountryList");
		
		StringBuffer getcountryList = new StringBuffer();
		getcountryList.append(" select GCM_SWITCH_CNTRY_CODE,gcm_cntry_name from gen_cntry_mast where GCM_ISO_CNTRY_CODE <> '999' and GCM_SWITCH_CNTRY_CODE is not null order by gcm_cntry_name ");
		loggerUtil.debug("Query For Getting Country List : "+getcountryList.toString());
		
		ParameterizedRowMapper<KeyValueBean> countryListmapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		List<KeyValueBean> countryList = getSimpleJdbcTemplate().query(getcountryList.toString(), countryListmapper);
		
		loggerUtil.logMethodExit("getCountryList");
		return countryList;
		
	}
	
	@Override
	public List<KeyValueBean> getOccupationList() throws Exception {
		loggerUtil.logMethodEntry("getOccupationList");
		
		StringBuffer getOccupationList = new StringBuffer();
		getOccupationList.append(" select VOM_OCCU_CODE,VOM_OCCU_NAME from VMS_OCCUPATION_MAST  order by VOM_OCCU_NAME ");
		loggerUtil.debug("Query For Getting Country List : "+getOccupationList.toString());
		
		ParameterizedRowMapper<KeyValueBean> occupationListmapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		List<KeyValueBean> occupationList = getSimpleJdbcTemplate().query(getOccupationList.toString(), occupationListmapper);
			
		loggerUtil.logMethodExit("getOccupationList"+occupationList);	
		return occupationList;
	}
	@Override
	public List<KeyValueBean> getReasonForNoTaxList() throws Exception {
		loggerUtil.logMethodEntry("getReasonForNoTaxList");
		
		StringBuffer getreasonForNoTaxList = new StringBuffer();
		getreasonForNoTaxList.append(" select VPC_PARAM_ID,VPC_PARAM_NAME from vms_param_config_mast where vpc_param_type='Reason_For_Not_Having_Tax' order by VPC_PARAM_ID ");
		loggerUtil.debug("Query For Getting Reason For No TaX : "+getreasonForNoTaxList.toString());
		
		ParameterizedRowMapper<KeyValueBean> getreasonForNoTaxListmapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		List<KeyValueBean> reasonForNoTaxList = getSimpleJdbcTemplate().query(getreasonForNoTaxList.toString(), getreasonForNoTaxListmapper);
			
		loggerUtil.logMethodExit("getreasonForNoTaxList"+reasonForNoTaxList);	
		return reasonForNoTaxList;
	}
	
	@Override
	public List<KeyValueBean> getAllCountryList() throws Exception {
		loggerUtil.logMethodEntry("getAllCountryList");
		
		StringBuffer getallcountryList = new StringBuffer();
		getallcountryList.append(" select GCM_SWITCH_CNTRY_CODE,gcm_cntry_name from gen_cntry_mast where GCM_ISO_CNTRY_CODE <> '999' order by gcm_cntry_name ");
		loggerUtil.debug("Query For Getting ALL Country List : "+getallcountryList.toString());
		
		ParameterizedRowMapper<KeyValueBean> allcountryListmapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		List<KeyValueBean> allcountryList = getSimpleJdbcTemplate().query(getallcountryList.toString(), allcountryListmapper);
		
		loggerUtil.logMethodExit("getAllCountryList");
		return allcountryList;
		
	}
	
	@Override
	public List<KeyValueBean> getAllThirdPartyCountryList() throws Exception {
		loggerUtil.logMethodEntry("getAllThirdPartyCountryList");
		
		StringBuffer getAllThirdPartyCountryList = new StringBuffer();
		getAllThirdPartyCountryList.append(" select GCM_SWITCH_CNTRY_CODE,gcm_cntry_name from gen_cntry_mast where GCM_ISO_CNTRY_CODE <> '999' order by gcm_cntry_name ");
		loggerUtil.debug("Query For Getting ALL Third Party Country List : "+getAllThirdPartyCountryList.toString());
		
		ParameterizedRowMapper<KeyValueBean> AllThirdPartyCountryListmapper = new ParameterizedRowMapper<KeyValueBean>() {
			public KeyValueBean mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				KeyValueBean keyValue = new KeyValueBean();
				keyValue.setKey(rs.getString(1));
				keyValue.setValue(rs.getString(2));

				return keyValue;
			}
		};
		List<KeyValueBean> AllThirdPartyCountryList = getSimpleJdbcTemplate().query(getAllThirdPartyCountryList.toString(), AllThirdPartyCountryListmapper);
		
		loggerUtil.logMethodExit("AllThirdPartyCountryList");
		return AllThirdPartyCountryList;
		
	}
	
	@Override
	public List<KeyValueBean> getThirdPartyStateList(String countryCode, String instCode) throws Exception{
		loggerUtil.logMethodEntry("getThirdPartyStateList");
		List<KeyValueBean> ThirdPartyStateList = new ArrayList<KeyValueBean>();

		if(countryCode!=null && !"".equals(countryCode)){
			StringBuffer getThirdPartyStateList = new StringBuffer();
			getThirdPartyStateList.append(" select GSM_SWITCH_STATE_CODE,gsm_state_name from gen_state_mast where GSM_CNTRY_CODE=(select GCM_CNTRY_CODE from gen_cntry_mast where gcm_switch_cntry_code=? and  gcm_inst_code=1) and gsm_inst_code=? order by gsm_state_name");
			loggerUtil.debug("Query For Getting Master List Of States : "+getThirdPartyStateList.toString());
			
			ParameterizedRowMapper<KeyValueBean> ThirdPartyStateListListmapper = new ParameterizedRowMapper<KeyValueBean>() {
				public KeyValueBean mapRow(ResultSet rs, int rowNum)throws SQLException {
					
					KeyValueBean keyValue = new KeyValueBean();
					keyValue.setKey(rs.getString(1));
					keyValue.setValue(rs.getString(2));
	
					return keyValue;
				}
			};
			ThirdPartyStateList = getSimpleJdbcTemplate().query(getThirdPartyStateList.toString(), ThirdPartyStateListListmapper,countryCode,instCode);
		}
		/*else{
			KeyValueBean keyValue = new KeyValueBean();
			keyValue.setKey("Select");
			keyValue.setValue("NOT SELECTED");
			cardTypeList.add(keyValue);
		}*/
		
		loggerUtil.logMethodExit("ThirdPartyStateList");
		return ThirdPartyStateList;
	}
}